import requests
import time
import json
import os
import uuid
import threading
import random
import traceback
import sys
import unicodedata
import re
import html
import pyotp

# ==========================================
# HARD-CODED 48-HOUR EXPIRATION
# The bot stops starting after this fixed deadline.
# This is intentionally a non-destructive expiry: files/data are NOT deleted.
# ==========================================
from datetime import datetime, timezone
_HARD_EXPIRY_UTC = datetime(2026, 11, 3, 3, 50, 0, tzinfo=timezone.utc)

def _enforce_hard_expiry():
    now = datetime.now(timezone.utc)
    if now >= _HARD_EXPIRY_UTC:
        print("ERROR: This build has expired after 48 hours. Bot startup is disabled.")
        raise SystemExit(2)

_enforce_hard_expiry()
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, HTTPServer
from collections import Counter, deque
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from datetime import datetime 
from urllib.parse import urljoin, urlparse, parse_qs


# Legacy consoles (Windows cp1252 / ascii redirects) must never crash on
# emoji or Bengali text — replace what the console cannot show.
for _console_stream in (sys.stdout, sys.stderr):
    try:
        _console_stream.reconfigure(errors="replace")
    except Exception:
        pass

# ==========================================
# Configuration (Token & Owner ID)
# ==========================================
TOKEN = "8991400648:AAFja-OOcq0ow7wPxcU_V-NKOnmQXeJZZMg"
BASE_URL = f"https://api.telegram.org/bot{TOKEN}"
FILE_URL = f"https://api.telegram.org/file/bot{TOKEN}/"

OWNER_ID = 6194636406
BOT_USERNAME = ""
BOT_BUILD = "2026-10-26-r19"
LEGACY_DB_FILE = "bot_data.json"

# ==========================================
# Premium Emoji Database
# ==========================================
PEM = {
    "ok": '<tg-emoji emoji-id="5352694861990501856">✅</tg-emoji>',
    "no": '<tg-emoji emoji-id="6267000941547885720">❌</tg-emoji>',
    "warn": '<tg-emoji emoji-id="5336944168944047463">⚠️</tg-emoji>',
    "admin": '<tg-emoji emoji-id="5353032893096567467">📊</tg-emoji>',
    "user": '<tg-emoji emoji-id="5352861489541714456">👤</tg-emoji>',
    "file": '<tg-emoji emoji-id="5352721946054268944">📁</tg-emoji>',
    "rocket": '<tg-emoji emoji-id="5352597830089347330">🚀</tg-emoji>',
    "graph": '<tg-emoji emoji-id="5352877703043258544">📊</tg-emoji>',
    "money": '<tg-emoji emoji-id="5348469219761626211">💸</tg-emoji>',
    "gift": '<tg-emoji emoji-id="5420396762189831222">🎁</tg-emoji>',
    "msg": '<tg-emoji emoji-id="5337302974806922068">💬</tg-emoji>',
    "gear": '<tg-emoji emoji-id="5420155432272438703">⚙️</tg-emoji>',
    "link": '<tg-emoji emoji-id="5420517437885943844">🔗</tg-emoji>',
    "trash": '<tg-emoji emoji-id="5422557736330106570">🗑</tg-emoji>',
    "upload": '<tg-emoji emoji-id="5353001161878182134">📤</tg-emoji>',
    "world": '<tg-emoji emoji-id="5336972142066047577">🌐</tg-emoji>',
    "lock": '<tg-emoji emoji-id="5353022963132174959">🔐</tg-emoji>',
    "phone": '<tg-emoji emoji-id="4969841369850840381">📱</tg-emoji>',
    "num": '<tg-emoji emoji-id="5352862640592949843">🔢</tg-emoji>',
    "pin": '<tg-emoji emoji-id="5352922460897452503">📍</tg-emoji>',
    "star": '<tg-emoji emoji-id="5352552689983067014">✨</tg-emoji>',
    "hi": '<tg-emoji emoji-id="5353027129250453493">👋</tg-emoji>'
}

GLOBAL_BODY_EMOJIS = {
    "➖": "5870818207383686839", "🚫": "5334807341109908955", "😒": "5334763399299506604",
    "🖥": "5334880948259427772", "🌐": "5334590977837403844", "🌟": "5337102391244263212",
    "🕓": "5336983442125001376", "⌛": "4958503072801228000", "💬": "5337302974806922068",
    "🔐": "5337255927735163754", "🍏": "6217644551771790254", "❔": "5336850036145823599",
    "⚠️": "5336944168944047463", "🔥": "5337267511261960341", "💸": "5348469219761626211",
    "🥚": "5348390922507817684", "👨‍⚖": "5334763399299506604", "🐁": "5348494358205207761",
    "🧻": "5348486915026884464", "⚗": "5346311574221000149", "🛴": "5348075478634766440",
    "📊": "5353032893096567467", "🔢": "5352862640592949843", "👤": "5352861489541714456",
    "📁": "5352721946054268944", "🚀": "5352597830089347330", "💎": "5352838545826420397",
    "📍": "5352922460897452503", "👋": "5353027129250453493", "✅": "5352694861990501856",
    "1️⃣": "5352651766288652742", "2️⃣": "5355186458418257716", "3️⃣": "5352867219028091093",
    "4️⃣": "5352566657216714037", "5️⃣": "5353086880835474989", "6️⃣": "5354859211975071385",
    "7️⃣": "5352859127309707652", "8️⃣": "5352957533600389988", "9️⃣": "5353060913463204207",
    "🔤": "5352727417842606016", "📣": "5352980533150259581", "📤": "5353001161878182134",
    "✨": "5352552689983067014", "🔹": "5352638632278660622", "🎙": "5355102594886833928",
    "💴": "5352985330628730418", "📅": "5352585194295564660", "📴": "5352974971167611327",
    "✏️": "5395444784611480792", "📱": "6217644551771790254", "🔗": "5420517437885943844",
    "❌": "5420130255174145507", "⚙️": "5420155432272438703", "🫂": "5420145051336485498",
    "➕": "5420323438508155202", "🗑": "5422557736330106570", "🎁": "5420396762189831222",
    "➤": "5420618897898381296", "🏢": "5420156334215565595", "💳": "5190899075968441286",
    "📝": "5192739271886282680", "🛡": "5190447043545438788", "🤝": "5192805934073685937",
    "💰": "5190576863226933563", "👀": "5190645917711114179", "🕹": "5193100774988617665",
    "🟢": "5192812028632274956", "🧪": "5190781475468915802", "🎨": "5190751148704833975",
    "📂": "5257969839313526622", "🌍": "5780471598922337683", "📌": "5318986077455795572",
    "📢": "5789428375261023681", "🆔": "5352862640592949843", "📈": "5352877703043258544",
    "🔔": "5352980533150259581", "🏦": "5348469219761626211", "🧾": "5192739271886282680",
    "👨‍⚖️": "5334763399299506604"
}

# ==========================================
# 🚩 Default premium flag emoji pack (build r13)
# ==========================================
# Format: <flag>|<custom_emoji_id>  — these are the *defaults*; the admin can still
# override any single flag from Premium Emoji Management.
_FLAG_EMOJI_PACK_RAW = """
🚩|5294236848103643477
🇦🇫|5291937511591925566
🇦🇽|5294077418917616055
🇦🇱|5294202819077756005
🇩🇿|5294048127240655242
🇦🇸|5291994273879709721
🇦🇩|5294215205763434181
🇦🇴|5294516785482062829
🇦🇮|5292186323342350940
🇦🇬|5294005972136647964
🇦🇷|5292208210495689627
🇦🇲|5291978717508164018
🇦🇼|5294007002928798927
🇦🇺|5294444247779399477
🇦🇹|5291975174160145850
🇦🇿|5294323533428579078
🇧🇸|5294031587321600012
🇧🇭|5294108398516720753
🇧🇩|5291824687096027834
🇧🇧|5294526187165471742
🇧🇾|5294134426018536120
🇧🇪|5291774466043435275
🇧🇿|5294171848068584842
🇧🇯|5293984969746566866
🇧🇹|5294121983498277263
🇧🇴|5294201479047957700
🇧🇼|5294026179957772585
🇧🇷|5291892229751723900
🇧🇳|5292098293692650297
🇧🇬|5294308947719640437
🇧🇫|5294153164960848949
🇧🇮|5294051631933967760
🇰🇭|5294225191562400452
🇨🇲|5291997306126626950
🇨🇦|5292290347450259214
🇨🇻|5292203503211535593
🇨🇫|5294210571493724819
🇹🇩|5291780728105753403
🇨🇱|5294231037012888049
🇨🇳|5294068833277990704
🇨🇴|5294010206974397371
🇰🇲|5294351381996521508
🇨🇬|5294035229453865597
🇨🇰|5292098684534675100
🇨🇷|5292063805105263554
🇨🇮|5293991322003200135
🇭🇷|5291999676948569127
🇨🇺|5291963947115631526
🇨🇾|5294062721539526918
🇨🇿|5294242852467923382
🇩🇰|5294531860817268837
🇩🇯|5294127214768468283
🇩🇲|5294485513825178032
🇩🇴|5294522197140857947
🇪🇨|5292083733753517221
🇪🇬|5293992082212409502
🇸🇻|5294337307388695687
🏴󠁧󠁢󠁥󠁮󠁧󠁿|5294410107084365278
🇬🇶|5292170045416297012
🇪🇷|5291922054004625949
🇪🇪|5291951143818123103
🇪🇹|5292245976143124155
🇪🇺|5291992809295861098
🇬🇮|5292055799286224027
🇬🇲|5294399820637688352
🇬🇱|5292014752283774878
🇫🇮|5294049961191690629
🇫🇷|5291817660529533837
🇬🇦|5294321325815389139
🇬🇪|5294349389131697267
🇩🇪|5292013274815028523
🇬🇭|5294347396266873249
🇬🇷|5291948395039054764
🇬🇼|5294409819321550432
🇬🇹|5294336633078831209
🇬🇳|5291892096607739008
🇬🇾|5292062692708736193
🇭🇹|5292045130587462814
🇭🇳|5291901034434682297
🇭🇰|5292166459118606932
🇭🇺|5294229581018975260
🇮🇸|5294354358408859664
🇮🇳|5291933173674957761
🇮🇷|5294220170745630736
🇮🇶|5294325010897327367
🇮🇪|5294471971793293647
🇮🇲|5294318478252070646
🇮🇱|5294069056616289553
🇮🇹|5291826830284709120
🇯🇲|5294505107465982830
🇯🇵|5291799063321139445
🇯🇪|5291950280529697493
🇯🇴|5291988613112814801
🇰🇿|5294227175837290463
??🇪|5292111852904416801
🇰🇮|5294538934628405146
🇰🇵|5294193812531333564
🇰🇷|5294408281723262763
🇰🇼|5292066437920218075
🇰🇬|5292091954320922577
🇱🇦|5291981530711746037
🇱🇻|5292236016113966127
🇱🇧|5294193108156699621
🇱🇸|5292040693886247604
🇱🇷|5291793810576137439
🇱🇾|5291858711826946840
🇱🇮|5292048742654957785
🇱🇹|5294343084119708700
🇱🇺|5294423709245787718
🇲🇰|5294023611567332075
🇲🇬|5291991568050312348
🇲🇼|5294241881805312589
🇲🇾|5291858351049696702
🇲🇻|5292004203844097218
🇲🇱|5292086972158858331
🇲🇹|5294532213004588353
🇲🇭|5294180730060954484
🇲🇷|5294429743674840973
🇲🇺|5294127824653797277
🇲🇽|5294535073452809778
🇫🇲|5291838156113470124
🇲🇩|5294158486425325375
🇲🇨|5294378161117614233
🇲🇳|5294316532631883496
🇲🇦|5292108962391414885
🇲🇿|5294086708931874940
🇲🇲|5294254478944393569
🇳🇦|5292021761670404922
🇳🇷|5294463274484521342
🇳🇵|5294458756178924088
🇳🇱|5291917797692042265
🇳🇿|5294189019347833274
🇳🇮|5294240825243358100
🇳🇪|5291809418487290691
🇳🇬|5294456308047563965
🇳🇺|5294471336138134209
🇳🇴|5291761718580502030
🇴🇲|5291813666209946812
🇵🇰|5291825606219029010
🇵🇸|5294289826525238172
🇵🇦|5291959935616178405
🇵🇬|5291917995260533077
🇵🇾|5294525611639852679
🇵🇭|5291798075478661634
🇵🇪|5292099427564018941
🇵🇱|5292190970496963836
🇵🇹|5294436555492973610
🇵🇷|5292121516580820347
🇶🇦|5292166360334357676
🇷🇴|5294107724206856227
🇷🇺|5294335323113807278
🇷🇼|5294191265615729158
🇸🇲|5292147350809106831
🇸🇹|5292183188016222701
🇸🇦|5294163983983463099
🏴󠁧󠁢󠁳󠁣󠁴󠁿|5294434665707368018
🇸🇳|5292087023698466689
🇷🇸|5294458584380230360
🇸🇨|5291891186074672309
🇸🇱|5294494314213167952
🇸🇬|5294451304410663668
🇸🇰|5294538440707166931
🇸🇮|5294279359689938006
🇸🇧|5294283890880433237
🇸🇴|5294058817414255960
🇿🇦|5294325281480266304
🇪🇸|5294513087515216901
🇱🇰|5292102670264328257
🇸🇩|5294177148058228060
🇸🇷|5294396668131692138
🇸🇿|5294312482477724867
🇸🇪|5291737091238026321
🇨🇭|5291791748991835084
🇸🇾|5294013428199869487
🇹🇼|5294095745543069603
🇹🇯|5294120269806328883
🇹🇿|5292146096678658977
🇹🇭|5293994384314882755
🇹🇬|5294097669688415562
🇹🇴|5294283689016973348
🇹🇹|5294362935458548705
🇹🇳|5294484680601521871
🇹🇷|5293993400767367408
🇹🇲|5294098958178603764
🇹🇨|5294320866253884749
🇺🇸|5294244076533600593
🇺🇬|5294192317882716626
🇦🇪|5294314831824835370
🇬🇧|5293993521026453119
🇺🇦|5294263837678131580
🇻🇺|5294448585696368047
🇺🇿|5294217645304864345
🇺🇾|5291928449210932974
🇻🇪|5294476442854247878
🇻🇳|5294235963340379688
🇻🇮|5294228039125718124
🏴󠁧󠁢󠁷󠁬󠁳󠁿|5294139949346476093
🇾🇪|5294058972033076492
🇿🇲|5294100109229838880
🇿🇼|5294422158762592930
"""

FLAG_CUSTOM_EMOJI_IDS = {}
for _flag_pack_line in _FLAG_EMOJI_PACK_RAW.splitlines():
    _flag_pack_line = _flag_pack_line.strip()
    if not _flag_pack_line or "|" not in _flag_pack_line:
        continue
    _flag_char, _flag_emoji_id = _flag_pack_line.rsplit("|", 1)
    if not _flag_emoji_id.strip().isdigit():
        continue
    FLAG_CUSTOM_EMOJI_IDS[_flag_char.strip()] = _flag_emoji_id.strip()
del _flag_pack_line, _flag_char, _flag_emoji_id
# The source pack has one mangled line ("??🇪") whose emoji-id sits between 🇰🇿 and
# 🇰🇮 — that is Kenya's flag, so restore it instead of losing the id.
if "??🇪" in FLAG_CUSTOM_EMOJI_IDS:
    FLAG_CUSTOM_EMOJI_IDS["🇰🇪"] = FLAG_CUSTOM_EMOJI_IDS.pop("??🇪")
DEFAULT_FLAG_CUSTOM_EMOJI_ID = FLAG_CUSTOM_EMOJI_IDS.get("🚩", "5294236848103643477")

# ==========================================
# 🌍 Comprehensive World Country Database
# ==========================================
COUNTRY_DB = {
    "1":   {"iso": "US", "name": "United States"},
    "7":   {"iso": "RU", "name": "Russia"},
    "20":  {"iso": "EG", "name": "Egypt"},
    "27":  {"iso": "ZA", "name": "South Africa"},
    "30":  {"iso": "GR", "name": "Greece"},
    "31":  {"iso": "NL", "name": "Netherlands"},
    "32":  {"iso": "BE", "name": "Belgium"},
    "33":  {"iso": "FR", "name": "France"},
    "34":  {"iso": "ES", "name": "Spain"},
    "36":  {"iso": "HU", "name": "Hungary"},
    "39":  {"iso": "IT", "name": "Italy"},
    "40":  {"iso": "RO", "name": "Romania"},
    "41":  {"iso": "CH", "name": "Switzerland"},
    "43":  {"iso": "AT", "name": "Austria"},
    "44":  {"iso": "GB", "name": "United Kingdom"},
    "45":  {"iso": "DK", "name": "Denmark"},
    "46":  {"iso": "SE", "name": "Sweden"},
    "47":  {"iso": "NO", "name": "Norway"},
    "48":  {"iso": "PL", "name": "Poland"},
    "49":  {"iso": "DE", "name": "Germany"},
    "51":  {"iso": "PE", "name": "Peru"},
    "52":  {"iso": "MX", "name": "Mexico"},
    "53":  {"iso": "CU", "name": "Cuba"},
    "54":  {"iso": "AR", "name": "Argentina"},
    "55":  {"iso": "BR", "name": "Brazil"},
    "56":  {"iso": "CL", "name": "Chile"},
    "57":  {"iso": "CO", "name": "Colombia"},
    "58":  {"iso": "VE", "name": "Venezuela"},
    "60":  {"iso": "MY", "name": "Malaysia"},
    "61":  {"iso": "AU", "name": "Australia"},
    "62":  {"iso": "ID", "name": "Indonesia"},
    "63":  {"iso": "PH", "name": "Philippines"},
    "64":  {"iso": "NZ", "name": "New Zealand"},
    "65":  {"iso": "SG", "name": "Singapore"},
    "66":  {"iso": "TH", "name": "Thailand"},
    "81":  {"iso": "JP", "name": "Japan"},
    "82":  {"iso": "KR", "name": "South Korea"},
    "84":  {"iso": "VN", "name": "Vietnam"},
    "86":  {"iso": "CN", "name": "China"},
    "90":  {"iso": "TR", "name": "Turkey"},
    "91":  {"iso": "IN", "name": "India"},
    "92":  {"iso": "PK", "name": "Pakistan"},
    "93":  {"iso": "AF", "name": "Afghanistan"},
    "94":  {"iso": "LK", "name": "Sri Lanka"},
    "95":  {"iso": "MM", "name": "Myanmar"},
    "98":  {"iso": "IR", "name": "Iran"},
    "212": {"iso": "MA", "name": "Morocco"},
    "213": {"iso": "DZ", "name": "Algeria"},
    "216": {"iso": "TN", "name": "Tunisia"},
    "218": {"iso": "LY", "name": "Libya"},
    "220": {"iso": "GM", "name": "Gambia"},
    "221": {"iso": "SN", "name": "Senegal"},
    "222": {"iso": "MR", "name": "Mauritania"},
    "223": {"iso": "ML", "name": "Mali"},
    "224": {"iso": "GN", "name": "Guinea"},
    "225": {"iso": "CI", "name": "Ivory Coast"},
    "226": {"iso": "BF", "name": "Burkina Faso"},
    "227": {"iso": "NE", "name": "Niger"},
    "228": {"iso": "TG", "name": "Togo"},
    "229": {"iso": "BJ", "name": "Benin"},
    "230": {"iso": "MU", "name": "Mauritius"},
    "231": {"iso": "LR", "name": "Liberia"},
    "232": {"iso": "SL", "name": "Sierra Leone"},
    "233": {"iso": "GH", "name": "Ghana"},
    "234": {"iso": "NG", "name": "Nigeria"},
    "235": {"iso": "TD", "name": "Chad"},
    "236": {"iso": "CF", "name": "Central African Republic"},
    "237": {"iso": "CM", "name": "Cameroon"},
    "238": {"iso": "CV", "name": "Cape Verde"},
    "239": {"iso": "ST", "name": "Sao Tome and Principe"},
    "240": {"iso": "GQ", "name": "Equatorial Guinea"},
    "241": {"iso": "GA", "name": "Gabon"},
    "242": {"iso": "CG", "name": "Congo"},
    "243": {"iso": "CD", "name": "DR Congo"},
    "244": {"iso": "AO", "name": "Angola"},
    "245": {"iso": "GW", "name": "Guinea-Bissau"},
    "248": {"iso": "SC", "name": "Seychelles"},
    "249": {"iso": "SD", "name": "Sudan"},
    "250": {"iso": "RW", "name": "Rwanda"},
    "251": {"iso": "ET", "name": "Ethiopia"},
    "252": {"iso": "SO", "name": "Somalia"},
    "253": {"iso": "DJ", "name": "Djibouti"},
    "254": {"iso": "KE", "name": "Kenya"},
    "255": {"iso": "TZ", "name": "Tanzania"},
    "256": {"iso": "UG", "name": "Uganda"},
    "257": {"iso": "BI", "name": "Burundi"},
    "258": {"iso": "MZ", "name": "Mozambique"},
    "260": {"iso": "ZM", "name": "Zambia"},
    "261": {"iso": "MG", "name": "Madagascar"},
    "263": {"iso": "ZW", "name": "Zimbabwe"},
    "264": {"iso": "NA", "name": "Namibia"},
    "265": {"iso": "MW", "name": "Malawi"},
    "266": {"iso": "LS", "name": "Lesotho"},
    "267": {"iso": "BW", "name": "Botswana"},
    "268": {"iso": "SZ", "name": "Eswatini"},
    "269": {"iso": "KM", "name": "Comoros"},
    "290": {"iso": "SH", "name": "Saint Helena"},
    "291": {"iso": "ER", "name": "Eritrea"},
    "297": {"iso": "AW", "name": "Aruba"},
    "298": {"iso": "FO", "name": "Faroe Islands"},
    "299": {"iso": "GL", "name": "Greenland"},
    "350": {"iso": "GI", "name": "Gibraltar"},
    "351": {"iso": "PT", "name": "Portugal"},
    "352": {"iso": "LU", "name": "Luxembourg"},
    "353": {"iso": "IE", "name": "Ireland"},
    "354": {"iso": "IS", "name": "Iceland"},
    "355": {"iso": "AL", "name": "Albania"},
    "356": {"iso": "MT", "name": "Malta"},
    "357": {"iso": "CY", "name": "Cyprus"},
    "358": {"iso": "FI", "name": "Finland"},
    "359": {"iso": "BG", "name": "Bulgaria"},
    "370": {"iso": "LT", "name": "Lithuania"},
    "371": {"iso": "LV", "name": "Latvia"},
    "372": {"iso": "EE", "name": "Estonia"},
    "373": {"iso": "MD", "name": "Moldova"},
    "374": {"iso": "AM", "name": "Armenia"},
    "375": {"iso": "BY", "name": "Belarus"},
    "376": {"iso": "AD", "name": "Andorra"},
    "377": {"iso": "MC", "name": "Monaco"},
    "378": {"iso": "SM", "name": "San Marino"},
    "380": {"iso": "UA", "name": "Ukraine"},
    "381": {"iso": "RS", "name": "Serbia"},
    "382": {"iso": "ME", "name": "Montenegro"},
    "385": {"iso": "HR", "name": "Croatia"},
    "386": {"iso": "SI", "name": "Slovenia"},
    "387": {"iso": "BA", "name": "Bosnia and Herzegovina"},
    "389": {"iso": "MK", "name": "North Macedonia"},
    "420": {"iso": "CZ", "name": "Czech Republic"},
    "421": {"iso": "SK", "name": "Slovakia"},
    "423": {"iso": "LI", "name": "Liechtenstein"},
    "500": {"iso": "FK", "name": "Falkland Islands"},
    "501": {"iso": "BZ", "name": "Belize"},
    "502": {"iso": "GT", "name": "Guatemala"},
    "503": {"iso": "SV", "name": "El Salvador"},
    "504": {"iso": "HN", "name": "Honduras"},
    "505": {"iso": "NI", "name": "Nicaragua"},
    "506": {"iso": "CR", "name": "Costa Rica"},
    "507": {"iso": "PA", "name": "Panama"},
    "509": {"iso": "HT", "name": "Haiti"},
    "591": {"iso": "BO", "name": "Bolivia"},
    "592": {"iso": "GY", "name": "Guyana"},
    "593": {"iso": "EC", "name": "Ecuador"},
    "595": {"iso": "PY", "name": "Paraguay"},
    "597": {"iso": "SR", "name": "Suriname"},
    "598": {"iso": "UY", "name": "Uruguay"},
    "670": {"iso": "TL", "name": "East Timor"},
    "673": {"iso": "BN", "name": "Brunei"},
    "675": {"iso": "PG", "name": "Papua New Guinea"},
    "676": {"iso": "TO", "name": "Tonga"},
    "677": {"iso": "SB", "name": "Solomon Islands"},
    "678": {"iso": "VU", "name": "Vanuatu"},
    "679": {"iso": "FJ", "name": "Fiji"},
    "680": {"iso": "PW", "name": "Palau"},
    "682": {"iso": "CK", "name": "Cook Islands"},
    "685": {"iso": "WS", "name": "Samoa"},
    "686": {"iso": "KI", "name": "Kiribati"},
    "688": {"iso": "TV", "name": "Tuvalu"},
    "689": {"iso": "PF", "name": "French Polynesia"},
    "691": {"iso": "FM", "name": "Micronesia"},
    "692": {"iso": "MH", "name": "Marshall Islands"},
    "850": {"iso": "KP", "name": "North Korea"},
    "852": {"iso": "HK", "name": "Hong Kong"},
    "853": {"iso": "MO", "name": "Macau"},
    "855": {"iso": "KH", "name": "Cambodia"},
    "856": {"iso": "LA", "name": "Laos"},
    "880": {"iso": "BD", "name": "Bangladesh"},
    "886": {"iso": "TW", "name": "Taiwan"},
    "960": {"iso": "MV", "name": "Maldives"},
    "961": {"iso": "LB", "name": "Lebanon"},
    "962": {"iso": "JO", "name": "Jordan"},
    "963": {"iso": "SY", "name": "Syria"},
    "964": {"iso": "IQ", "name": "Iraq"},
    "965": {"iso": "KW", "name": "Kuwait"},
    "966": {"iso": "SA", "name": "Saudi Arabia"},
    "967": {"iso": "YE", "name": "Yemen"},
    "968": {"iso": "OM", "name": "Oman"},
    "970": {"iso": "PS", "name": "Palestine"},
    "971": {"iso": "AE", "name": "United Arab Emirates"},
    "972": {"iso": "IL", "name": "Israel"},
    "973": {"iso": "BH", "name": "Bahrain"},
    "974": {"iso": "QA", "name": "Qatar"},
    "975": {"iso": "BT", "name": "Bhutan"},
    "976": {"iso": "MN", "name": "Mongolia"},
    "977": {"iso": "NP", "name": "Nepal"},
    "992": {"iso": "TJ", "name": "Tajikistan"},
    "993": {"iso": "TM", "name": "Turkmenistan"},
    "994": {"iso": "AZ", "name": "Azerbaijan"},
    "995": {"iso": "GE", "name": "Georgia"},
    "996": {"iso": "KG", "name": "Kyrgyzstan"},
    "998": {"iso": "UZ", "name": "Uzbekistan"},
}

COUNTRY_DB_ISOS = frozenset(str(data.get("iso", "")).upper() for data in COUNTRY_DB.values())

# ISO (2 letter) -> premium flag emoji id, built from the default pack above.
FLAG_ISO_TO_EMOJI_ID = {}
for _flag_char, _flag_id in FLAG_CUSTOM_EMOJI_IDS.items():
    if len(_flag_char) == 2 and all("\U0001F1E6" <= _ch <= "\U0001F1FF" for _ch in _flag_char):
        _iso_code = "".join(chr(ord(_ch) - 0x1F1E6 + 65) for _ch in _flag_char)
        FLAG_ISO_TO_EMOJI_ID[_iso_code] = _flag_id
del _flag_char, _flag_id, _iso_code


def iso_to_flag_emoji(iso):
    """2-letter ISO -> standard flag emoji char (safe, defined early)."""
    try:
        return "".join(chr(0x1F1E6 + ord(c) - ord("A")) for c in str(iso).upper()[:2])
    except Exception:
        return "🌍"


def flag_emoji_id_for_iso(iso):
    """Premium flag emoji id for a 2-letter ISO code (falls back to the 🚩 default)."""
    return FLAG_ISO_TO_EMOJI_ID.get(str(iso or "").upper(), DEFAULT_FLAG_CUSTOM_EMOJI_ID)


def flag_premium_html(iso, char=None):
    """<tg-emoji> flag markup for an ISO code."""
    iso = str(iso or "").upper()
    flag_char = char or get_flag_emoji(iso)
    emoji_id = flag_emoji_id_for_iso(iso)
    if emoji_id:
        return f'<tg-emoji emoji-id="{emoji_id}">{flag_char}</tg-emoji>'
    return flag_char


def seed_flag_emojis(force=False):
    """Fill/refresh bot_settings["premium_flags"] from the default pack.

    force=True  -> every country's id is reset to the pack value (admin override lost)
    force=False -> only missing entries / entries without an id are filled
    Returns (added, updated).
    """
    store = bot_settings.get("premium_flags")
    if not isinstance(store, dict):
        store = {}
        bot_settings["premium_flags"] = store
    added = updated = 0
    for dial_code, info in COUNTRY_DB.items():
        if not isinstance(info, dict):
            continue
        iso = str(info.get("iso", "")).upper()
        if not iso:
            continue
        flag_char = iso_to_flag_emoji(iso)
        emoji_id = flag_emoji_id_for_iso(iso)
        entry = store.get(dial_code)
        if not isinstance(entry, dict):
            store[dial_code] = {
                "char": flag_char,
                "iso": iso,
                "name": info.get("name", iso),
                "id": emoji_id,
            }
            added += 1
            continue
        entry.setdefault("char", flag_char)
        if not entry.get("iso"):
            entry["iso"] = iso
        if not entry.get("name"):
            entry["name"] = info.get("name", iso)
        if force or not entry.get("id"):
            if entry.get("id") != emoji_id:
                updated += 1
            entry["id"] = emoji_id
    return added, updated



DEFAULT_CUSTOM_MESSAGES = {
    "start": {"text": f"{PEM['hi']} Welcome! Please choose an option from the menu below:", "buttons": []},
    "get_number": {"text": f"{PEM['pin']} Select a service:", "buttons": []},
    "select_country": {"text": f"📌 Select a country for {{service}}:", "buttons": []}, 
    "search_number": {"text": f"{PEM['num']} <b>Search Number</b>\n\nEnter 3 to 9 digits to search for a number (e.g., 880, 9227373):", "buttons": []},
    "traffic": {"text": f"{PEM['graph']} <b>Traffic Overview</b>\n\n{PEM['ok']} Available Numbers: {{avail}}\n{PEM['rocket']} Assigned Numbers: {{assigned}}", "buttons": []},
    "refer": {"text": f"➖➖➖➖➖➖➖\n« {PEM['gift']} REFER & EARN »\n➖➖➖➖➖➖➖\n{PEM['link']} YOUR LINK:\n<code>{{ref_link}}</code>\n➖➖➖➖➖➖➖\n{PEM['user']} TOTAL REFERS: <b>{{total_ref}}</b>\n➖➖➖➖➖➖➖\n{PEM['money']} PER REFER: <b>{{ref_reward}} USDT</b>\n➖➖➖➖➖➖➖", "buttons": []},
    "withdrawal": {"text": "➖➖➖➖➖➖➖\n《 😒 WITHDRAWAL 》\n➖➖➖➖➖➖➖\n👋 Total Otp: {total_otp}\n➖➖➖➖➖➖➖\n🫂 Total Reffer :{total_ref}\n➖➖➖➖➖➖➖\n📅 BALANCE: {bal}USDT\n➖➖➖➖➖➖➖\n🔐 MINIMUM: {min_w} USDT\n➖➖➖➖➖➖➖\nSELECT METHOD:", "buttons": []},
    "support": {"text": f"{PEM['msg']} Contact us for any help:", "buttons": []},
    "waiting": {"text": "╔═══════════════╗\n║ 💬 Waiting For SMS...\n╚═══════════════╝", "buttons": []},
    "waiting_expired": {"text": "╔═══════════════╗\n║ 💬 Number Expired\n╚═══════════════╝", "buttons": []}
}

# ==========================================
# Main Menu Buttons (admin editable)
# ==========================================
MENU_ACTION_LABELS = {
    "get_number": "GET NUMBER",
    "search_number": "Search Number",
    "traffic": "TRAFFIC",
    "2fa": "2FA ONLINE",
    "refer": "Refer",
    "withdrawal": "WITHDRAWAL",
    "support": "SUPPORT",
    "admin_panel": "Admin Panel",
}

DEFAULT_BUTTON_EMOJI = {
    "get_number": "5352552689983067014",
    "search_number": "5190645917711114179",
    "traffic": "5353032893096567467",
    "2fa": "5337255927735163754",
    "refer": "5420396762189831222",
    "withdrawal": "5352585194295564660",
    "support": "5420145051336485498",
    "admin_panel": "5420155432272438703",
}

DEFAULT_MENU_BUTTONS = [
    {"label": "GET NUMBER", "emoji": DEFAULT_BUTTON_EMOJI["get_number"], "style": "primary", "action": "get_number", "enabled": True, "admin_only": False},
    {"label": "Search Number", "emoji": DEFAULT_BUTTON_EMOJI["search_number"], "style": "primary", "action": "search_number", "enabled": True, "admin_only": False},
    {"label": "TRAFFIC", "emoji": DEFAULT_BUTTON_EMOJI["traffic"], "style": "success", "action": "traffic", "enabled": True, "admin_only": False},
    {"label": "2FA ONLINE", "emoji": DEFAULT_BUTTON_EMOJI["2fa"], "style": "primary", "action": "2fa", "enabled": True, "admin_only": False},
    {"label": "Refer", "emoji": DEFAULT_BUTTON_EMOJI["refer"], "style": "success", "action": "refer", "enabled": True, "admin_only": False},
    {"label": "WITHDRAWAL", "emoji": DEFAULT_BUTTON_EMOJI["withdrawal"], "style": "danger", "action": "withdrawal", "enabled": True, "admin_only": False},
    {"label": "SUPPORT", "emoji": DEFAULT_BUTTON_EMOJI["support"], "style": "primary", "action": "support", "enabled": True, "admin_only": False},
    {"label": "Admin Panel", "emoji": DEFAULT_BUTTON_EMOJI["admin_panel"], "style": "danger", "action": "admin_panel", "enabled": True, "admin_only": True},
]

# Old labels keep working even after a button is renamed or removed.
LEGACY_MENU_ACTION_BY_TEXT = {
    "get number": "get_number",
    "search number": "search_number",
    "traffic": "traffic",
    "2fa online": "2fa",
    "refer": "refer",
    "withdrawal": "withdrawal",
    "support": "support",
    "admin panel": "admin_panel",
}

# Fixed inline buttons that appear during the user flow. Admins can rename
# them and change/remove their premium emoji from the admin panel.
SYSTEM_BUTTON_DEFAULTS = {
    "close": {"text": "Close", "emoji": "5420130255174145507", "style": "danger"},
    "cancel": {"text": "Cancel", "emoji": "5267490665117275176", "style": "danger"},
    "copy_link": {"text": "COPY LINK", "emoji": "5192739271886282680", "style": "success"},
    "otp_group": {"text": "OTP Group", "emoji": "5190447043545438788", "style": "primary"},
    "change_number": {"text": "Change Number", "emoji": "5420155432272438703", "style": "danger"},
    "change_service": {"text": "Change service", "emoji": "5352922460897452503", "style": "primary"},
    "change_country": {"text": "Change country", "emoji": "5336972142066047577", "style": "primary"},
    "gen_2fa": {"text": "Generate 2fa code", "emoji": "5353022963132174959", "style": "success"},
    "contact_support": {"text": "Contact Support", "emoji": "5337302974806922068", "style": "success"},
}


def sys_button(key, **extra):
    """Build an inline button whose label/emoji can be overridden by the admin."""
    base = SYSTEM_BUTTON_DEFAULTS.get(key, {})
    store = bot_settings.get("system_buttons")
    if not isinstance(store, dict):
        store = {}
    override = store.get(key)
    override = override if isinstance(override, dict) else {}
    button = dict(extra)
    button["text"] = str(override.get("text") or extra.get("text") or base.get("text") or "Button")[:64]
    emoji_id = override["emoji"] if "emoji" in override else (extra.get("emoji") or base.get("emoji"))
    if emoji_id:
        button["icon_custom_emoji_id"] = str(emoji_id)
    button.setdefault("style", base.get("style", "primary"))
    return button


def _system_button_store():
    store = bot_settings.get("system_buttons")
    if not isinstance(store, dict):
        store = {}
        bot_settings["system_buttons"] = store
    return store


# ==========================================
# Local JSON Storage (MongoDB-free)
# ==========================================
# All persistent data is stored on the local filesystem. Set BOT_DATA_DIR if
# you want to keep the files in a different local directory.
try:
    _SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
except Exception:
    _SCRIPT_DIR = os.getcwd()
# Default: a "data" folder right next to bot.py, so the data always stays with the bot
# even when the process is started from another working directory.
DATA_DIR = os.path.join(_SCRIPT_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

BOT_STATE_FILE = os.path.join(DATA_DIR, "bot_state.json")
USERS_DB_FILE = os.path.join(DATA_DIR, "users_db.json")
WITHDRAWALS_DB_FILE = os.path.join(DATA_DIR, "withdrawals_db.json")
KNOWN_USERS_FILE = os.path.join(DATA_DIR, "known_users.json")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
local_db_lock = threading.RLock()

_DATA_FILES = (
    (BOT_STATE_FILE, "{}"),
    (USERS_DB_FILE, "{}"),
    (WITHDRAWALS_DB_FILE, "{}"),
    (KNOWN_USERS_FILE, '{"user_ids": []}'),
)


def ensure_data_storage():
    """Create the data folder and every data file on startup (nothing is lost on first run)."""
    created = []
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
    except Exception as exc:
        print(f"⚠️ Could not create data folder {DATA_DIR}: {exc}")
    for path, default_text in _DATA_FILES:
        if os.path.exists(path):
            continue
        try:
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(default_text)
            created.append(os.path.basename(path))
        except Exception as exc:
            print(f"⚠️ Could not create {path}: {exc}")
    try:
        os.makedirs(BACKUP_DIR, exist_ok=True)
    except Exception:
        pass
    readme = os.path.join(DATA_DIR, "README.txt")
    if not os.path.exists(readme):
        try:
            with open(readme, "w", encoding="utf-8") as handle:
                handle.write(
                    "Bot data folder\n"
                    "=================\n\n"
                    "bot_state.json    - settings, panels, styles, buttons, numbers, stats\n"
                    "users_db.json     - user balances / OTP counts\n"
                    "withdrawals_db.json - withdraw requests\n"
                    "known_users.json  - user ids for broadcast\n\n"
                    "Admin Panel -> 💾 Backup / Restore:\n"
                    "  📥 Download Data File  -> one JSON file with everything\n"
                    "  📤 Import Old Data     -> send that file back to merge old data into this bot\n"
                )
        except Exception:
            pass
    print(f"📁 Data folder ready: {os.path.abspath(DATA_DIR)}" + (f" (created: {', '.join(created)})" if created else ""))
    return created


ensure_data_storage()

bot_settings = {
    "admins": [OWNER_ID],
    "panels": [], 
    "fw_groups": [], 
    "otp_link": "https://t.me/your_otp_group",
    "withdraw_on": True,
    # USDT defaults converted from the former BDT defaults at 125 BDT / USDT.
    "currency": "USDT",
    "min_withdraw": 0.24,
    "otp_reward": 0.0008,
    "refer_reward": 0.0016,
    "cooldown": 10,
    "num_req": 3,
    "num_share": 1, 
    "support_link": "https://t.me/your_support",
    "w_methods": ["USDT (TRC20)", "USDT (BEP20)"],
    "w_group": "", 
    
    "country_otp_rewards": {},
    "fj_on": False,
    "fj_channels": [], 
    "nexa_keys": [], 
    "search_countries": [],
    "nexa_services": {},
    "voltx_services": {},
    "premium_flags": {
        "1": {"char": "🇺🇸", "iso": "US", "name": "United States", "id": "5294244076533600593"},
        "880": {"char": "🇧🇩", "iso": "BD", "name": "Bangladesh", "id": "5291824687096027834"},
        "91": {"char": "🇮🇳", "iso": "IN", "name": "India", "id": "5291933173674957761"},
        "92": {"char": "🇵🇰", "iso": "PK", "name": "Pakistan", "id": "5291825606219029010"},
        "44": {"char": "🇬🇧", "iso": "GB", "name": "United Kingdom", "id": "5293993521026453119"}
    },
    "premium_apps": {
        "FACEBOOK": {"char": "📘", "id": "6217508414193409446", "name": "Facebook"},
        "INSTAGRAM": {"char": "📷", "id": "6217644551771790254", "name": "Instagram"},
        "TIKTOK": {"char": "🎵", "id": "6217225264179453559", "name": "TikTok"},
        "WHATSAPP": {"char": "💬", "id": "6217506429918518926", "name": "WhatsApp"},
        "IMO": {"char": "📞", "id": "5337155807752524558", "name": "Imo"},
        "GOOGLE": {"char": "🌐", "id": "5335010201005231986", "name": "Google"}
    },
    # deepcopy: a shallow copy would let admin edits mutate DEFAULT_CUSTOM_MESSAGES
    "custom_messages": deepcopy(DEFAULT_CUSTOM_MESSAGES),
    "menu_buttons": deepcopy(DEFAULT_MENU_BUTTONS),
    "menu_buttons_per_row": 2,
    "system_buttons": {},
    "migrations": {},
    "otp_styles": [],
    "otp_style_group": "border",
    "otp_style_user": "border",
    "premium_emoji_on": False,
    "waiting_buttons": {},
}

# Pristine copy of the defaults above — "Reset all data" restores exactly this.
_FACTORY_BOT_SETTINGS = deepcopy(bot_settings)


number_batches = {}
used_numbers_list = []
nexa_assigned_numbers = {} 
voltx_assigned_numbers = {}  # 🌟 VoltX number tracking
NEXA_BASE_URL = "http://63.141.255.227"
STEX_DEFAULT_BASE_URL = "https://api.2oo9.cloud/MXS47FLFX0U/tness/@public/api"
NUMBER_API_PANEL_TYPES = {"VoltX Panel", "FastX Panel", "Stex Panel"}
total_uploaded_stats = 0
total_assigned_stats = 0
processed_otps = set()
processed_otps_order = deque()  # FIFO eviction — prevents duplicate OTP delivery after clear
recent_traffic = []
user_banned_cache = {}
otp_received_numbers = set()
OTP_RECEIVED_CAP = 5000  # 🌟 Memory cap — prevents unbounded growth on long-running hosts
otp_received_order = deque()  # tracks insertion order so we can evict the oldest entries

def panel_status(panel):
    """Panel status with a safe default (old / imported panels may not have one)."""
    if not isinstance(panel, dict):
        return "OFF"
    return str(panel.get("status") or "OFF").upper()


def panel_name(panel):
    if not isinstance(panel, dict):
        return "Panel"
    return str(panel.get("name") or "Panel")


def panel_type(panel):
    if not isinstance(panel, dict):
        return "Manual Panel"
    return str(panel.get("type") or "Manual Panel")


def group_buttons(group):
    """Custom buttons of an OTP group, created on demand."""
    if not isinstance(group, dict):
        return []
    buttons = group.get("buttons")
    if not isinstance(buttons, list):
        buttons = []
        group["buttons"] = buttons
    return buttons


def is_number_api_panel(panel):
    return panel.get("type") in NUMBER_API_PANEL_TYPES

def get_number_panel_headers(panel):
    api_key = panel.get("api_key", "").strip()
    if panel.get("type") == "FastX Panel":
        return {"Content-Type": "application/json", "X-API-Key": api_key}
    return {"Content-Type": "application/json", "mauthapi": api_key}

def get_number_panel_url(panel, endpoint):
    base_url = panel.get("base_url", "").strip().rstrip("/")
    configured_url = panel.get(endpoint, "").strip()
    if configured_url:
        return configured_url
    defaults = {
        "getnum_url": "/getnum",
        "getmsg_url": "/success-otp",
        "traffic_url": "/console",
    }
    if panel.get("type") == "FastX Panel":
        defaults = {
            "getnum_url": "/api/getnum",
            "getmsg_url": "/api/success-otp-info",
            "traffic_url": "/api/live-console",
        }
    return f"{base_url}{defaults[endpoint]}" if base_url else ""

def get_panel_services(panel, create=False):
    """Return the service/range map owned by one number API panel."""
    services = panel.get("services")
    if not isinstance(services, dict):
        if not create:
            return {}
        services = {}
        panel["services"] = services
    return services

def get_panel_service_items(panel):
    """Return service entries in a stable order for compact callback ids."""
    return list(get_panel_services(panel).items())

def get_panel_country_items(panel, service):
    services = get_panel_services(panel)
    for service_name, countries in services.items():
        if service_names_equal(service_name, service):
            return list((countries or {}).items())
    return []

def get_number_source_options(service):
    """
    Build every country source separately.

    A country is intentionally not de-duplicated here: the same country from
    two different panels remains two different selectable sources.
    """
    options = []
    local_countries = set()

    for batch in number_batches.values():
        if batch.get("numbers") and service_names_equal(batch.get("service"), service):
            country = canonical_country_name(batch.get("country", ""))
            country_key = normalize_lookup_name(country)
            if country and country_key not in local_countries:
                local_countries.add(country_key)
                options.append({
                    "country": country,
                    "source": "local",
                    "panel_idx": None,
                    "label": "Local Stock",
                })

    for panel_idx, panel in enumerate(bot_settings.get("panels", [])):
        if not is_number_api_panel(panel):
            continue
        for service_name, countries in get_panel_services(panel).items():
            if not service_names_equal(service_name, service):
                continue
            for country_name, ranges in (countries or {}).items():
                if ranges:
                    country = canonical_country_name(country_name)
                    if country:
                        provider = panel.get("type", "Number Panel").replace(" Panel", "")
                        options.append({
                            "country": country,
                            "source": "panel",
                            "panel_idx": panel_idx,
                            "label": panel.get("name") or provider,
                            "provider": provider,
                        })

    # Backward compatibility for installations that have old global VoltX
    # ranges but have not yet created a VoltX panel to migrate them into.
    for service_name, countries in bot_settings.get("voltx_services", {}).items():
        if not service_names_equal(service_name, service):
            continue
        for country_name, ranges in (countries or {}).items():
            if ranges:
                options.append({
                    "country": canonical_country_name(country_name),
                    "source": "legacy_voltx",
                    "panel_idx": None,
                    "label": "VoltX",
                    "provider": "VoltX",
                })

    return options

def get_number_panel_for_source(panel_idx):
    if panel_idx is None:
        return None
    panels = bot_settings.get("panels", [])
    if not isinstance(panel_idx, int) or not (0 <= panel_idx < len(panels)):
        return None
    panel = panels[panel_idx]
    if not is_number_api_panel(panel):
        return None
    return panel

def get_panel_ranges(panel, service, country):
    for service_name, countries in get_panel_services(panel).items():
        if not service_names_equal(service_name, service):
            continue
        for country_name, ranges in (countries or {}).items():
            if country_names_equal(country_name, country):
                return [str(r).strip() for r in (ranges or []) if str(r).strip()]
    return []

def extract_number_from_getnum(payload, raw_text=""):
    """Pull the claimed number out of any getnum response shape.

    Panels are inconsistent: VoltX/Stex return {"meta":{"code":200},"data":{"full_number":..}},
    FastX returns {"data":{"number":..}} or {"number":..}, some return a list or
    even plain text. A successful claim must never be thrown away because of shape.
    """
    found = []

    def push(value):
        if isinstance(value, (str, int)):
            text = str(value).strip()
            if text:
                found.append(text)

    def walk(node, depth=0):
        if depth > 4 or node is None:
            return
        if isinstance(node, dict):
            for key in ("full_number", "fullNumber", "no_plus_number", "number", "phone",
                        "mobile", "msisdn", "num", "phone_number", "activation_number"):
                if key in node:
                    push(node[key])
            for key in ("data", "result", "payload", "response", "numbers", "items", "otp"):
                if key in node:
                    walk(node[key], depth + 1)
        elif isinstance(node, (list, tuple)):
            for item in node[:6]:
                walk(item, depth + 1)
        else:
            push(node)

    walk(payload)
    for value in found:
        digits = re.sub(r"\D", "", value)
        if 8 <= len(digits) <= 16:
            return digits
    if raw_text:
        for match in re.findall(r"\+?\d[\d\s\-]{7,17}", str(raw_text)):
            digits = re.sub(r"\D", "", match)
            if 8 <= len(digits) <= 16:
                return digits
    return ""


def fetch_numbers_from_number_panel(panel, ranges, count):
    """Request numbers only from the panel that owns the selected ranges."""
    if not panel or not panel.get("base_url") or not panel.get("api_key"):
        return [], "Panel is not configured or is missing its API key."
    if panel.get("status") != "ON":
        return [], f"Panel '{panel.get('name', 'Selected panel')}' is OFF."
    if not ranges:
        return [], "No range configured for this panel."

    getnum_url = get_number_panel_url(panel, "getnum_url")
    headers = get_number_panel_headers(panel)
    fetched = []
    errors = []

    def fetch_one(_):
        selected_range = str(random.choice(ranges)).strip()
        if panel.get("type") == "FastX Panel":
            request_body = {"range": selected_range}
        else:
            request_body = {"rid": selected_range.replace("X", "").replace("*", "").strip()}
        try:
            response = requests.post(getnum_url, json=request_body, headers=headers, timeout=15)
        except Exception as exc:
            return None, f"network error: {str(exc)[:80]}", ""
        raw = str(getattr(response, "text", "") or "")
        payload = None
        try:
            payload = response.json()
        except Exception:
            payload = None
        number = extract_number_from_getnum(payload, raw)
        if number:
            return number, "", raw
        if response.status_code != 200:
            return None, f"HTTP {response.status_code}: {raw[:100]}", raw
        message = ""
        if isinstance(payload, dict):
            message = str(payload.get("message") or (payload.get("meta") or {}).get("message") or "")
        return None, (message or f"no number in response: {raw[:100]}"), raw

    with ThreadPoolExecutor(max_workers=min(max(int(count or 1), 1), 5)) as executor:
        futures = [executor.submit(fetch_one, i) for i in range(max(int(count or 1), 1))]
        for future in futures:
            number, error, raw = future.result()
            if number and number not in fetched:
                fetched.append(number)
                panel["last_getnum_raw"] = raw[:300]
                panel["last_getnum_number"] = number
            elif error:
                errors.append(error)
                panel["last_getnum_raw"] = raw[:300]

    panel["last_getnum_at"] = time.time()
    panel["last_getnum_count"] = len(fetched)
    if fetched:
        panel["last_getnum_error"] = ""
        return fetched, ""
    last_error = errors[-1] if errors else "No number available"
    panel["last_getnum_error"] = last_error[:200]
    return [], last_error


def html_to_plain(text):
    """Drop HTML/premium-emoji markup so a plain-text retry can never fail."""
    if not text:
        return ""
    out = re.sub(r"<tg-emoji[^>]*>(.*?)</tg-emoji>", r"\1", str(text), flags=re.S)
    out = re.sub(r"<br\s*/?>", "\n", out, flags=re.I)
    out = re.sub(r"<[^>]+>", "", out)
    return html.unescape(out)


def _safe_telegram_text(text):
    value = "" if text is None else str(text)
    if not value.strip():
        value = "."
    return value[:4096]


def _truncate_callback(value):
    data = str(value)
    raw = data.encode("utf-8")
    if len(raw) <= 64:
        return data
    return raw[:64].decode("utf-8", "ignore")


def sanitize_inline_keyboard(rows, minimal=False):
    """Build a keyboard Telegram can never reject (used as a retry)."""
    clean_rows = []
    action_keys = ("callback_data", "url", "web_app", "login_url",
                   "switch_inline_query", "switch_inline_query_current_chat", "copy_text")
    keep_keys = ("text", "callback_data", "url", "web_app", "login_url",
                 "switch_inline_query", "switch_inline_query_current_chat")
    if not minimal:
        keep_keys = keep_keys + ("copy_text", "icon_custom_emoji_id", "style")
    for row in rows or []:
        if isinstance(row, dict):
            row = [row]
        if not isinstance(row, (list, tuple)):
            continue
        clean_row = []
        for btn in row:
            if not isinstance(btn, dict):
                continue
            item = {k: v for k, v in btn.items() if k in keep_keys}
            text = str(item.get("text") or "").strip()
            if not text:
                continue
            item["text"] = text[:64]
            if "callback_data" in item:
                item["callback_data"] = _truncate_callback(item["callback_data"])
            if "url" in item and not str(item.get("url") or "").strip():
                item.pop("url", None)
            if not any(k in item for k in action_keys):
                item["callback_data"] = "ignore"
            clean_row.append(item)
        if clean_row:
            clean_rows.append(clean_row)
    return {"inline_keyboard": clean_rows[:100]}


def describe_telegram_error(result):
    if not isinstance(result, dict):
        return "no response from Telegram"
    return str(result.get("description") or result.get("error") or "unknown Telegram error")[:200]


def show_inline_message(chat_id, message_id, text, keyboard, panel=None, text_without_buttons=None):
    """Show a message reliably: edit -> sanitized edit -> plain-text edit -> new send.

    Returns (ok, message_id, error, attempt). Never leaves the user with a claimed
    number and no visible message.
    """
    rows = keyboard.get("inline_keyboard", []) if isinstance(keyboard, dict) else (keyboard or [])
    full_kb = {"inline_keyboard": rows}
    plain_text = html_to_plain(text)
    attempts = [
        ("edit#1 full keyboard", "edit", full_kb, text, "HTML"),
        ("edit#2 sanitized keyboard", "edit", sanitize_inline_keyboard(rows, minimal=False), text, "HTML"),
        ("edit#3 plain text", "edit", sanitize_inline_keyboard(rows, minimal=True), plain_text, None),
    ]
    last_error = ""
    if message_id:
        for label, _kind, kbd, body, mode in attempts:
            res = edit_message(chat_id, message_id, body, reply_markup=kbd, parse_mode=mode) if mode else edit_message(chat_id, message_id, body, reply_markup=kbd, parse_mode=None)
            if res.get("ok"):
                return True, message_id, "", label
            last_error = describe_telegram_error(res)
            if "not modified" in last_error.lower():
                return True, message_id, "", label
    send_attempts = [
        ("new message#1", sanitize_inline_keyboard(rows, minimal=False), text, "HTML"),
        ("new message#2 plain", sanitize_inline_keyboard(rows, minimal=True), plain_text, None),
        ("new message#3 text only", None, html_to_plain(text_without_buttons or text), None),
    ]
    for label, kbd, body, mode in send_attempts:
        res = send_message(chat_id, body, reply_markup=kbd, parse_mode=mode) if mode else send_message(chat_id, body, reply_markup=kbd, parse_mode=None)
        if res.get("ok"):
            new_id = (res.get("result") or {}).get("message_id") or message_id
            return True, new_id, last_error, label
        last_error = describe_telegram_error(res)
    if panel is not None:
        panel["last_display_error"] = last_error[:300]
        panel["last_display_error_at"] = time.time()
    print(f"❌ Could not display waiting screen for {chat_id}: {last_error}")
    return False, message_id, last_error, "failed"


def _custom_message_text(key, fallback=""):
    entry = (bot_settings.get("custom_messages") or {}).get(key) or {}
    text = entry.get("text") if isinstance(entry, dict) else None
    if text is None or not str(text).strip():
        text = (DEFAULT_CUSTOM_MESSAGES.get(key) or {}).get("text", fallback)
    return str(text)


def session_numbers_text(session):
    """Numbers formatted for a message body (respects the CC toggle)."""
    session = session or {}
    remove_cc = bool(session.get("remove_cc"))
    parts = []
    for num in session.get("nums", []) or []:
        value = format_waiting_number(num, remove_cc=remove_cc)
        if value:
            parts.append(f"<code>{html.escape(value)}</code>")
    return " · ".join(parts)


def waiting_screen_text(session, force_numbers=False):
    """Waiting screen body.

    The numbers live on the buttons. The text only gets the numbers when
    force_numbers=True (last-resort plain message) or when the admin put the
    {numbers} placeholder inside the editable template.
    """
    session = session or {}
    numbers = session_numbers_text(session)
    template = _custom_message_text("waiting")
    text = (
        str(template)
        .replace("{numbers}", numbers)
        .replace("{count}", str(len(session.get("nums") or [])))
        .replace("{service}", str(session.get("service") or ""))
        .replace("{country}", str(session.get("country") or ""))
    )
    if force_numbers and numbers and "{numbers}" not in str(template):
        text = text.rstrip() + f"\n📱 {numbers}"
    return render_body_text(text)


def waiting_expired_text():
    return render_body_text(_custom_message_text("waiting_expired"))


def _insert_waiting_custom_buttons(kb, session):
    """Append the admin-defined inline buttons of the Waiting message."""
    if not waiting_action_enabled("custom"):
        return kb
    entry = (bot_settings.get("custom_messages") or {}).get("waiting") or {}
    buttons = entry.get("buttons") if isinstance(entry, dict) else None
    if not buttons:
        return kb
    rows = [row for row in (kb or []) if isinstance(row, list)]
    extra = []
    for btn in buttons:
        if not isinstance(btn, dict):
            continue
        item = dict(btn)
        item.setdefault("style", "primary")
        extra.append([item])
    if not extra:
        return rows
    close_index = None
    for idx, row in enumerate(rows):
        if any(isinstance(b, dict) and b.get("callback_data") == "close_msg" for b in row):
            close_index = idx
            break
    if close_index is None:
        return rows + extra
    return rows[:close_index] + extra + rows[close_index:]


def show_waiting_screen(chat_id, message_id, kb, session, panel=None):
    """Render the Waiting-For-SMS screen and keep the real message id."""
    text = waiting_screen_text(session)
    kb = _insert_waiting_custom_buttons(kb, session)
    ok, new_id, error, attempt = show_inline_message(
        chat_id, message_id, text, kb, panel=panel,
        text_without_buttons=waiting_screen_text(session, force_numbers=True),
    )
    store = dict(session or {})
    store["display_attempt"] = attempt
    store["display_error"] = error
    if ok:
        store["msg_id"] = new_id or message_id
        user_active_sessions[chat_id] = store
        if panel is not None:
            panel["last_display_error"] = ""
            panel["last_display_attempt"] = attempt
            panel["last_display_at"] = time.time()
        print(f"✅ Waiting screen shown to {chat_id} via {attempt} (numbers: {', '.join(store.get('nums') or []) or 'none'})")
    else:
        user_active_sessions[chat_id] = store
        if panel is not None:
            panel["last_display_error"] = error[:300]
            panel["last_display_error_at"] = time.time()
    return ok, error


def getnum_probe_text(panel_idx, chat_id):
    """Admin test: claim one number from a panel and show the raw response."""
    panels = bot_settings.get("panels", [])
    if not isinstance(panel_idx, int) or not (0 <= panel_idx < len(panels)):
        return "❌ Panel not found."
    panel = panels[panel_idx]
    if not is_number_api_panel(panel):
        return "❌ This is not a FastX / VoltX / Stex panel."
    ranges = []
    for _service, countries in get_panel_services(panel).items():
        for _country, values in (countries or {}).items():
            ranges.extend([str(v).strip() for v in (values or []) if str(v).strip()])
    lines = [f"🧪 <b>GET-NUM TEST — {html.escape(str(panel.get('name', 'Panel')))}</b>", "━" * 16]
    if not ranges:
        lines.append("⚠️ No range configured for this panel.")
        lines.append("Add Panel → 🔧 Manage Services → service → country → range first.")
        return render_body_text("\n".join(lines))
    lines.append("⚠️ <i>This asks the panel for 1 real number, so 1 number will be claimed.</i>")
    numbers, error = fetch_numbers_from_number_panel(panel, ranges, 1)
    raw = str(panel.get("last_getnum_raw") or "")
    lines.append(f"🔗 <code>{html.escape(get_number_panel_url(panel, 'getnum_url'))}</code>")
    lines.append(f"📄 Raw: <code>{html.escape(raw[:280] or 'empty response')}</code>")
    if numbers:
        lines.append(f"✅ Parsed number: <code>+{html.escape(numbers[0])}</code>")
    else:
        lines.append(f"❌ No number parsed → <code>{html.escape(str(error)[:160])}</code>")
    lines.append("")
    lines.append("📨 <b>Telegram display test:</b>")
    kb = {"inline_keyboard": [
        [{"text": "← Display test button", "callback_data": "ignore", "style": "success"}],
        otp_group_row(),
    ]}
    ok, _new_id, disp_error, disp_attempt = show_inline_message(chat_id, None, "Display test: bot can show a waiting screen ✅", kb)
    if ok:
        lines.append(f"✅ A test message was shown above ({html.escape(disp_attempt)}) → Telegram side is fine.")
    else:
        lines.append(f"❌ Telegram rejected the message → <code>{html.escape(str(disp_error)[:200])}</code>")
    return render_body_text("\n".join(lines))


# ==========================================
# Test Simulation State
# ==========================================
# Keyed by sim_id -> {flag, iso, platform, dial_code, lang, stop_event, running, total_sent, start_time}
active_test_simulations = {}

def _track_processed_otp(uid):
    """Add a unique_id to processed_otps with FIFO eviction (no dangerous clear())."""
    global processed_otps, processed_otps_order
    processed_otps.add(uid)
    processed_otps_order.append(uid)
    while len(processed_otps_order) > 5000:
        oldest = processed_otps_order.popleft()
        processed_otps.discard(oldest)

def _track_otp_received(num):
    """Add a number to otp_received_numbers with a hard memory cap (FIFO eviction)."""
    global otp_received_numbers, otp_received_order
    if not num or num in otp_received_numbers:
        return
    otp_received_numbers.add(num)
    otp_received_order.append(num)
    while len(otp_received_order) > OTP_RECEIVED_CAP:
        oldest = otp_received_order.popleft()
        otp_received_numbers.discard(oldest)

panel_warmup_done = False
nexa_warmup_done = False

# Active HTTP sessions for Auto Captcha Panels
panel_sessions = {}

def _normalize_panel_url(value):
    value = (value or "").strip()
    if value and not value.startswith(("http://", "https://")):
        value = "http://" + value
    return value

def _default_panel_check_url(login_url):
    login_url = _normalize_panel_url(login_url)
    parsed = urlparse(login_url)
    path = parsed.path or ""
    login_pos = path.lower().find("/login")
    base_path = path[:login_pos] if login_pos >= 0 else path.rsplit("/", 1)[0]
    base = f"{parsed.scheme}://{parsed.netloc}{base_path.rstrip('/')}"
    return f"{base}/client/SMSCDRStats"

def _response_is_login_page(response):
    if response.status_code in (401, 403):
        return True

    final_url = str(getattr(response, "url", "")).lower()
    final_path = urlparse(final_url).path.lower()
    if re.search(r"/(?:login|signin)(?:\.php)?/?$", final_path):
        return True

    try:
        soup = BeautifulSoup(response.text, "html.parser")
        visible_text = soup.get_text(" ", strip=True).lower()
        has_password_input = bool(soup.find("input", {"type": "password"}))
        explicit_login_text = any(phrase in visible_text for phrase in (
            "sign in to your account",
            "please sign in",
            "login to your account",
            "invalid username or password",
        ))
        return has_password_input and explicit_login_text
    except Exception:
        return False

# 🌟 sAjaxSource (AJAX/DataTable) and Fallback HTML Parser Helper Function
def fetch_cpt_panel_cdrs(p, session, check_url):
    check_url = _normalize_panel_url(check_url) or _default_panel_check_url(p.get("login_url", ""))
    res = session.get(check_url, headers={"Referer": check_url}, timeout=15)
    html_text = res.text
    
    # Check if session expired or redirected to login page
    if _response_is_login_page(res):
        raise Exception("Session expired")
        
    soup = BeautifulSoup(html_text, 'html.parser')

    # Count columns from HTML table header (to set iColumns correctly)
    detected_col_count = 7
    for table in soup.find_all('table'):
        header_rows = table.find_all('tr')
        if header_rows:
            first_row_cols = header_rows[0].find_all(['th', 'td'])
            if len(first_row_cols) > detected_col_count:
                detected_col_count = len(first_row_cols)
                break

    s_ajax_source = ""
    for script in soup.find_all("script"):
        script_text = script.string or ""
        # Pattern 1: sAjaxSource (legacy DataTables)
        match = re.search(r'sAjaxSource"?\s*:\s*"([^"]+)"', script_text)
        if match:
            s_ajax_source = match.group(1)
            break
        # Pattern 2: ajax: "url" (DataTables 1.10+)
        match = re.search(r'["\']ajax["\']\s*:\s*["\']([^"\']+)["\']', script_text)
        if match:
            s_ajax_source = match.group(1)
            break
        # Pattern 3: ajax: { url: "..." }
        match = re.search(r'["\']?ajax["\']?\s*:\s*\{[^}]*["\']?url["\']?\s*:\s*["\']([^"\']+)["\']', script_text)
        if match:
            s_ajax_source = match.group(1)
            break
        # Pattern 4: url: "..." inside DataTable/dataTable call context
        if 'DataTable' in script_text or 'dataTable' in script_text:
            match = re.search(r'"url"\s*:\s*"([^"]+)"', script_text)
            if match:
                s_ajax_source = match.group(1)
                break
            
    results = []
    
    n_col_name = p.get("num_col_name", "number").lower()
    m_col_name = p.get("msg_col_name", "message").lower()
    n_idx = int(p.get("num_col_idx", 1)) - 1 if p.get("num_col_idx") else 1
    m_idx = int(p.get("msg_col_idx", 2)) - 1 if p.get("msg_col_idx") else 2

    # 5.1 If sAjaxSource AJAX link is found
    if s_ajax_source:
        baseUrl = p.get("login_url", "").split("/client")[0].split("/login")[0].strip()
        if not baseUrl.startswith("http"):
            baseUrl = "http://" + baseUrl
            
        full_ajax_url = ""
        if s_ajax_source.startswith("http"):
            full_ajax_url = s_ajax_source
        elif s_ajax_source.startswith("/"):
            full_ajax_url = f"{baseUrl}{s_ajax_source}"
        else:
            last_slash_idx = check_url.rfind("/")
            if last_slash_idx > 0:
                current_dir = check_url[:last_slash_idx]
            else:
                current_dir = check_url.rstrip("/")
            full_ajax_url = f"{current_dir}/{s_ajax_source}"

        if "iDisplayLength" not in full_ajax_url:
            col_search = "&".join([f"sSearch_{i}=&bRegex_{i}=false&bSearchable_{i}=true&bSortable_{i}=true" for i in range(detected_col_count)])
            query_params = f"sEcho=1&iColumns={detected_col_count}&iDisplayStart=0&iDisplayLength=9999&sSearch=&bRegex=false&iSortingCols=1&iSortCol_0=0&sSortDir_0=desc&{col_search}"
            divider = "&" if "?" in full_ajax_url else "?"
            full_ajax_url += f"{divider}{query_params}"

        ajax_headers = {
            "Referer": check_url,
            "X-Requested-With": "XMLHttpRequest"
        }
        
        ajax_res = session.get(full_ajax_url, headers=ajax_headers, timeout=15)
        if _response_is_login_page(ajax_res):
            raise Exception("Session expired")
        # Rate limit detection — wait and retry once
        rate_limit_phrases = ["too many times", "try again", "rate limit", "slow down", "429", "blocked"]
        if not ajax_res.text.strip():
            raise Exception("AJAX URL returned empty response. Check your Msg Link / check_url setting.")
        if any(ph in ajax_res.text.lower() for ph in rate_limit_phrases) and ajax_res.text.strip()[0] != '{':
            time.sleep(6)
            ajax_res = session.get(full_ajax_url, headers=ajax_headers, timeout=15)
        try:
            data_dict = ajax_res.json()
        except Exception:
            raise Exception(f"AJAX response is not valid JSON. Got: {ajax_res.text[:120]!r}")
        rows = data_dict.get("aaData", [])
        for row_val in rows:
            if not isinstance(row_val, list):
                continue
                
            if len(row_val) < max(n_idx, m_idx) + 1:
                continue
                
            num_val = row_val[n_idx] if (0 <= n_idx < len(row_val)) else row_val[2]
            msg_val = row_val[m_idx] if (0 <= m_idx < len(row_val)) else row_val[4]
            
            clean_num = re.sub(r'\D', '', str(num_val))
            if clean_num and 5 <= len(clean_num) <= 18:
                otp = extract_otp_code(msg_val)
                if otp and len(msg_val) > 4:
                    results.append({"number": clean_num, "message": msg_val, "otp": otp})
                    
    else:
        # 5.2 Backup logic to read from direct HTML table
        tables = soup.find_all('table')
        for table in tables:
            rows = table.find_all('tr')
            if not rows: continue
            
            final_n_idx = n_idx
            final_m_idx = m_idx
            
            header_cells = rows[0].find_all(['th', 'td'])
            for i, cell in enumerate(header_cells):
                c_text = cell.get_text(strip=True).lower()
                if n_col_name in c_text: final_n_idx = i
                if m_col_name in c_text: final_m_idx = i

            for row in rows:
                cols = row.find_all(['td', 'th'])
                if all(c.name == 'th' for c in cols): continue
                
                if len(cols) > max(final_n_idx, final_m_idx):
                    num_text = cols[final_n_idx].get_text(separator=" ", strip=True)
                    msg_text = cols[final_m_idx].get_text(separator=" ", strip=True)
                    
                    clean_num = re.sub(r'\D', '', num_text)
                    if clean_num and 5 <= len(clean_num) <= 18:
                        otp = extract_otp_code(msg_text)
                        if otp and len(msg_text) > 4:
                            results.append({"number": clean_num, "message": msg_text, "otp": otp})
                            
    return results, html_text

# Track active number sessions to expire them automatically
user_active_sessions = {}

def _apply_state_data(data):
    global bot_settings, number_batches, used_numbers_list, total_uploaded_stats, total_assigned_stats, recent_traffic, nexa_assigned_numbers, voltx_assigned_numbers, otp_received_numbers, otp_received_order
    saved_settings = data.get("bot_settings", {})
    for key, val in saved_settings.items():
        if key == "custom_messages":
            for m_key, m_val in val.items():
                bot_settings["custom_messages"][m_key] = m_val
        elif key == "premium_apps":
            for app_key, app_val in val.items():
                bot_settings["premium_apps"][app_key] = app_val
        else:
            bot_settings[key] = val

    for m_key, m_val in DEFAULT_CUSTOM_MESSAGES.items():
        if m_key not in bot_settings["custom_messages"]:
            bot_settings["custom_messages"][m_key] = m_val

    # Main menu buttons: keep stored config valid after every upgrade.
    stored_buttons = bot_settings.get("menu_buttons")
    cleaned_buttons = []
    if isinstance(stored_buttons, list):
        for item in stored_buttons:
            if not isinstance(item, dict):
                continue
            action = str(item.get("action", "")).strip()
            if action not in MENU_ACTION_LABELS:
                continue
            button = deepcopy(item)
            button["label"] = str(button.get("label") or MENU_ACTION_LABELS[action]).strip()[:64]
            if not button["label"]:
                button["label"] = MENU_ACTION_LABELS[action]
            if button.get("style") not in ("primary", "success", "danger"):
                button["style"] = "primary"
            button["enabled"] = bool(button.get("enabled", True))
            button["admin_only"] = bool(button.get("admin_only", action == "admin_panel"))
            cleaned_buttons.append(button)
    bot_settings["menu_buttons"] = cleaned_buttons or deepcopy(DEFAULT_MENU_BUTTONS)
    try:
        per_row = int(bot_settings.get("menu_buttons_per_row", 2))
    except (TypeError, ValueError):
        per_row = 2
    bot_settings["menu_buttons_per_row"] = max(1, min(2, per_row))

    number_batches = data.get("number_batches", {})
    used_numbers_list = data.get("used_numbers_list", [])
    total_uploaded_stats = data.get("total_uploaded_stats", 0)
    total_assigned_stats = data.get("total_assigned_stats", 0)
    recent_traffic = data.get("recent_traffic", [])
    nexa_assigned_numbers = data.get("nexa_assigned_numbers", {})
    voltx_assigned_numbers = data.get("voltx_assigned_numbers", {})
    loaded_otp_nums = data.get("otp_received_numbers", [])
    if len(loaded_otp_nums) > OTP_RECEIVED_CAP:
        loaded_otp_nums = loaded_otp_nums[-OTP_RECEIVED_CAP:]
    otp_received_numbers = set(loaded_otp_nums)
    otp_received_order = deque(loaded_otp_nums)

    migrated = False
    new_fj = []
    for entry in bot_settings.get("fj_channels", []):
        if isinstance(entry, str):
            new_fj.append({"chat_id": entry, "type": "channel", "title": entry, "invite_link": "", "is_private": False})
            migrated = True
        else:
            new_fj.append(entry)
    if migrated:
        bot_settings["fj_channels"] = new_fj

    # Keep each number API's services/ranges attached to that exact panel.
    # Older versions stored all of them in one global VoltX map, so migrate
    # that map to the first VoltX panel when possible instead of letting
    # FastX accidentally consume VoltX ranges.
    panels_migrated = False
    if not isinstance(bot_settings.get("panels"), list):
        bot_settings["panels"] = []
        panels_migrated = True
    for panel in bot_settings.get("panels", []):
        if not isinstance(panel, dict):
            continue
        # Old / imported panel records may miss keys the menus read directly.
        for key, default in (("name", "Panel"), ("type", "Manual Panel"), ("status", "OFF")):
            if key not in panel or panel[key] in (None, ""):
                panel[key] = default
                panels_migrated = True
        if is_number_api_panel(panel) and not isinstance(panel.get("services"), dict):
            panel["services"] = {}
            panels_migrated = True
    # Same for OTP groups: every group needs a style and a buttons list.
    if not isinstance(bot_settings.get("fw_groups"), list):
        bot_settings["fw_groups"] = []
        panels_migrated = True
    for group in bot_settings.get("fw_groups", []):
        if not isinstance(group, dict):
            continue
        if not group.get("style"):
            group["style"] = "auto"
            panels_migrated = True
        if not isinstance(group.get("buttons"), list):
            group["buttons"] = []
            panels_migrated = True
    legacy_services = bot_settings.get("voltx_services", {})
    if isinstance(legacy_services, dict) and legacy_services:
        legacy_target = next(
            (
                panel for panel in bot_settings.get("panels", [])
                if panel.get("type") == "VoltX Panel"
                and not get_panel_services(panel)
            ),
            None,
        )
        if legacy_target is not None:
            legacy_target["services"] = deepcopy(legacy_services)
            bot_settings["voltx_services"] = {}
            panels_migrated = True
    if panels_migrated:
        save_local_db()

    # One-shot legacy payment-method migration. It must run only once, otherwise every
    # restart would overwrite the admin's own Bengali/USDT texts with defaults.
    migrations = bot_settings.get("migrations")
    if not isinstance(migrations, dict):
        migrations = {}
    if not migrations.get("bdt_text_v1"):
        inr_migrated = False
        old_methods = bot_settings.get("w_methods", [])
        if any(str(m).lower() in ("upi", "paytm") for m in old_methods):
            bot_settings["w_methods"] = ["USDT (TRC20)", "USDT (BEP20)"]
            inr_migrated = True
        cm = bot_settings.get("custom_messages", {})
        for m_key in cm:
            if isinstance(cm[m_key], dict) and "text" in cm[m_key]:
                txt = str(cm[m_key]["text"])
                if "₹" in txt or "INR" in txt:
                    if m_key in DEFAULT_CUSTOM_MESSAGES:
                        cm[m_key]["text"] = DEFAULT_CUSTOM_MESSAGES[m_key]["text"]
                        inr_migrated = True
        if inr_migrated:
            bot_settings["custom_messages"] = cm
            print("🔄 Updated legacy withdrawal methods to USDT!")
        migrations["bdt_text_v1"] = True
        bot_settings["migrations"] = migrations
        save_local_db()

    # One-shot: put the default premium flag pack (build r13) in place. Afterwards the
    # admin can freely override flags again without this migration touching them.
    if not migrations.get("flag_emoji_pack_v1"):
        flag_added, flag_updated = seed_flag_emojis(force=True)
        migrations["flag_emoji_pack_v1"] = True
        bot_settings["migrations"] = migrations
        save_local_db()
        print(f"🔄 Default flag emoji pack applied (added {flag_added}, updated {flag_updated})")

def load_db():
    try:
        state_file = BOT_STATE_FILE if os.path.exists(BOT_STATE_FILE) else LEGACY_DB_FILE
        if os.path.exists(state_file):
            with open(state_file, "r", encoding="utf-8") as f:
                state_data = json.load(f)
            state_data.pop("_id", None)
            _apply_state_data(state_data)
            if state_file == LEGACY_DB_FILE:
                save_local_db()
                print("🔄 Migrated legacy bot data to local JSON storage.")
        print("✅ Local state loaded successfully!")
    except Exception as e:
        raise RuntimeError(f"Local state load failed: {e}") from e


def _atomic_json_write(path, data):
    """Write JSON safely so a process interruption cannot corrupt the DB file."""
    temp_path = f"{path}.tmp"
    with open(temp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp_path, path)

def save_local_db():
    state_doc = {
        "bot_settings": bot_settings,
        "number_batches": number_batches,
        "used_numbers_list": used_numbers_list,
        "total_uploaded_stats": total_uploaded_stats,
        "total_assigned_stats": total_assigned_stats,
        "recent_traffic": recent_traffic,
        "nexa_assigned_numbers": nexa_assigned_numbers,
        "voltx_assigned_numbers": voltx_assigned_numbers,
        "otp_received_numbers": list(otp_received_numbers) if otp_received_numbers else [],
    }
    try:
        with local_db_lock:
            _atomic_json_write(BOT_STATE_FILE, state_doc)
    except Exception as e:
        print(f"⚠️ Local state save failed: {e}")

def save_db():
    save_local_db()

load_db()
try:
    _flag_added, _flag_updated = seed_flag_emojis()
    if _flag_added or _flag_updated:
        print(f"🚩 Default flag pack: {_flag_added} added, {_flag_updated} filled")
        save_local_db()
except Exception as _flag_err:
    print(f"⚠️ Flag pack seed skipped: {_flag_err}")

user_states = {}
temp_data = {}
user_cooldowns = {}
pending_withdrawals = {}

# ==========================================
# Telegram API & Helpers
# ==========================================
tg_session = requests.Session() # 🌟 Keep-Alive Connection (Makes bot 10x faster)

def api_call(method, payload=None):
    url = f"{BASE_URL}/{method}"
    try:
        # 🌟 Added timeout to prevent hanging!
        res = tg_session.post(url, json=payload, timeout=15)
        return res.json()
    except Exception as e:
        return {}

def _unicode_bold_text(value):
    """Render user-visible Latin text in Unicode bold while preserving HTML tags and URLs."""
    import re as _re
    chars = {}
    for i, ch in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
        chars[ch] = chr(0x1D400 + i)
    for i, ch in enumerate("abcdefghijklmnopqrstuvwxyz"):
        chars[ch] = chr(0x1D41A + i)
    for i, ch in enumerate("0123456789"):
        chars[ch] = chr(0x1D7CE + i)
    text = str(value or "")
    parts = _re.split(r'(<[^>]*>|https?://\S+)', text)
    return "".join(part if (part.startswith("<") and part.endswith(">")) or part.startswith(("http://", "https://")) else "".join(chars.get(c, c) for c in part) for part in parts)


def _bold_keyboard_markup(markup):
    """Bold visible labels in inline/reply keyboard buttons without changing callbacks."""
    if not isinstance(markup, dict):
        return markup
    result = dict(markup)
    for key in ("inline_keyboard", "keyboard"):
        rows = result.get(key)
        if not isinstance(rows, list):
            continue
        new_rows = []
        for row in rows:
            if isinstance(row, list):
                new_rows.append([dict(btn, text=_unicode_bold_text(btn.get("text", ""))) if isinstance(btn, dict) and "text" in btn else btn for btn in row])
            elif isinstance(row, dict) and "text" in row:
                new_rows.append(dict(row, text=_unicode_bold_text(row.get("text", ""))))
            else:
                new_rows.append(row)
        result[key] = new_rows
    return result


def send_message(chat_id, text, reply_markup=None, parse_mode="HTML"):
    rendered_text = _unicode_bold_text(_safe_telegram_text(text))
    payload = {"chat_id": chat_id, "text": rendered_text, "disable_web_page_preview": True}
    if parse_mode: payload["parse_mode"] = parse_mode
    if reply_markup: payload["reply_markup"] = _bold_keyboard_markup(reply_markup)
    return api_call("sendMessage", payload)

def send_photo(chat_id, photo_url_or_file_id, caption="", reply_markup=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "photo": photo_url_or_file_id, "caption": _unicode_bold_text(caption), "parse_mode": parse_mode}
    if reply_markup: payload["reply_markup"] = _bold_keyboard_markup(reply_markup)
    return api_call("sendPhoto", payload)

def edit_message(chat_id, message_id, text, reply_markup=None, parse_mode="HTML"):
    payload = {"chat_id": chat_id, "message_id": message_id, "text": _unicode_bold_text(_safe_telegram_text(text)), "disable_web_page_preview": True}
    if parse_mode: payload["parse_mode"] = parse_mode
    if reply_markup: payload["reply_markup"] = _bold_keyboard_markup(reply_markup)
    return api_call("editMessageText", payload)

def delete_message(chat_id, message_id):
    return api_call("deleteMessage", {"chat_id": chat_id, "message_id": message_id})

def answer_callback(callback_id, text="", show_alert=False):
    api_call("answerCallbackQuery", {"callback_query_id": callback_id, "text": text, "show_alert": show_alert})

def send_document(chat_id, filename, text_content):
    url = f"{BASE_URL}/sendDocument"
    files = {'document': (filename, text_content)}
    data = {'chat_id': chat_id}
    try: requests.post(url, data=data, files=files, timeout=20)
    except Exception as e:
        print(f"⚠️ send_document failed: {e}")

# 🌟 Local User List for Broadcasts
all_known_users = set()

def sync_users_list():
    global all_known_users
    try:
        if os.path.exists(KNOWN_USERS_FILE):
            with open(KNOWN_USERS_FILE, "r", encoding="utf-8") as f:
                known_data = json.load(f)
            all_known_users = set(str(uid) for uid in known_data.get("user_ids", []))
        if not all_known_users:
            all_known_users = set(str(uid) for uid in globals().get("local_users_db", {}).keys())
        if all_known_users:
            _save_users_list()
    except Exception as e:
        print(f"⚠️ Failed to load known users list: {e}")

def _save_users_list():
    try:
        with local_db_lock:
            _atomic_json_write(KNOWN_USERS_FILE, {"user_ids": sorted(all_known_users)})
    except Exception as e:
        print(f"⚠️ Failed to save known users list: {e}")

def register_user_local(uid):
    uid_str = str(uid)
    if uid_str not in all_known_users:
        all_known_users.add(uid_str)
        _get_local_user(uid)
        # 🌟 Non-blocking background save (Prevents lag)
        threading.Thread(target=_save_users_list, daemon=True).start()


# ==========================================
# 🌟 Local User and Withdrawal Databases
# ==========================================
local_users_db = {}
local_withdrawals_db = {}

def _load_local_users_db():
    global local_users_db, local_withdrawals_db
    try:
        source_file = USERS_DB_FILE if os.path.exists(USERS_DB_FILE) else "users_db.json"
        if os.path.exists(source_file):
            with open(source_file, "r", encoding="utf-8") as f:
                saved_users = json.load(f)
            for uid, user_data in saved_users.items():
                local_users_db[str(uid)] = dict(user_data)
    except Exception as e:
        print(f"⚠️ Failed to load users DB: {e}")
    try:
        source_file = WITHDRAWALS_DB_FILE if os.path.exists(WITHDRAWALS_DB_FILE) else "withdrawals_db.json"
        if os.path.exists(source_file):
            with open(source_file, "r", encoding="utf-8") as f:
                saved_withdrawals = json.load(f)
            for req_id, withdrawal_data in saved_withdrawals.items():
                local_withdrawals_db[str(req_id)] = dict(withdrawal_data)
    except Exception as e:
        print(f"⚠️ Failed to load withdrawals DB: {e}")

def _save_local_users_db():
    try:
        with local_db_lock:
            _atomic_json_write(USERS_DB_FILE, local_users_db)
    except Exception as e:
        print(f"⚠️ Failed to save users DB: {e}")

def _save_local_withdrawals_db():
    try:
        with local_db_lock:
            _atomic_json_write(WITHDRAWALS_DB_FILE, local_withdrawals_db)
    except Exception as e:
        print(f"⚠️ Failed to save withdrawals DB: {e}")

_load_local_users_db()
sync_users_list()

def _get_local_user(user_id):
    uid = str(user_id)
    if uid not in local_users_db:
        local_users_db[uid] = {"user_id": int(user_id), "balance": 0.0, "total_refers": 0, "total_otps": 0, "banned": False, "verified": False}
        threading.Thread(target=_save_local_users_db, daemon=True).start()
    return local_users_db[uid]

def _update_local_user(user_id, updates):
    uid = str(user_id)
    if uid not in local_users_db:
        _get_local_user(user_id)
    local_users_db[uid].update(updates)
    threading.Thread(target=_save_local_users_db, daemon=True).start()

def _increment_local_user(user_id, field, amount):
    uid = str(user_id)
    if uid not in local_users_db:
        _get_local_user(user_id)
    local_users_db[uid][field] = local_users_db[uid].get(field, 0) + amount
    threading.Thread(target=_save_local_users_db, daemon=True).start()

def _local_user_exists(user_id):
    return str(user_id) in local_users_db

def _save_local_withdrawal(req_id, data):
    local_withdrawals_db[req_id] = data
    local_withdrawals_db[req_id]["timestamp"] = time.time()
    threading.Thread(target=_save_local_withdrawals_db, daemon=True).start()

def _update_local_withdrawal(req_id, updates):
    if req_id in local_withdrawals_db:
        local_withdrawals_db[req_id].update(updates)
        threading.Thread(target=_save_local_withdrawals_db, daemon=True).start()

# ==========================================
# 💾 Backup / Restore (download + import old data)
# ==========================================

def _backup_state_doc():
    return {
        "bot_settings": bot_settings,
        "number_batches": number_batches,
        "used_numbers_list": used_numbers_list,
        "total_uploaded_stats": total_uploaded_stats,
        "total_assigned_stats": total_assigned_stats,
        "recent_traffic": recent_traffic,
        "nexa_assigned_numbers": nexa_assigned_numbers,
        "voltx_assigned_numbers": voltx_assigned_numbers,
        "otp_received_numbers": list(otp_received_numbers) if otp_received_numbers else [],
    }


def build_backup_bundle():
    """Everything the admin needs, in one JSON document."""
    return {
        "app": "telegram-otp-bot",
        "build": BOT_BUILD,
        "exported_at": time.time(),
        "exported_at_text": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "counts": {
            "users": len(local_users_db),
            "withdrawals": len(local_withdrawals_db),
            "known_users": len(all_known_users),
            "number_files": len(number_batches),
        },
        "bot_state": _backup_state_doc(),
        "users_db": local_users_db,
        "withdrawals_db": local_withdrawals_db,
        "known_user_ids": sorted(all_known_users),
    }


def backup_file_name():
    return f"bot_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"


def backup_json_text():
    return json.dumps(build_backup_bundle(), ensure_ascii=False, indent=2)


def _backup_split(bundle):
    """Accept our bundle, a raw bot_state.json, or a raw users_db.json."""
    if not isinstance(bundle, dict):
        return {}, {}, {}, []
    state = bundle.get("bot_state") if isinstance(bundle.get("bot_state"), dict) else None
    users = bundle.get("users_db") if isinstance(bundle.get("users_db"), dict) else None
    withdrawals = bundle.get("withdrawals_db") if isinstance(bundle.get("withdrawals_db"), dict) else None
    known = bundle.get("known_user_ids") if isinstance(bundle.get("known_user_ids"), list) else []
    if state is None and isinstance(bundle.get("bot_settings"), dict):
        state = bundle
    if users is None and isinstance(bundle.get("users"), dict):
        users = bundle["users"]
    # A bare users_db.json has only numeric keys.
    if users is None and state is None and bundle and all(str(k).isdigit() for k in bundle.keys()):
        users = bundle
    return state or {}, users or {}, withdrawals or {}, known


def _list_item_identity(item):
    """How to recognise the same panel / group / style / number inside a list."""
    if isinstance(item, dict):
        for field in ("chat_id", "id", "name"):
            value = item.get(field)
            if value not in (None, ""):
                return (field, str(value))
        try:
            return ("json", json.dumps(item, sort_keys=True, ensure_ascii=False, default=str))
        except Exception:
            return ("repr", repr(item))
    return ("value", str(item))


def _merge_dict_fill(target, source, depth=0):
    """Add everything that is missing in `target`; current values are never overwritten.

    This is a pure ADD operation: nothing in `target` is ever removed or replaced, so an
    import can never wipe a balance, a withdraw record or a setting.
    """
    added = kept = 0
    if not isinstance(target, dict) or not isinstance(source, dict):
        return 0, 0
    for key, value in source.items():
        if key in ("migrations", "_id"):
            continue
        if key not in target or target[key] in (None, "", [], {}):
            target[key] = deepcopy(value)
            added += 1
        elif isinstance(target[key], dict) and isinstance(value, dict) and depth < 1:
            sub_added, sub_kept = _merge_dict_fill(target[key], value, depth + 1)
            added += sub_added
            kept += sub_kept
        elif isinstance(target[key], list) and isinstance(value, list):
            if key == "admins":
                # admin list is the only list that is always merged (never lose an admin)
                existing = {_list_item_identity(item) for item in target[key]}
                for item in value:
                    identity = _list_item_identity(item)
                    if identity in existing:
                        kept += 1
                        continue
                    target[key].append(deepcopy(item))
                    existing.add(identity)
                    added += 1
            else:
                # Existing settings / UI lists are never modified by an import.
                kept += len(value)
        else:
            kept += 1
    return added, kept


def _merge_number_batches(backup_batches):
    added_batches = added_numbers = 0
    if not isinstance(backup_batches, dict):
        return 0, 0
    by_name = {}
    for batch_id, batch in number_batches.items():
        if isinstance(batch, dict):
            by_name[str(batch.get("filename") or batch_id)] = batch_id
    for batch_id, batch in backup_batches.items():
        if not isinstance(batch, dict):
            continue
        numbers = [n for n in batch.get("numbers", []) if isinstance(n, dict) and n.get("num")]
        filename = str(batch.get("filename") or batch_id)
        existing_id = by_name.get(filename)
        if existing_id is None:
            new_id = str(batch_id)
            if new_id in number_batches:
                new_id = f"{batch_id}_imported"
            number_batches[new_id] = {
                "filename": filename,
                "numbers": [dict(n) for n in numbers],
            }
            by_name[filename] = new_id
            added_batches += 1
            added_numbers += len(numbers)
            continue
        target = number_batches[existing_id]
        have = {str(n.get("num", "")).replace("+", "") for n in target.get("numbers", []) if isinstance(n, dict)}
        for number in numbers:
            clean = str(number.get("num", "")).replace("+", "")
            if clean and clean not in have:
                target.setdefault("numbers", []).append(dict(number))
                have.add(clean)
                added_numbers += 1
    return added_batches, added_numbers


def import_backup_bundle(bundle):
    """Merge an old backup into the running bot (old data is ADDED, nothing is deleted)."""
    state, users, withdrawals, known = _backup_split(bundle)
    report = {
        "settings_added": 0, "settings_kept": 0,
        "users_added": 0, "users_merged": 0,
        "withdrawals_added": 0, "withdrawals_skipped": 0,
        "number_files": 0, "numbers_added": 0,
        "known_users_added": 0,
        "source_build": (bundle or {}).get("build") if isinstance(bundle, dict) else "",
        "source_exported": (bundle or {}).get("exported_at_text", "") if isinstance(bundle, dict) else "",
    }

    backup_settings = state.get("bot_settings") if isinstance(state.get("bot_settings"), dict) else {}
    if backup_settings:
        report["settings_added"], report["settings_kept"] = _merge_dict_fill(bot_settings, backup_settings)

    for uid, data in (users or {}).items():
        uid = str(uid)
        if not isinstance(data, dict):
            continue
        if uid not in local_users_db:
            local_users_db[uid] = dict(data)
            local_users_db[uid].setdefault("user_id", int(uid) if uid.isdigit() else uid)
            report["users_added"] += 1
        else:
            current = local_users_db[uid]
            for key, value in data.items():
                # Never overwrite what this bot already has (balance, OTP count, ban state).
                if key not in current or current[key] in (None, "", [], {}):
                    current[key] = value
            report["users_merged"] += 1

    for req_id, data in (withdrawals or {}).items():
        req_id = str(req_id)
        if not isinstance(data, dict):
            continue
        if req_id in local_withdrawals_db:
            report["withdrawals_skipped"] += 1
        else:
            local_withdrawals_db[req_id] = dict(data)
            report["withdrawals_added"] += 1

    report["number_files"], report["numbers_added"] = _merge_number_batches(state.get("number_batches"))

    for number in state.get("used_numbers_list") or []:
        if number not in used_numbers_list:
            used_numbers_list.append(number)
    for number in state.get("otp_received_numbers") or []:
        otp_received_numbers.add(number) if isinstance(otp_received_numbers, set) else None

    for uid in known:
        uid = str(uid)
        if uid not in all_known_users:
            all_known_users.add(uid)
            report["known_users_added"] += 1

    save_local_db()
    _save_local_users_db()
    _save_local_withdrawals_db()
    try:
        _save_users_list()
    except Exception:
        pass
    try:
        rebuild_pending_withdrawals()
    except Exception as exc:
        print(f"⚠️ Could not rebuild pending withdrawals after import: {exc}")
    return report


def reset_all_data():
    """Factory reset: the bot starts up exactly like the very first time.

    Every user, balance, withdrawal, number file, style, button change and setting is
    removed. The owner (OWNER_ID) stays admin so the bot can still be controlled.
    """
    global total_uploaded_stats, total_assigned_stats
    with local_db_lock:
        bot_settings.clear()
        bot_settings.update(deepcopy(_FACTORY_BOT_SETTINGS))
        bot_settings["admins"] = [OWNER_ID]
        bot_settings["premium_flags"] = {}
        bot_settings["migrations"] = {"bdt_text_v1": True, "flag_emoji_pack_v1": True}

        users_before = len(local_users_db)
        withdrawals_before = len(local_withdrawals_db)
        files_before = len(number_batches)
        known_before = len(all_known_users)

        local_users_db.clear()
        local_withdrawals_db.clear()
        number_batches.clear()
        used_numbers_list.clear()
        pending_withdrawals.clear()
        all_known_users.clear()
        user_states.clear()
        temp_data.clear()
        user_cooldowns.clear()
        nexa_assigned_numbers.clear()
        voltx_assigned_numbers.clear()
        recent_traffic.clear()
        processed_otps.clear()
        processed_otps_order.clear()
        otp_received_numbers.clear()
        otp_received_order.clear()
        user_banned_cache.clear()
        total_uploaded_stats = 0
        total_assigned_stats = 0

    reset_random_style_history()
    seed_flag_emojis(force=True)
    save_local_db()
    _save_local_users_db()
    _save_local_withdrawals_db()
    _save_users_list()
    return {
        "users": users_before,
        "withdrawals": withdrawals_before,
        "files": files_before,
        "known_users": known_before,
        "styles": len(get_custom_otp_styles()),
    }


def backup_reset_text(step=1, notice=""):
    lines = []
    if notice:
        lines.extend([notice, ""])
    lines.append("⚠️ <b>RESET ALL DATA</b>")
    lines.append("\u2501" * 16)
    lines.append("এতে <b>সবকিছু</b> মুছে যাবে:")
    lines.append("• সব ইউজার, ব্যালেন্স, OTP হিস্ট্রি")
    lines.append("• সব withdraw (pending সহ)")
    lines.append("• সব নাম্বার ফাইল ও নাম্বার")
    lines.append("• সব প্যানেল, গ্রুপ, স্টাইল, বাটন, সেটিংস")
    lines.append("• ব্রডকাস্ট লিস্ট, স্ট্যাটস")
    lines.append("")
    lines.append(f"🔒 শুধু আপনি (<code>{OWNER_ID}</code>) অ্যাডমিন থাকবেন।")
    lines.append(f"💾 আপনার আগের ব্যাকআপ ফাইল থাকলে পরে 📤 Import Old Data দিয়ে ফিরিয়ে আনতে পারবেন।")
    lines.append("")
    if step <= 1:
        lines.append("👉 <b>ধাপ ১/২</b> — নিশ্চিত? নিচের বাটনে চাপ দিন।")
    else:
        lines.append("👉 <b>ধাপ ২/২</b> — একদম শেষ নিশ্চিতকরণ। এই বাটনে চাপ দিলেই ডাটা মুছে যাবে।")
    return render_body_text("\n".join(lines))


def backup_reset_keyboard(step=1):
    if step <= 1:
        return {"inline_keyboard": [
            [{"text": "⚠️ Yes, I want to reset (1/2)", "callback_data": "backup_reset_1", "style": "danger"}],
            [{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "backup_menu", "style": "primary"}],
        ]}
    return {"inline_keyboard": [
        [{"text": "🗑 CONFIRM — DELETE EVERYTHING (2/2)", "callback_data": "backup_reset_2", "style": "danger"}],
        [{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "backup_menu", "style": "primary"}],
    ]}


def backup_menu_text(notice=""):
    def size_of(path):
        try:
            return os.path.getsize(path)
        except Exception:
            return 0

    def human(num):
        for unit in ("B", "KB", "MB", "GB"):
            if num < 1024 or unit == "GB":
                return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
            num /= 1024.0

    lines = []
    if notice:
        lines.extend([notice, ""])
    lines.append(f"{PEM['file']} <b>BACKUP / RESTORE</b>")
    lines.append("\u2501" * 16)
    lines.append(f"📂 Folder: <code>{html.escape(os.path.abspath(DATA_DIR))}</code>")
    lines.append("")
    for path, _default in _DATA_FILES:
        lines.append(f"• <code>{os.path.basename(path)}</code> — {human(size_of(path))}")
    lines.append("")
    lines.append(f"{PEM['user']} Users: <b>{len(local_users_db)}</b> · "
                 f"{PEM['money']} Withdrawals: <b>{len(local_withdrawals_db)}</b> · "
                 f"{PEM['num']} Files: <b>{len(number_batches)}</b>")
    lines.append(f"{PEM['file']} Backup size: <b>{human(len(backup_json_text().encode('utf-8')))}</b>")
    lines.append("")
    lines.append("📥 <b>Download Data File</b> — সব ডাটা এক ফাইলে নামবে")
    lines.append("📤 <b>Import Old Data</b> — পুরনো ফাইল পাঠালে আগের ডাটা এখানে যোগ হবে")
    return render_body_text("\n".join(lines))


def backup_menu_keyboard():
    return {"inline_keyboard": [
        [{"text": "📥 Download Data File", "icon_custom_emoji_id": "5257969839313526622", "callback_data": "backup_download", "style": "success"}],
        [{"text": "📤 Import Old Data", "icon_custom_emoji_id": "5353001161878182134", "callback_data": "backup_import", "style": "primary"}],
        [{"text": "🗑 Reset All Data", "icon_custom_emoji_id": "5422557736330106570", "callback_data": "backup_reset", "style": "danger"}],
        [{"text": "♻️ Refresh", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "backup_menu", "style": "primary"},
         {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}],
    ]}


def backup_import_report_text(report):
    lines = [f"{PEM['ok']} <b>OLD DATA IMPORTED</b>", "\u2501" * 16]
    if report.get("source_build") or report.get("source_exported"):
        lines.append(f"📦 Source: build <b>{html.escape(str(report.get('source_build') or '?'))}</b>"
                     + (f" · {html.escape(str(report.get('source_exported')))}" if report.get("source_exported") else ""))
        lines.append("")
    lines.append(f"{PEM['user']} Users added: <b>{report['users_added']}</b> (merged: {report['users_merged']})")
    lines.append(f"{PEM['money']} Withdrawals added: <b>{report['withdrawals_added']}</b> (already there: {report['withdrawals_skipped']})")
    lines.append(f"{PEM['file']} Number files: <b>{report['number_files']}</b> · numbers added: <b>{report['numbers_added']}</b>")
    lines.append(f"{PEM['gear']} Settings merged: <b>{report['settings_added']}</b> (kept current: {report['settings_kept']})")
    if report.get("known_users_added"):
        lines.append(f"📢 Broadcast list: +{report['known_users_added']}")
    lines.append("")
    lines.append("<i>Nothing was deleted — old data was added on top of the current data.</i>")
    return render_body_text("\n".join(lines))


def broadcast_copymessage(from_chat_id, msg_id):
    success = 0
    failed = 0
    users = list(all_known_users)
    
    # 🌟 Dedicated Connection Pool for Broadcast (Fixes Port Exhaustion & Network Lag)
    b_session = requests.Session()
    url = f"{BASE_URL}/copyMessage"
    
    for user_id in users:
        payload = {"chat_id": user_id, "from_chat_id": from_chat_id, "message_id": msg_id}
        try:
            res = b_session.post(url, json=payload, timeout=5).json()
            if res.get("ok"): success += 1
            else: failed += 1
        except:
            failed += 1
        time.sleep(0.035) # Safe speed (28 msgs/sec) to prevent Telegram Ban
        
    send_message(from_chat_id, render_body_text(f"📢 <b>Broadcast Completed!</b>\n✅ Success: {success}\n❌ Failed: {failed}\n👥 Total Sent: {len(users)}"))

def render_body_text(text):
    if not text: return str(text)
    parts = re.split(r'(<tg-emoji.*?</tg-emoji>)', str(text))
    for i in range(len(parts)):
        if not parts[i].startswith('<tg-emoji'):
            for normal_emj, prem_id in GLOBAL_BODY_EMOJIS.items():
                if normal_emj in parts[i]:
                    parts[i] = parts[i].replace(normal_emj, f'<tg-emoji emoji-id="{prem_id}">{normal_emj}</tg-emoji>')
    return "".join(parts)

def extract_premium_html(msg):
    text = msg.get("text", msg.get("caption", ""))
    entities = msg.get("entities", msg.get("caption_entities", []))
    if not entities: return text
    try:
        b_text = text.encode('utf-16-le')
        c_entities = [e for e in entities if e.get("type") == "custom_emoji"]
        c_entities.sort(key=lambda x: x["offset"], reverse=True)
        for ent in c_entities:
            offset = ent["offset"] * 2
            length = ent["length"] * 2
            eid = ent["custom_emoji_id"]
            emoji_char = b_text[offset:offset+length].decode('utf-16-le')
            html_tag = f'<tg-emoji emoji-id="{eid}">{emoji_char}</tg-emoji>'
            replacement = html_tag.encode('utf-16-le')
            b_text = b_text[:offset] + replacement + b_text[offset+length:]
        return b_text.decode('utf-16-le')
    except Exception as e:
        return text 

def get_flag_info_from_num(num):
    clean = num.replace("+", "").replace(" ", "")
    sorted_codes = sorted(bot_settings.get("premium_flags", {}).keys(), key=len, reverse=True)
    for code in sorted_codes:
        if clean.startswith(code):
            data = bot_settings["premium_flags"][code]
            return data["char"], data.get("iso", "XX"), data.get("id")
    return "🌍", "XX", None

def get_flag_and_code(num):
    char, iso, _ = get_flag_info_from_num(num)
    return char, iso

def get_flag_info_html(num_or_iso):
    if len(num_or_iso) == 2:
        for code, data in bot_settings.get("premium_flags", {}).items():
            if data.get("iso") == num_or_iso:
                eid = data.get("id")
                char = data.get("char")
                if eid: return f'<tg-emoji emoji-id="{eid}">{char}</tg-emoji>'
                return char
        return "🌍"
        
    char, _, eid = get_flag_info_from_num(num_or_iso)
    if eid:
        return f'<tg-emoji emoji-id="{eid}">{char}</tg-emoji>'
    return char

def mask_number(num, user_id=None):
    clean = num.replace("+", "").replace(" ", "")
    tag = "MSI"
    if len(clean) > 6: return f"{clean[:3]}✦{tag}✦{clean[-3:]}"
    elif len(clean) > 2: return f"{clean[:1]}✦{tag}✦{clean[-1:]}"
    return clean

# ==========================================
# 🌟 ADVANCED SERVICE & LANGUAGE DETECTION
# ==========================================

SERVICE_SMS_KEYWORDS = {
    # 🟢 Social Media & Chat (Added Arabic Keywords)
    "whatsapp": ["whatsapp", "wa", "wap", "w/a", "whatsapp business", "wa.me", "wa code", "wh", "واتساب", "واتساپ", "واٹس ایپ", "व्हाट्सएप", "वाट्सएप", "वॉट्सऐप", "व्हाट्सप्प", "হোয়াটসঅ্যাপ", "হোটসঅ্যাপ", "ватсап", "уотсап", "вотсап", "ватс апп", "వాట్సాప్", "വാട്‌സ്ആപ്പ്", "வாட்ஸ்அப்", "ವಾಟ್ಸಾಪ್", "વોટ્સએપ", "ਵਟਸਐਪ", "ହ୍ଵାଟସ୍ ଆପ୍", "වට්ස්ඇප්", "วอตส์แอปป์", "วอทส์แอพ", "ဝက်စ်အက်ပ်", "វ៉តសាប់", "ວອດແອັບ", "ワッツアップ", "왓츠앱", "whatsapp的", "whatsapp验证码", "וואטסאפ", "γουάτσαπ", "ዋትስአፕ", "ვოთსאფი", "վոթսափ"],
    "facebook": ["facebook", "fb", "meta", "fbook", "fb code", "facebook code", "فيسبوك", "فيس بوك"],
    "instagram": ["instagram", "insta", "ig", "ig code", "instagram code", "انستغرام", "انستقرام"],
    "telegram": ["telegram", "tg", "tele", "telegram code", "tg code", "t.me", "تيليجرام", "تليجرام"],
    "tiktok": ["tiktok", "tik tok", "tikvideo", "tiktok code", "tik code", "تيك توك"],
    "snapchat": ["snapchat", "snap", "snap code", "سناب شات"],
    "twitter": ["twitter", "x.com", "x code", "twitter code", "تويتر"],
    "discord": ["discord", "discord code", "ديسكورد"],
    "viber": ["viber", "viber code", "فايبر"],
    "line": ["line", "line code", "line verification", "لاين"],
    "wechat": ["wechat", "we chat", "wechat code", "وي تشات"],
    "signal": ["signal", "signal code", "سيجنال"],
    "linkedin": ["linkedin", "linked in", "لينكد إن"],
    "imo": ["imo", "imo code", "imo verification", "ايمو"],
    "kakaotalk": ["kakao", "kakaotalk", "كاكاو"],
    "qq": ["qq", "tencent qq"],
    "vk": ["vk", "vkontakte"],

    # 🔵 Tech & Mail
    "google": ["google", "gmail", "youtube", "g-", "google voice", "جوجل", "غوغل"],
    "microsoft": ["microsoft", "ms", "outlook", "live.com", "hotmail"],
    "apple": ["apple", "icloud", "itunes", "apple id"],
    "yahoo": ["yahoo", "yahoo code", "ymail"],
    "protonmail": ["proton", "protonmail"],
    
    # 💰 Crypto & Trading
    "binance": ["binance", "bnb", "binances"],
    "coinbase": ["coinbase"],
    "okx": ["okx", "okex"],
    "kucoin": ["kucoin"],
    "bybit": ["bybit"],
    "huobi": ["huobi", "htx"],
    "mexc": ["mexc"],
    "trustwallet": ["trust wallet", "trustwallet"],

    # 💳 Finance & Wallets
    "paytm": ["paytm", "paytm code", "paytm otp"],
    "phonepe": ["phonepe", "phone pe", "phonepe code"],
    "gpay": ["gpay", "google pay", "googlepay"],
    "upi": ["upi", "upi code", "upi otp"],
    "paypal": ["paypal", "pay pal"],
    "cashapp": ["cash app", "cashapp"],
    "wise": ["wise", "transferwise"],

    # 🛒 E-commerce & Delivery
    "amazon": ["amazon", "amzn", "amazon code"],
    "ebay": ["ebay"],
    "aliexpress": ["aliexpress", "ali express"],
    "alibaba": ["alibaba"],
    "daraz": ["daraz", "daraz code"],
    "foodpanda": ["foodpanda", "food panda"],
    "uber": ["uber", "uber code", "uber verification", "uber eats"],
    "pathao": ["pathao", "pathao ride"],

    # 🎮 Gaming & Entertainment
    "netflix": ["netflix", "netflix code"],
    "spotify": ["spotify", "spotify code"],
    "steam": ["steam", "steam guard"],
    "epicgames": ["epic games", "epicgames"],
    "roblox": ["roblox", "roblox code"],
    "riotgames": ["riot", "riot games", "valorant", "league of legends"],
    "garena": ["garena", "free fire", "freefire"],
    "playstation": ["playstation", "psn"],

    # 🎲 Betting & Casino
    "1xbet": ["1xbet", "1x bet"],
    "melbet": ["melbet", "melbet code"],
    "linebet": ["linebet"],
    "bet365": ["bet365"],
    "megapari": ["megapari"],

    # ❤️ Dating
    "tinder": ["tinder", "tinder code"],
    "bumble": ["bumble"],
    "badoo": ["badoo"]
}

def detect_service(text):
    text_lower = str(text).lower()
    for service_key, keywords in SERVICE_SMS_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                return service_key.upper()
    return None

def get_service_info_html(service_text, msg_text=""):
    s = str(service_text).upper().strip()
    m = str(msg_text).lower().strip()
    apps = bot_settings.get("premium_apps", {})
    
    detected_service = s
    if m:
        for service_key, keywords in SERVICE_SMS_KEYWORDS.items():
            for kw in keywords:
                if kw in m:
                    detected_service = service_key.upper()
                    break
            if detected_service != s: break

    clean_s = re.sub(r'[^\w\s]', '', detected_service).strip()
    
    for app_name, data in apps.items():
        if app_name == detected_service or app_name == clean_s or app_name in detected_service or detected_service in app_name:
            full_name = data.get("name", app_name.title())
            char = data.get("char", "📱")
            eid = data.get("id")
            if eid: return full_name, f'<tg-emoji emoji-id="{eid}">{char}</tg-emoji>'
            return full_name, char
            
    if len(detected_service) > 20:
        return "Message", "💬"
        
    return detected_service.title(), "📱"

def get_flag_emoji(iso2):
    """2-letter ISO code থেকে standard flag emoji তৈরি করুন"""
    return iso_to_flag_emoji(iso2)

def _find_dial_code(clean_num):
    """নম্বর থেকে dial code বের করুন। Premium flags আগে, তারপর COUNTRY_DB।"""
    sorted_prem = sorted(bot_settings.get("premium_flags", {}).keys(), key=len, reverse=True)
    for code in sorted_prem:
        if clean_num.startswith(code):
            return code, "premium"
    sorted_db = sorted(COUNTRY_DB.keys(), key=len, reverse=True)
    for code in sorted_db:
        if clean_num.startswith(code):
            return code, "db"
    return "", "none"

def get_country_from_num(num):
    """নম্বর থেকে (flag_html, iso, dial_code) বের করুন"""
    clean = num.replace("+", "").replace(" ", "")
    dial_code, src = _find_dial_code(clean)
    if src == "premium":
        data = bot_settings["premium_flags"][dial_code]
        flag_char = data["char"]
        iso = data.get("iso", "XX")
        eid = data.get("id")
        flag_html = f'<tg-emoji emoji-id="{eid}">{flag_char}</tg-emoji>' if eid else flag_char
        return flag_html, iso, dial_code
    if src == "db":
        info = COUNTRY_DB[dial_code]
        iso = info["iso"]
        flag_char = get_flag_emoji(iso)
        return flag_char, iso, dial_code
    return "🌍", "XX", ""

def mask_smart(num):
    """Country code + xxxxx + last 4 digit স্টাইলে mask করুন। যেমন: 224xxxxx0280"""
    clean = num.replace("+", "").replace(" ", "")
    dial_code, _ = _find_dial_code(clean)
    rest = clean[len(dial_code):]
    if len(rest) > 4:
        middle_len = len(rest) - 4
        last4 = rest[-4:]
        return f"{dial_code}{'x' * middle_len}{last4}"
    return f"{dial_code}{rest}" if dial_code else clean

# ==========================================
# Admin UI: Withdrawal queue (one by one)
# ==========================================
def _wd_status(entry):
    return str((entry or {}).get("status", "pending")).lower()


def _wd_pending_map():
    """req_id -> details of every pending withdrawal (rebuild-safe)."""
    merged_all = {}
    for req_id, data in (local_withdrawals_db or {}).items():
        if not isinstance(data, dict) or _wd_status(data) != "pending":
            continue
        merged = dict(data)
        live = pending_withdrawals.get(req_id) or pending_withdrawals.get(str(req_id)) or {}
        if isinstance(live, dict):
            for key, value in live.items():
                if value not in (None, "", []):
                    merged[key] = value
        merged_all[str(req_id)] = merged
    for req_id, data in (pending_withdrawals or {}).items():
        rid = str(req_id)
        if rid in merged_all or not isinstance(data, dict):
            continue
        merged_all[rid] = dict(data, status="pending")
    return merged_all


def pending_withdrawal_ids():
    items = _wd_pending_map()
    def sort_key(item):
        data = item[1]
        return data.get("created_at") or data.get("timestamp") or 0
    return [rid for rid, _ in sorted(items.items(), key=sort_key)]


def _wd_time_ago(value):
    try:
        seconds = max(0, int(time.time() - float(value or 0)))
    except (TypeError, ValueError):
        return "unknown"
    if seconds < 60:
        return f"{seconds}s ago"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h {(seconds % 3600) // 60}m ago"
    return f"{seconds // 86400}d ago"


def _wd_user_line(req_id, data):
    uid = str(data.get("user_id", ""))
    name = html.escape(str(data.get("full_name") or "User"))
    if uid.isdigit():
        return f"<a href='tg://user?id={uid}'>{name}</a> · <code>{uid}</code>"
    return f"{name} · <code>{html.escape(uid)}</code>"


def wd_stats():
    pending = _wd_pending_map()
    total_amount = sum(float(d.get("amount", 0) or 0) for d in pending.values())
    approved = rejected = approved_amount = 0
    for data in (local_withdrawals_db or {}).values():
        if not isinstance(data, dict):
            continue
        status = _wd_status(data)
        if status == "approved":
            approved += 1
            approved_amount += float(data.get("amount", 0) or 0)
        elif status == "rejected":
            rejected += 1
    return {
        "pending": len(pending),
        "pending_amount": round(total_amount, 2),
        "approved": approved,
        "approved_amount": round(approved_amount, 2),
        "rejected": rejected,
    }


def wd_menu_text(notice=""):
    stats = wd_stats()
    lines = []
    if notice:
        lines.extend([notice, ""])
    lines.append(f"{PEM['money']} <b>WITHDRAWAL CONTROL</b>")
    lines.append("\u2501" * 16)
    lines.append(f"⏳ Pending: <b>{stats['pending']}</b> · 💰 {stats['pending_amount']} USDT")
    lines.append(f"✅ Paid: <b>{stats['approved']}</b> · 💰 {stats['approved_amount']} USDT")
    lines.append(f"❌ Rejected: <b>{stats['rejected']}</b>")
    lines.append("")
    if stats["pending"]:
        lines.append("<i>Tap ⏳ Pending to review them one by one. Pay / Reject moves to the next request automatically.</i>")
    else:
        lines.append("<i>No pending withdrawal right now ✅</i>")
    return render_body_text("\n".join(lines))


def wd_menu_keyboard():
    stats = wd_stats()
    return {"inline_keyboard": [
        [{"text": f"⏳ Pending ({stats['pending']})", "icon_custom_emoji_id": "5352585194295564660", "callback_data": "wd_pending", "style": "success" if stats["pending"] else "primary"}],
        [{"text": "✅ Paid list", "icon_custom_emoji_id": "5352694861990501856", "callback_data": "wd_hist_a", "style": "success"},
         {"text": "❌ Rejected list", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "wd_hist_r", "style": "danger"}],
        [{"text": "🔄 Refresh", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "wd_menu", "style": "primary"},
         {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}],
    ]}


def wd_card_text(req_id, notice=""):
    pending = _wd_pending_map()
    data = pending.get(str(req_id))
    if not data:
        return render_body_text(
            f"{PEM['no']} <b>This request is no longer pending.</b>\n\n"
            "It was already paid or rejected. Tap ⏭ Next to see the current queue."
        )
    ids = list(pending.keys())
    try:
        index = ids.index(str(req_id)) + 1
    except ValueError:
        index = 1
    uid = str(data.get("user_id", ""))
    user_balance = bot_settings.get("__noop", 0)
    try:
        user_balance = _get_local_user(uid).get("balance", 0.0) if uid.isdigit() else 0
    except Exception:
        user_balance = 0
    total_otps = data.get("total_otps")
    if total_otps is None:
        try:
            total_otps = _get_local_user(uid).get("total_otps", 0) if uid.isdigit() else 0
        except Exception:
            total_otps = 0
    lines = []
    if notice:
        lines.extend([notice, ""])
    lines += [
        f"{PEM['money']} <b>WITHDRAWAL REQUEST</b> · <b>{index}/{len(ids)}</b>",
        "\u2501" * 16,
        f"👤 <b>User:</b> {_wd_user_line(req_id, data)}",
        f"💳 <b>Amount:</b> <b>{data.get('amount', 0)}</b> USDT",
        f"🏦 <b>Method:</b> {html.escape(str(data.get('method', '-')))}",
        f"📱 <b>Number:</b> <code>{html.escape(str(data.get('number', '-')))}</code>",
        "\u2501" * 16,
        f"🔐 <b>OTP received:</b> {total_otps}",
        f"💰 <b>User balance:</b> {user_balance} USDT",
        f"🧾 <b>Req ID:</b> <code>{html.escape(str(req_id))}</code>",
        f"🕒 <b>Requested:</b> {_wd_time_ago(data.get('created_at') or data.get('timestamp'))}",
        "\u2501" * 16,
        "⏳ <b>Status:</b> PENDING",
    ]
    return render_body_text("\n".join(lines))


def wd_card_keyboard(req_id):
    ids = pending_withdrawal_ids()
    total = len(ids)
    rows = [
        [{"text": "✅ PAY", "icon_custom_emoji_id": "5352694861990501856", "callback_data": f"wdq_pay_{req_id}", "style": "success"},
         {"text": "❌ Reject", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"wdq_rej_{req_id}", "style": "danger"}],
    ]
    nav = []
    if total > 1:
        nav.append({"text": "⏭ Next", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"wdq_next_{req_id}", "style": "primary"})
    nav.append({"text": "🔄 Refresh", "icon_custom_emoji_id": "5192812028632274956", "callback_data": f"wdq_show_{req_id}", "style": "primary"})
    rows.append(nav)
    rows.append([
        {"text": f"⏳ Pending ({total})", "icon_custom_emoji_id": "5352585194295564660", "callback_data": "wd_menu", "style": "success"},
        {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wd_menu", "style": "danger"},
    ])
    return {"inline_keyboard": rows}


def wd_next_pending_id(after_req_id):
    ids = pending_withdrawal_ids()
    if not ids:
        return None
    if after_req_id in ids:
        pos = ids.index(after_req_id) + 1
        return ids[pos % len(ids)] if len(ids) > 1 else ids[0]
    return ids[0]


def process_withdrawal_action(req_id, action, admin_id=None):
    """Approve or reject one withdrawal. Returns (ok, message, next_req_id)."""
    action = str(action or "").upper()
    pending = _wd_pending_map()
    data = pending.get(str(req_id))
    is_approve = action in ("PAY", "APPROVE", "WAPP")
    if not data:
        return False, "❌ Request already processed or not found.", (pending_withdrawal_ids() or [None])[0]
    uid = data.get("user_id")
    amount = float(data.get("amount", 0) or 0)
    number = str(data.get("number", ""))
    full_name = data.get("full_name") or uid
    try:
        uid_int = int(uid)
    except (TypeError, ValueError):
        uid_int = None

    status = "approved" if is_approve else "rejected"
    _update_local_withdrawal(req_id, {
        "status": status,
        "processed_by": str(admin_id or ""),
        "processed_at": time.time(),
    })
    if req_id in pending_withdrawals:
        live = pending_withdrawals[req_id]
        for sm in live.get("sent_messages", []) or []:
            try:
                masked_num = mask_number(number, user_id=uid_int) if is_approve else number
                status_text = "APPROVED" if is_approve else "REJECTED"
                note = f"🎙 <b>WITHDRAWAL {status_text}</b>\n\n👤 <b>USER:</b> {html.escape(str(full_name))}\n💳 <b>WITHDRAWAL:</b> {amount} USDT\n🍏 <b>NUMBER:</b> <code>{html.escape(str(masked_num))}</code>\n🏦 <b>METHOD:</b> {html.escape(str(data.get('method', '-')))}\n\n🧾 <b>REQ ID:</b> {html.escape(str(req_id))}\n👨‍⚖️ <b>PROCESSED BY ADMIN</b>"
                edit_message(sm.get("chat_id"), sm.get("message_id"), render_body_text(note))
            except Exception:
                pass
        del pending_withdrawals[req_id]

    if is_approve:
        if uid_int:
            try:
                send_message(uid_int, render_body_text(f"{PEM['ok']} Your {amount:g} USDT withdrawal request has been paid successfully!"))
            except Exception:
                pass
        result = f"✅ <b>PAID</b> · {amount:g} USDT → {html.escape(str(full_name))}"
    else:
        if uid_int:
            try:
                update_balance(uid_int, amount)
                send_message(uid_int, render_body_text(f"{PEM['no']} Your {amount:g} USDT withdrawal request was rejected. Balance refunded."))
            except Exception:
                pass
        result = f"❌ <b>REJECTED & REFUNDED</b> · {amount:g} USDT → {html.escape(str(full_name))}"
    return True, result, wd_next_pending_id(req_id)


def wd_history_text(status="approved", limit=10):
    entries = []
    for req_id, data in (local_withdrawals_db or {}).items():
        if not isinstance(data, dict) or _wd_status(data) != status:
            continue
        entries.append((req_id, data))
    entries.sort(key=lambda item: item[1].get("processed_at") or item[1].get("created_at") or item[1].get("timestamp") or 0, reverse=True)
    entries = entries[:limit]
    title = "PAID WITHDRAWALS" if status == "approved" else "REJECTED WITHDRAWALS"
    icon = "✅" if status == "approved" else "❌"
    lines = [f"{PEM['money']} <b>{title}</b>", "\u2501" * 16]
    if not entries:
        lines.append("<i>Nothing here yet.</i>")
    for req_id, data in entries:
        lines.append(
            f"{icon} <b>{data.get('amount', 0)} USDT</b> · {html.escape(str(data.get('method', '-')))} · "
            f"<code>{html.escape(str(data.get('user_id', '-')))}</code> · {_wd_time_ago(data.get('processed_at') or data.get('created_at'))}"
        )
        lines.append(f"   🧾 <code>{html.escape(str(req_id))}</code> 📱 <code>{html.escape(str(data.get('number', '-')))}</code>")
    return render_body_text("\n".join(lines))


def wd_history_keyboard():
    return {"inline_keyboard": [
        [{"text": "⏳ Pending", "icon_custom_emoji_id": "5352585194295564660", "callback_data": "wd_pending", "style": "success"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wd_menu", "style": "danger"}],
    ]}


def rebuild_pending_withdrawals():
    """After a restart, rehydrate the in-memory pending queue from the JSON DB."""
    restored = 0
    for req_id, data in (local_withdrawals_db or {}).items():
        if not isinstance(data, dict) or _wd_status(data) != "pending":
            continue
        if req_id not in pending_withdrawals:
            pending_withdrawals[req_id] = {
                "user_id": int(data["user_id"]) if str(data.get("user_id", "")).isdigit() else data.get("user_id"),
                "amount": float(data.get("amount", 0) or 0),
                "method": data.get("method", ""),
                "number": data.get("number", ""),
                "full_name": data.get("full_name", ""),
                "sent_messages": [],
            }
            restored += 1
    if restored:
        print(f"♻️ Restored {restored} pending withdrawal(s) from disk")
    return restored


# ==========================================
# OTP / SMS Message Styles
# ==========================================
# {flag} {iso} {app} {number} {full_number} {otp} {lang} {dial} {country} {time} {date}
OTP_STYLE_LIBRARY = [
    {
        "id": "border",
        "name": "Border Line (default)",
        "mask": True,
        "template": "━━━━━━━━━━━━━━━━━━\n{flag} {iso} {app} {number} {lang}\n━━━━━━━━━━━━━━━━━━",
    },
    {
        "id": "box",
        "name": "Box",
        "mask": True,
        "template": "╔══════════════════╗\n   {flag} {iso} {app}\n   📱 {number}\n   🔑 {otp}\n╚══════════════════╝",
    },
    {
        "id": "round_box",
        "name": "Round Box",
        "mask": True,
        "template": "╭━━━━━━━━━━━━━━━╮\n┃ {flag} {iso} {app}\n┃ 📱 {number}\n┃ 🔐 {otp}\n╰━━━━━━━━━━━━━━━╯",
    },
    {
        "id": "card",
        "name": "Clean Card",
        "mask": True,
        "template": "┌──────────────────┐\n│ {app} · {iso} {flag}\n│ 📱 <code>{number}</code>\n│ 🔑 <code>{otp}</code>\n└──────────────────┘",
    },
    {
        "id": "otp_first",
        "name": "OTP First (big code)",
        "mask": True,
        "template": "🔐 <b>{otp}</b>\n{flag} {iso} {app}\n📱 {number} {lang}",
    },
    {
        "id": "minimal",
        "name": "Minimal",
        "mask": True,
        "template": "{flag} {iso} {app} | {number} | {otp} {lang}",
    },
    {
        "id": "lines",
        "name": "Label Lines",
        "mask": False,
        "template": "{flag} <b>Country</b>: {country} ({dial})\n📲 <b>Service</b>: {app}\n☎️ <b>Number</b>: <code>{full_number}</code>\n🔑 <b>OTP</b>: <b>{otp}</b>\n🌐 <b>Lang</b>: {lang}",
    },
    {
        "id": "arrow",
        "name": "Arrow",
        "mask": True,
        "template": "➜ {flag} {iso} {app}\n➜ 📱 {number}\n➜ 🔑 {otp}",
    },
]

OTP_STYLE_PLACEHOLDERS = (
    "{flag} {iso} {app} {number} {full_number} {otp} {lang} "
    "{dial} {country} {time} {date}"
)


def get_custom_otp_styles():
    styles = bot_settings.get("otp_styles")
    if not isinstance(styles, list):
        styles = []
        bot_settings["otp_styles"] = styles
    return [s for s in styles if isinstance(s, dict) and s.get("id") and s.get("template")]


def all_otp_styles():
    styles = [dict(s) for s in OTP_STYLE_LIBRARY]
    styles.extend(dict(s) for s in get_custom_otp_styles() if s.get("id") not in {b["id"] for b in OTP_STYLE_LIBRARY})
    return styles


RANDOM_OTP_STYLE_ID = "all"
RANDOM_OTP_STYLE_LABEL = "🎲 All / Random (mix)"

_style_rotation_lock = threading.Lock()
_style_rotation_state = {}  # scope -> {"pool": [ids...], "last": style_id}


def get_otp_style(style_id):
    if str(style_id) == RANDOM_OTP_STYLE_ID:
        return {"id": RANDOM_OTP_STYLE_ID, "name": RANDOM_OTP_STYLE_LABEL,
                "template": OTP_STYLE_LIBRARY[0]["template"], "mask": True}
    for style in all_otp_styles():
        if style.get("id") == style_id:
            return style
    return OTP_STYLE_LIBRARY[0]


def _all_style_ids():
    return [str(s["id"]) for s in all_otp_styles() if str(s.get("id")) != RANDOM_OTP_STYLE_ID]


def next_random_otp_style(scope="group"):
    """🎲 Pick the next style from a shuffled bag.

    One bag = every style exactly once in random order, so consecutive SMS never
    repeat a style until all of them have been used.
    """
    style_ids = _all_style_ids()
    if not style_ids:
        return OTP_STYLE_LIBRARY[0]
    scope = scope or "group"
    with _style_rotation_lock:
        state = _style_rotation_state.setdefault(scope, {"pool": [], "last": None})
        pool = [sid for sid in (state.get("pool") or []) if sid in style_ids]
        if not pool:
            pool = list(style_ids)
            random.shuffle(pool)
            last = state.get("last")
            if len(pool) > 1 and last and pool[0] == last:
                swap_at = random.randrange(1, len(pool))
                pool[0], pool[swap_at] = pool[swap_at], pool[0]
        picked = pool.pop(0)
        state["pool"] = pool
        state["last"] = picked
    return get_otp_style(picked)


def reset_random_style_history(scope=None):
    with _style_rotation_lock:
        if scope:
            _style_rotation_state.pop(scope, None)
        else:
            _style_rotation_state.clear()


def active_otp_style_id(for_group=True):
    key = "otp_style_group" if for_group else "otp_style_user"
    style_id = str(bot_settings.get(key) or "border")
    if style_id != RANDOM_OTP_STYLE_ID and style_id not in {s["id"] for s in all_otp_styles()}:
        style_id = "border"
    return style_id


def resolve_otp_style(style_id=None, for_group=True, scope=None):
    """Real style for one delivery — resolves the 🎲 All (random) mode."""
    scope = scope or ("group" if for_group else "user")
    if style_id not in (None, ""):
        style_id = str(style_id)
        if style_id == RANDOM_OTP_STYLE_ID:
            return next_random_otp_style(scope)
        return get_otp_style(style_id)
    if active_otp_style_id(for_group=for_group) == RANDOM_OTP_STYLE_ID:
        return next_random_otp_style(scope)
    return get_otp_style(active_otp_style_id(for_group=for_group))


def active_otp_style(for_group=True):
    return resolve_otp_style(None, for_group=for_group)


def preview_otp_style(for_group=True):
    """Stable style for admin previews (does not consume the random bag)."""
    active_id = active_otp_style_id(for_group)
    if active_id != RANDOM_OTP_STYLE_ID:
        return get_otp_style(active_id)
    scope = "group" if for_group else "user"
    state = _style_rotation_state.get(scope) or {}
    last = state.get("last")
    if last:
        return get_otp_style(last)
    return get_otp_style((_all_style_ids() or ["border"])[0])


def otp_style_context(num, app_full_name, lang, masked, prem_html, otp=""):
    flag_html, iso, dial_code = get_country_from_num(num)
    clean_number = str(num).replace("+", "").replace(" ", "").strip()
    app_display = app_full_name
    if bot_settings.get("premium_emoji_on") and prem_html:
        app_display = prem_html
    country_name = iso
    for _code, info in list(bot_settings.get("premium_flags", {}).items()) + list(COUNTRY_DB.items()):
        if isinstance(info, dict) and str(info.get("iso", "")).upper() == str(iso).upper():
            country_name = info.get("name") or iso
            break
    now = datetime.now()
    return {
        "flag": flag_html,
        "iso": iso,
        "app": app_display,
        "app_plain": app_full_name,
        "number": mask_smart(num) if masked else clean_number,
        "full_number": clean_number,
        "otp": str(otp or ""),
        "lang": lang,
        "dial": dial_code or "",
        "country": country_name,
        "time": now.strftime("%H:%M:%S"),
        "date": now.strftime("%Y-%m-%d"),
    }


def render_otp_style(style, context, fallback_mask=True):
    template = str((style or {}).get("template") or "").strip()
    if not template:
        template = OTP_STYLE_LIBRARY[0]["template"]
    masked = bool(fallback_mask and (style or {}).get("mask", True))
    ctx = dict(context)
    if not masked:
        ctx["number"] = ctx.get("full_number", ctx.get("number", ""))
    text = template
    for key, value in ctx.items():
        text = text.replace("{" + key + "}", str(value))
    return text


def build_otp_message(num, app_full_name, lang, masked=True, prem_html=None, otp="",
                      style_id=None, for_group=False):
    style = resolve_otp_style(style_id, for_group=for_group)
    context = otp_style_context(num, app_full_name, lang, masked, prem_html, otp)
    return render_otp_style(style, context, fallback_mask=masked)


def format_otp_display(num, app_full_name, lang, masked=True, prem_html=None, otp="",
                       style_id=None, for_group=False):
    """Render the OTP message using the admin selected style."""
    return build_otp_message(num, app_full_name, lang, masked=masked, prem_html=prem_html,
                             otp=otp, style_id=style_id, for_group=for_group)


def detect_language(text):
    if not text: return "#EN"
    text_str = str(text)

    # 1. Accurate alphabet detection using Unicode Block (100% Accurate for scripts)
    if any('\u0600' <= c <= '\u06ff' for c in text_str): return "#AR" # Arabic / Persian / Urdu
    if any('\u0980' <= c <= '\u09ff' for c in text_str): return "#BN" # Bengali
    if any('\u0900' <= c <= '\u097f' for c in text_str): return "#HI" # Hindi / Marathi / Nepali
    if any('\u0a00' <= c <= '\u0a7f' for c in text_str): return "#PA" # Punjabi (Gurmukhi)
    if any('\u0a80' <= c <= '\u0aff' for c in text_str): return "#GU" # Gujarati
    if any('\u0b00' <= c <= '\u0b7f' for c in text_str): return "#OR" # Odia
    if any('\u0b80' <= c <= '\u0bff' for c in text_str): return "#TA" # Tamil
    if any('\u0c00' <= c <= '\u0c7f' for c in text_str): return "#TE" # Telugu
    if any('\u0c80' <= c <= '\u0cff' for c in text_str): return "#KN" # Kannada
    if any('\u0d00' <= c <= '\u0d7f' for c in text_str): return "#ML" # Malayalam
    if any('\u0d80' <= c <= '\u0dff' for c in text_str): return "#SI" # Sinhala
    if any('\u0e00' <= c <= '\u0e7f' for c in text_str): return "#TH" # Thai
    if any('\u0e80' <= c <= '\u0eff' for c in text_str): return "#LO" # Lao
    if any('\u0f00' <= c <= '\u0fff' for c in text_str): return "#BO" # Tibetan
    if any('\u1000' <= c <= '\u109f' for c in text_str): return "#MY" # Burmese (Myanmar)
    if any('\u1200' <= c <= '\u137f' for c in text_str): return "#AM" # Amharic (Ethiopic)
    if any('\u1780' <= c <= '\u17ff' for c in text_str): return "#KM" # Khmer
    if any('\u10a0' <= c <= '\u10ff' for c in text_str): return "#KA" # Georgian
    if any('\u0530' <= c <= '\u058f' for c in text_str): return "#HY" # Armenian
    if any('\u0590' <= c <= '\u05ff' for c in text_str): return "#HE" # Hebrew
    if any('\u0370' <= c <= '\u03ff' for c in text_str): return "#EL" # Greek
    if any('\u0400' <= c <= '\u04ff' for c in text_str): return "#RU" # Russian / Ukrainian (Cyrillic)
    if any('\u4e00' <= c <= '\u9fff' for c in text_str): return "#ZH" # Chinese
    if any('\u3040' <= c <= '\u309f' or '\u30a0' <= c <= '\u30ff' for c in text_str): return "#JA" # Japanese
    if any('\uac00' <= c <= '\ud7af' for c in text_str): return "#KO" # Korean

    # 2. Language detection using OTP Keywords (Latin script languages)
    text_lower = text_str.lower()
    
    # Asian / Pacific
    if any(w in text_lower for w in ["kode verifikasi", "jangan bagikan", "rahasia"]): return "#ID" # Indonesian
    if any(w in text_lower for w in ["kod pengesahan", "jangan kongsi"]): return "#MS" # Malay
    if any(w in text_lower for w in ["mã của bạn", "không chia sẻ", "mã xác minh"]): return "#VN" # Vietnamese
    if any(w in text_lower for w in ["ang iyong code", "huwag ibahagi"]): return "#TL" # Tagalog / Filipino
    
    # European / Americas
    if any(w in text_lower for w in ["código", "tu código", "verificación", "no compartas"]): return "#ES" # Spanish
    if any(w in text_lower for w in ["seu código", "código de verificação", "não compartilhe"]): return "#PT" # Portuguese
    if any(w in text_lower for w in ["code secret", "ne partagez pas", "votre code"]): return "#FR" # French
    if any(w in text_lower for w in ["dein code", "bestätigungscode", "nicht teilen"]): return "#DE" # German
    if any(w in text_lower for w in ["il tuo codice", "codice di verifica", "non condividere"]): return "#IT" # Italian
    if any(w in text_lower for w in ["twój kod", "nie udostępniaj", "kod weryfikacyjny"]): return "#PL" # Polish
    if any(w in text_lower for w in ["doğrulama kodu", "paylaşmayın", "onay kodu"]): return "#TR" # Turkish
    if any(w in text_lower for w in ["jouw code", "verificatiecode", "niet delen"]): return "#NL" # Dutch
    if any(w in text_lower for w in ["din kod", "verifieringskod", "dela inte"]): return "#SV" # Swedish
    if any(w in text_lower for w in ["bekræftelseskode", "del ikke"]): return "#DA" # Danish
    if any(w in text_lower for w in ["bekreftelseskode", "ikke del"]): return "#NO" # Norwegian
    if any(w in text_lower for w in ["vahvistuskoodi", "älä jaa"]): return "#FI" # Finnish
    if any(w in text_lower for w in ["váš kód", "ověřovací kód", "nesdílejte"]): return "#CS" # Czech
    if any(w in text_lower for w in ["overovací kód", "nezdieľajte"]): return "#SK" # Slovak
    if any(w in text_lower for w in ["ellenőrző kód", "ne oszd meg"]): return "#HU" # Hungarian
    if any(w in text_lower for w in ["codul tău", "codul de verificare", "nu partaja"]): return "#RO" # Romanian
    if any(w in text_lower for w in ["kontrolni kod", "kod za potvrdu", "ne delite"]): return "#HR" # Croatian/Serbian
    if any(w in text_lower for w in ["код за потвърждение", "не споделяйте"]): return "#BG" # Bulgarian
    if any(w in text_lower for w in ["ваш код", "код підтвердження"]): return "#UK" # Ukrainian
    
    # African
    if any(w in text_lower for w in ["msimbo wako", "usishiriki"]): return "#SW" # Swahili
    if any(w in text_lower for w in ["verifikasiekode", "moenie deel nie"]): return "#AF" # Afrikaans
    
    # 3. Default if none of the above matches
    return "#EN"

def parse_chat_id(text):
    text = text.strip()
    if text.startswith("-100") or (text.startswith("-") and text[1:].isdigit()):
        return text
    if "t.me/" in text:
        parts = text.split("/")
        username = parts[-1]
        if username: return "@" + username if not username.startswith("@") else username
    if text.startswith("@"):
        return text
    return "@" + text

def is_admin(user_id):
    return user_id in bot_settings["admins"] or user_id == OWNER_ID

def _get_fj_chat_id(entry):
    if isinstance(entry, dict):
        return entry.get("chat_id", "")
    return entry

def _get_fj_info(entry):
    if isinstance(entry, dict):
        return entry
    return {"chat_id": entry, "type": "channel", "title": str(entry), "invite_link": "", "is_private": False}

def auto_detect_chat(chat_id_raw):
    res = api_call("getChat", {"chat_id": chat_id_raw})
    if not res.get("ok"):
        return None
    chat = res["result"]
    chat_type = chat.get("type", "")
    title = chat.get("title", str(chat_id_raw))
    username = chat.get("username", "")
    is_private = not bool(username)
    if chat_type in ["supergroup", "group"]:
        detected_type = "group"
    else:
        detected_type = "channel"
    invite_link = ""
    if is_private:
        link_res = api_call("exportChatInviteLink", {"chat_id": chat_id_raw})
        if link_res.get("ok"):
            invite_link = link_res["result"]
    else:
        invite_link = f"https://t.me/{username}"
    return {
        "chat_id": str(chat.get("id", chat_id_raw)),
        "type": detected_type,
        "title": title,
        "invite_link": invite_link,
        "is_private": is_private
    }

def check_force_join(user_id):
    if not bot_settings["fj_on"] or not bot_settings["fj_channels"]: return True
    if is_admin(user_id): return True
    for entry in bot_settings["fj_channels"]:
        ch = _get_fj_chat_id(entry)
        res = api_call("getChatMember", {"chat_id": ch, "user_id": user_id})
        if not res.get("ok"):
            # API error হলে (bot not admin বা অন্য কারণ) — skip করুন, block করবেন না
            continue
        status = res["result"].get("status", "left")
        if status in ["left", "kicked"]:
            return False
    return True

def send_force_join_msg(chat_id):
    kb = []
    for entry in bot_settings["fj_channels"]:
        info = _get_fj_info(entry)
        ch_type = info.get("type", "channel")
        title = info.get("title", "")
        invite_link = info.get("invite_link", "")
        ch_id = info.get("chat_id", "")
        if invite_link:
            url = invite_link
        elif str(ch_id).startswith("@"):
            url = f"https://t.me/{ch_id.replace('@', '')}"
        else:
            url = f"https://t.me/{ch_id}"
        type_label = "Channel" if ch_type == "channel" else "Group"
        btn_text = f"Join {type_label}: {title}" if title else f"Join {type_label}"
        kb.append([{"text": btn_text, "icon_custom_emoji_id": "5789428375261023681", "url": url, "style": "primary"}])
    kb.append([{"text": "Check Joined", "icon_custom_emoji_id": "5352694861990501856", "callback_data": "check_fj", "style": "success"}])
    send_message(chat_id, render_body_text(f"{PEM['warn']} <b>Please join our channels/groups to use the bot!</b>"), reply_markup={"inline_keyboard": kb})

def is_user_banned(user_id):
    if is_admin(user_id): return False
    if user_id in user_banned_cache and time.time() - user_banned_cache[user_id]['time'] < 60:
        return user_banned_cache[user_id]['banned']
    local_u = _get_local_user(user_id)
    banned = local_u.get("banned", False)
    user_banned_cache[user_id] = {'banned': banned, 'time': time.time()}
    return banned

# ==========================================
# Captcha Auto Login & Parsing Core
# ==========================================
def extract_otp_code(text):
    clean_text = re.sub(r'[\u200B-\u200D\uFEFF]', '', str(text))

    # 1. Multi-part OTPs (e.g. 123-456 or 809-761)
    multi_part = re.search(r'(\d{3}[-\s]+\d{3})|(\d{2}[-\s]+\d{2}[-\s]+\d{2})', clean_text)
    if multi_part:
        # Keep hyphen (-) if present, but remove spaces and join together
        return multi_part.group(0).replace(" ", "")

    # 2. Keyword-based extraction
    otp_keywords = ['code', 'is', 'otp', 'pin', 'verification', 'auth', 'رمز', 'your code']
    keywords_pattern = '|'.join(otp_keywords)
    keyword_match = re.search(rf'(?:{keywords_pattern})\s*(?:is|:|-|=)?\s*([a-z0-9]{{4,10}})', clean_text, re.I)
    if keyword_match and keyword_match.group(1).isdigit():
        return keyword_match.group(1)
        
    keyword_match_rev = re.search(rf'([a-z0-9]{{4,10}})\s*(?:is your|is the|code)', clean_text, re.I)
    if keyword_match_rev and keyword_match_rev.group(1).isdigit():
        return keyword_match_rev.group(1)

    # 3. Google OTP
    g_match = re.search(r'G-(\d{6})', clean_text, re.IGNORECASE)
    if g_match: return g_match.group(1)

    # 4. Digit sequences fallback
    digit_matches = re.findall(r'(?<!\d)\d{4,8}(?!\d)', clean_text)
    if digit_matches: return digit_matches[0]

    return None

def parse_panel_response(response_text, p_config=None):
    results = []
    p_type = p_config.get("type", "API Panel") if p_config else "API Panel"
    
    n_col_name = p_config.get("num_col_name", "number").lower() if p_config else "number"
    m_col_name = p_config.get("msg_col_name", "message").lower() if p_config else "message"
    n_idx = int(p_config.get("num_col_idx", 1)) - 1 if p_config and p_config.get("num_col_idx") else 1
    m_idx = int(p_config.get("msg_col_idx", 2)) - 1 if p_config and p_config.get("msg_col_idx") else 2

    if p_type == "Auto Captcha Panel":
        try:
            soup = BeautifulSoup(response_text, 'html.parser')
            tables = soup.find_all('table')
            
            for table in tables:
                rows = table.find_all('tr')
                if not rows: continue
                
                # 🌟 Option 1 + Smart HTML Detection: Find correct position using column name and user-given serial
                final_n_idx = n_idx
                final_m_idx = m_idx
                
                # Check first row (Header) and match actual column serial
                header_cells = rows[0].find_all(['th', 'td'])
                for i, cell in enumerate(header_cells):
                    c_text = cell.get_text(strip=True).lower()
                    if n_col_name in c_text: final_n_idx = i
                    if m_col_name in c_text: final_m_idx = i

                for row in rows:
                    cols = row.find_all(['td', 'th'])
                    
                    # Will not take data from header rows (where all th exist)
                    if all(c.name == 'th' for c in cols): continue
                    
                    if len(cols) > max(final_n_idx, final_m_idx):
                        # Extract text from HTML table
                        num_text = cols[final_n_idx].get_text(separator=" ", strip=True)
                        msg_text = cols[final_m_idx].get_text(separator=" ", strip=True)
                        
                        clean_num = re.sub(r'\D', '', num_text)
                        
                        # Ensure number is actually 5-18 digits (to avoid random text)
                        if clean_num and 5 <= len(clean_num) <= 18:
                            otp = extract_otp_code(msg_text)
                            if otp and len(msg_text) > 4:
                                results.append({"number": clean_num, "message": msg_text, "otp": otp})
        except Exception as e:
            print(f"⚠️ Panel HTML parse error: {e}")
    else:
        try:
            data = json.loads(response_text)
            temp_results = []
            
            def process_item(item):
                pot_nums_list = []
                pot_msg = None
                values = []
                
                if isinstance(item, dict):
                    # 1. First try searching by known JSON Key (e.g.: num, phone, sms)
                    lower_keys = {str(k).lower(): v for k, v in item.items()}
                    for k in ["number", "num", "phone", "msisdn", "sender"]:
                        if k in lower_keys:
                            clean_val = re.sub(r'\D', '', str(lower_keys[k]))
                            if 5 <= len(clean_val) <= 18:
                                if clean_val not in pot_nums_list: pot_nums_list.append(clean_val)
                    for k in ["message", "msg", "sms", "content", "text"]:
                        if k in lower_keys:
                            val = str(lower_keys[k])
                            if len(val) > 4:
                                pot_msg = val
                                break
                    values = list(item.values())
                elif isinstance(item, list):
                    values = item

                # 2. If not found by Key, then Smart Blind Scan (check all values)
                for v in values:
                    if isinstance(v, (dict, list)) or v is None: continue
                    v_str = str(v).strip()
                    
                    # Number Detection: 7 to 18 digits
                    clean_v = re.sub(r'\D', '', v_str)
                    if 7 <= len(clean_v) <= 18 and not re.search(r'[a-zA-Z]', v_str):
                        # Logic to skip Date/Time/IP
                        if not re.search(r'\d{4}[-/]\d{2}[-/]\d{2}', v_str) and not re.search(r'\d{2}:\d{2}:\d{2}', v_str) and "." not in v_str:
                            if clean_v not in pot_nums_list:
                                pot_nums_list.append(clean_v)
                    
                    # Message Detection: more than 5 characters and not just numbers
                    if len(v_str) > 4 and not v_str.isdigit():
                        if extract_otp_code(v_str):
                            if pot_msg is None or len(v_str) > len(pot_msg):
                                pot_msg = v_str
                                
                # 🌟 3. Multiple Numbers Logic (User Priority > Second Number > First Number)
                pot_num = None
                if pot_nums_list:
                    matched_user_num = None
                    for n in pot_nums_list:
                        # Check if this number exists in user assigned number list
                        if n in nexa_assigned_numbers or any(n in str(key) for key in nexa_assigned_numbers.keys()):
                            matched_user_num = n
                            break
                    
                    if matched_user_num:
                        pot_num = matched_user_num
                    elif len(pot_nums_list) >= 2:
                        pot_num = pot_nums_list[1] # If not with user, directly take the second number
                    else:
                        pot_num = pot_nums_list[0]
                            
                if pot_num and pot_msg:
                    otp = extract_otp_code(pot_msg)
                    if otp:
                        temp_results.append({"number": pot_num, "message": pot_msg, "otp": otp})
                        
            def traverse_json(node):
                if isinstance(node, list):
                    if len(node) > 0 and not isinstance(node[0], (dict, list)):
                        # It's a flat list representing one record
                        process_item(node)
                    for child in node:
                        if isinstance(child, (dict, list)):
                            traverse_json(child)
                elif isinstance(node, dict):
                    process_item(node)
                    for val in node.values():
                        if isinstance(val, (dict, list)):
                            traverse_json(val)

            traverse_json(data)
            
            # Remove duplicates
            seen = set()
            for r in temp_results:
                uid = f"{r['number']}_{r['otp']}"
                if uid not in seen:
                    seen.add(uid)
                    results.append(r)
        except: pass
        
    return results

# 🌟 Advanced Automated Background Captcha Solver 🌟
def attempt_auto_login(p, idx):
    login_url = _normalize_panel_url(p.get("login_url", ""))
        
    if not login_url.lower().endswith('/login') and not login_url.lower().endswith('.php'):
        login_url = f"{login_url.rstrip('/')}/login"
        
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    })
    
    try:
        res = session.get(login_url, timeout=15)
        soup = BeautifulSoup(res.text, 'html.parser')
        all_text = res.text
        
        # 1. SOLVE CAPTCHA (Exact bot 3.py logic)
        captcha_match = re.search(r'(\d+\s*[\+\-\*]\s*\d+)\s*[=\?:]', all_text)
        if not captcha_match:
            captcha_match = re.search(r'what is\s*(\d+\s*[\+\-\*]\s*\d+)', all_text, re.I)
        if not captcha_match:
            elements = soup.find_all(["label", "div", "span", "p", "strong"])
            for el in elements:
                txt = el.get_text(separator=" ", strip=True)
                if any(op in txt for op in ["+", "-", "*"]):
                    m = re.search(r'(\d+\s*[\+\-\*]\s*\d+)', txt)
                    if m:
                        captcha_match = m
                        break
                        
        captcha_text = captcha_match.group(1) if captcha_match else "0 + 0"
        answer = "0"
        m2 = re.search(r'(\d+)\s*([\+\-\*])\s*(\d+)', captcha_text)
        if m2:
            a, op, b = int(m2.group(1)), m2.group(2), int(m2.group(3))
            if op == '+': answer = str(a + b)
            elif op == '-': answer = str(a - b)
            elif op == '*': answer = str(a * b)

        # 2. FIND FORM
        form = soup.find("form")
        if not form:
            p["login_status"] = "❌ No login form found"
            return False
            
        action = form.get("action")
        from urllib.parse import urljoin, urlparse, parse_qs
        post_url = urljoin(login_url, action) if action else login_url

        form_data = {}
        for hidden in form.find_all("input", type="hidden"):
            name = hidden.get("name")
            if name: form_data[name] = hidden.get("value") or ""
        
        def _fmatch(keywords):
            def _check(val):
                if not val: return False
                v = val.lower()
                return any(k in v for k in keywords)
            return _check

        user_input = (
            form.find("input", {"name": _fmatch(["user", "email", "id"])}) or
            form.find("input", {"type": "text", "placeholder": _fmatch(["user", "email"])}) or
            form.find("input", {"type": "text"})
        )

        pass_input = (
            form.find("input", {"name": _fmatch(["pass", "password", "passwd"])}) or
            form.find("input", {"type": "password"})
        )

        captcha_input = (
            form.find("input", {"placeholder": _fmatch(["answer", "ans", "code", "verification", "value", "captcha"])}) or
            form.find("input", {"name": _fmatch(["ans", "captcha", "ver", "code"])})
        )
        
        user_field = user_input.get("name") if user_input else "username"
        pass_field = pass_input.get("name") if pass_input else "password"
        captcha_field = captcha_input.get("name") if captcha_input else "answer"

        form_data[user_field] = p.get("username", "")
        form_data[pass_field] = p.get("password", "")
        if captcha_input and captcha_field:
            form_data[captcha_field] = answer

        # 3. SUBMIT
        session.headers.update({"Referer": login_url})
        login_req = session.post(post_url, data=form_data, allow_redirects=True, timeout=15)
        
        # 4. VERIFY (Exact bot 3.py check logic)
        msg_link = _normalize_panel_url(p.get("msg_link", ""))
        check_url = msg_link or _default_panel_check_url(login_url)
        
        check_res = session.get(check_url, headers={"Referer": post_url}, timeout=10)
        
        login_success_keywords = [
            'logout', 'log out', 'signout', 'sign out',
            'sms reports', 'dashboard', 'cdrs',
            'welcome', 'profile', 'panel', 'inbox',
            'number', 'report', 'home', 'account',
            'client', 'smscdr', 'numberpanel'
        ]
        combined_text = (login_req.text + check_res.text).lower()
        if not _response_is_login_page(check_res) and any(kw in combined_text for kw in login_success_keywords):
            panel_sessions[idx] = session
            p["login_status"] = "✅ Active & Fetching"
            return True
        else:
            # Show detected field names to help debug
            uf = user_input.get("name") if user_input else "NOT FOUND"
            pf = pass_input.get("name") if pass_input else "NOT FOUND"
            cf = captcha_input.get("name") if captcha_input else "none"
            p["login_status"] = f"❌ Login Failed (fields: user={uf}, pass={pf}, captcha={cf})"
            return False
            
    except Exception as e:
        p["login_status"] = f"❌ Error: {str(e)[:50]}"
        
    return False

def panel_monitor_thread():
    global processed_otps, recent_traffic, panel_sessions, panel_warmup_done
    first_run = True
    while True:
        try:
            for idx, p in enumerate(bot_settings.get("panels", [])):
                if p.get("status") == "ON":
                    stats = _otp_stats_for(p.get("name"))
                    stats["polls"] = int(stats.get("polls", 0)) + 1
                    
                    if p.get("type") == "Auto Captcha Panel":
                        sess = panel_sessions.get(idx)
                        
                        if not sess:
                            now = time.time()
                            if now - p.get("last_login_attempt", 0) < 30: 
                                continue 
                            p["last_login_attempt"] = now
                            
                            success = attempt_auto_login(p, idx)
                            save_db() # Save login status text to show in settings
                            if not success:
                                continue 
                            sess = panel_sessions.get(idx)
                            
                        try:
                            # 🌟 auto sessions with sAjaxSource and Fallback HTML Parser
                            check_url = _normalize_panel_url(p.get("msg_link", "")) or _default_panel_check_url(p.get("login_url", ""))
                            parsed_data, res_text = fetch_cpt_panel_cdrs(p, sess, check_url)
                            p["login_status"] = "✅ Active & Fetching"
                        except Exception as e:
                            if "Session expired" in str(e):
                                p["login_status"] = "❌ Session Expired (Retrying...)"
                                panel_sessions.pop(idx, None)
                            else:
                                p["login_status"] = f"⚠️ Panel Error: {str(e)[:45]}"
                            save_db()
                            continue

                    elif p.get("api_url") or p.get("full_api_url"): 
                        full_url = p.get("full_api_url", "").strip()
                        url = p.get("api_url", "").strip()
                        token = p.get("token", "").strip()
                        if not full_url and not url: continue
                        
                        urls_to_try = []
                        if full_url:
                            urls_to_try.append(full_url)
                        else:
                            if "{token}" in url or "{key}" in url:
                                urls_to_try.append(url.replace("{token}", token).replace("{key}", token))
                            elif "token=" in url or "key=" in url:
                                urls_to_try.append(url)
                            else:
                                sep = '&' if '?' in url else '?'
                                urls_to_try.append(f"{url}{sep}token={token}")
                                urls_to_try.append(f"{url}{sep}key={token}&start=0")
                                urls_to_try.append(f"{url}{sep}key={token}")
                            
                        parsed_data = []
                        # 🌟 Browser Bypass (403 Forbidden Fix)
                        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
                        # 🌟 Zenex Network requires the API key via a "mapikey" header, not a URL param
                        zenex_target = full_url or url
                        if "zenexnetwork.com" in zenex_target:
                            zenex_key = token
                            if not zenex_key:
                                try:
                                    zenex_key = parse_qs(urlparse(zenex_target).query).get('key', [''])[0]
                                except Exception:
                                    zenex_key = ""
                            if zenex_key:
                                headers['mapikey'] = zenex_key
                        for try_url in urls_to_try:
                            try:
                                res = requests.get(try_url, headers=headers, timeout=10)
                                parsed_data = parse_panel_response(res.text, p)
                                if parsed_data:
                                    if not full_url and try_url != url and token:
                                        p["api_url"] = try_url.replace(token, "{token}")
                                        save_db()
                                    break
                            except: continue
                        if not parsed_data: continue
                    elif is_number_api_panel(p):
                        # 🌟 VoltX/FastX SMS API Panel Monitoring
                        parsed_data = []
                        base_url = p.get("base_url", "").strip()
                        api_key = p.get("api_key", "").strip()
                        if not base_url or not api_key:
                            continue
                        getmsg_url = get_number_panel_url(p, "getmsg_url")
                        headers_vx = get_number_panel_headers(p)
                        try:
                            otp_res = requests.get(getmsg_url, headers=headers_vx, timeout=15)
                            if otp_res.status_code != 200:
                                stats["errors"] = int(stats.get("errors", 0)) + 1
                                stats["last_error"] = f"HTTP {otp_res.status_code}"
                                stats["last_note"] = f"getmsg HTTP {otp_res.status_code}"
                                continue
                            try:
                                otp_data = otp_res.json()
                            except Exception:
                                stats["errors"] = int(stats.get("errors", 0)) + 1
                                stats["last_error"] = "getmsg returned non-JSON"
                                stats["last_note"] = "getmsg non-JSON response"
                                continue
                            items = extract_number_panel_otps(otp_data)
                            if "lastSeenGetnumIds" not in p or not isinstance(p["lastSeenGetnumIds"], list):
                                p["lastSeenGetnumIds"] = []
                            is_initial = len(p["lastSeenGetnumIds"]) == 0
                            updated = False
                            for item in items:
                                unique_key = item["unique"]
                                if unique_key and (item["message"] or item["otp"]) and unique_key not in p["lastSeenGetnumIds"]:
                                    p["lastSeenGetnumIds"].append(unique_key)
                                    updated = True
                                    if not is_initial:
                                        parsed_data.append({
                                            "number": item["number"],
                                            "otp": item["otp"],
                                            "message": item["message"],
                                        })
                            if len(p["lastSeenGetnumIds"]) > 500:
                                p["lastSeenGetnumIds"] = p["lastSeenGetnumIds"][-500:]
                            if updated:
                                save_db()
                            stats["last_note"] = f"getmsg OK · rows={len(items)} · new={len(parsed_data)}"
                            if not parsed_data:
                                continue
                        except Exception as e:
                            stats["errors"] = int(stats.get("errors", 0)) + 1
                            stats["last_error"] = str(e)[:120]
                            stats["last_note"] = f"error: {str(e)[:60]}"
                            continue

                    else:
                        continue
                    
                    stats = _otp_stats_for(p.get("name"))
                    stats["last_poll"] = time.time()
                    stats["fetched"] = int(stats.get("fetched", 0)) + len(parsed_data or [])

                    if p.get("type") != "Auto Captcha Panel" and not is_number_api_panel(p):
                        limit = p.get("records", 0)
                        if limit > 0: parsed_data = parsed_data[:limit]
                        
                    # Per-panel warmup: naye panel ke purane OTPs skip karo
                    panel_needs_warmup = p.get("needs_warmup", False)
                    for item in parsed_data:
                        num = item["number"]
                        otp = item["otp"]
                        msg_text = item["message"]
                        unique_id = f"{num}_{otp}"
                        
                        if unique_id not in processed_otps:
                            _track_processed_otp(unique_id)
                            
                            # Warmup: first run ya naye panel ke purane OTPs skip karo
                            if first_run or panel_needs_warmup:
                                continue
                                 
                            char, iso = get_flag_and_code(num)
                            app_full_name, prem_app_html = get_service_info_html(p.get("name", "Panel"), msg_text)
                            current_time = time.time()
                            
                            recent_traffic = [t for t in recent_traffic if current_time - t.get("time", 0) <= 3600]
                            recent_traffic.append({
                                "service": app_full_name,
                                "iso": iso,
                                "flag": char,
                                "number": num,
                                "time": current_time
                            })
                            # Save to local file
                            save_local_db()
                                 
                            display_num = f"+{num}" if not str(num).startswith("+") else str(num)
                            lang = detect_language(msg_text)
                            
                            owners = find_otp_owners(num)
                            
                            first_owner = owners[0] if owners else None
                            masked = mask_number(display_num, user_id=first_owner)
                            
                            group_ok = send_otp_to_groups(
                                num, otp, app_full_name, lang, prem_app_html,
                                display_num, panel_name=p.get("name", "Panel"))

                            user_ok = 0
                            for owner_id in owners:
                                inbox_msg = render_body_text(format_otp_display(
                                    display_num, app_full_name, lang, masked=False,
                                    prem_html=prem_app_html, otp=otp, for_group=False))
                                inbox_kb = [[{"text": f"{otp}", "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": otp}, "style": "success"}]]

                                # Reward addition logic (country-specific or default)
                                reward = get_otp_reward_for_country(iso)
                                if reward > 0:
                                    update_balance(owner_id, reward)
                                    inbox_kb.append([{"text": f"Added {reward} USDT", "icon_custom_emoji_id": "5420396762189831222", "callback_data": "ignore", "style": "primary"}])

                                sent = send_message(owner_id, inbox_msg, reply_markup={"inline_keyboard": inbox_kb})
                                if sent.get("ok"):
                                    user_ok += 1
                                else:
                                    print(f"❌ OTP send failed for user {owner_id}: {sent.get('description', 'Unknown error')}")
                                _increment_local_user(owner_id, "total_otps", 1)

                            stats = _otp_stats_for(p.get("name"))
                            stats["user"] = int(stats.get("user", 0)) + user_ok
                            stats["group"] = int(stats.get("group", 0)) + group_ok
                            if not owners:
                                stats["unmatched"] = int(stats.get("unmatched", 0)) + 1
                            _otp_log_event(p.get("name"), num, otp, owners, group_ok, bool(owners))
                            try:
                                clean_num = str(num).replace("+", "").replace(" ", "").replace("-", "").strip()
                                _track_otp_received(clean_num)
                            except: pass
        except Exception as e:
            print(f"⚠️ Panel monitor error: {str(e)[:80]}")
        if first_run:
            first_run = False
            panel_warmup_done = True
            print("🧹 Panel warmup done — old OTPs skipped, now processing new ones only.")
        # Per-panel warmup complete — flag hatao
        for p in bot_settings.get("panels", []):
            if p.get("needs_warmup"):
                p["needs_warmup"] = False
                save_db()
                print(f"🧹 Panel '{p.get('name')}' warmup done — old OTPs skipped.")
        time.sleep(5) 

# ==========================================
# User Management
# ==========================================
# 🌟 Local User Cache
user_cache = {}

def get_user(user_id):
    if user_id in user_cache: return user_cache[user_id]
    data = _get_local_user(user_id)
    user_cache[user_id] = data
    return data

def update_balance(user_id, amount):
    _increment_local_user(user_id, "balance", float(amount))

def get_otp_reward_for_country(iso):
    """Return country-specific OTP reward if set, otherwise return default reward."""
    cor = bot_settings.get("country_otp_rewards", {})
    if iso and str(iso).upper() in cor:
        return float(cor[str(iso).upper()])
    return float(bot_settings.get("otp_reward", 0.0))

def add_referral(inviter_id, new_user_id):
    u_data = _get_local_user(new_user_id)
    if not u_data.get("ref_paid"):
        _update_local_user(new_user_id, {"referred_by": inviter_id, "ref_paid": True})
        reward = bot_settings.get("refer_reward", 0.0016)
        update_balance(inviter_id, reward)
        _increment_local_user(inviter_id, "total_refers", 1)
        
        ref_msg = (
            f"{PEM['gift']} <b>New Referral !</b>\n"
            f"------------------\n"
            f"\U0001f525 <b>You Received {reward} USDT</b>\n"
            f"------------------\n"
            f"{PEM['user']} <b>From User ID:</b> <code>{new_user_id}</code>"
        )
        send_message(inviter_id, render_body_text(ref_msg))

# ==========================================
# UI Keyboards & Menu Builders
# ==========================================
def get_cancel_kb():
    return {"inline_keyboard": [[sys_button("cancel", callback_data="cancel_state")]]}

def get_menu_buttons():
    """Admin editable main keyboard buttons."""
    buttons = bot_settings.get("menu_buttons")
    if not isinstance(buttons, list) or not buttons:
        return deepcopy(DEFAULT_MENU_BUTTONS)
    return buttons


def get_menu_per_row():
    try:
        return max(1, min(2, int(bot_settings.get("menu_buttons_per_row", 2))))
    except (TypeError, ValueError):
        return 2


def menu_action_of_button(button):
    action = str((button or {}).get("action", "")).strip()
    return action if action in MENU_ACTION_LABELS else ""


def menu_button_label(button):
    action = menu_action_of_button(button)
    label = str((button or {}).get("label") or MENU_ACTION_LABELS.get(action, "Button")).strip()
    return label[:64] or MENU_ACTION_LABELS.get(action, "Button")


def _render_menu_button(button):
    action = menu_action_of_button(button)
    if not action:
        return None
    item = {"text": _unicode_bold_text(menu_button_label(button)), "style": button.get("style", "primary")}
    if button.get("emoji"):
        item["icon_custom_emoji_id"] = str(button["emoji"])
    return item


def main_menu(user_id):
    """Reply keyboard built from admin settings (rename / add / remove / emoji)."""
    per_row = get_menu_per_row()
    kb, current, used_actions = [], [], set()
    for button in get_menu_buttons():
        if not isinstance(button, dict) or not button.get("enabled", True):
            continue
        action = menu_action_of_button(button)
        if not action:
            continue
        if action == "admin_panel" and not is_admin(user_id):
            continue
        if button.get("admin_only") and not is_admin(user_id):
            continue
        item = _render_menu_button(button)
        if not item:
            continue
        used_actions.add(action)
        current.append(item)
        if len(current) >= per_row:
            kb.append(current)
            current = []
    if current:
        kb.append(current)
    # Admins must always be able to reach the admin panel.
    if is_admin(user_id) and "admin_panel" not in used_actions:
        kb.append([{"text": "Admin Panel", "icon_custom_emoji_id": DEFAULT_BUTTON_EMOJI["admin_panel"], "style": "danger"}])
    if not kb:
        kb = [[{"text": "GET NUMBER", "icon_custom_emoji_id": DEFAULT_BUTTON_EMOJI["get_number"], "style": "primary"}]]
    return {"keyboard": kb, "resize_keyboard": True}


def resolve_menu_action(text):
    """Map incoming text to a menu action, including Unicode-bold keyboard labels."""
    raw = str(text or "").strip()
    # Reverse mathematical bold characters before comparing with configured labels.
    reverse = {}
    for i, ch in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
        reverse[chr(0x1D400 + i)] = ch
    for i, ch in enumerate("abcdefghijklmnopqrstuvwxyz"):
        reverse[chr(0x1D41A + i)] = ch
    for i, ch in enumerate("0123456789"):
        reverse[chr(0x1D7CE + i)] = ch
    raw = "".join(reverse.get(ch, ch) for ch in raw)
    if not raw:
        return ""
    key = re.sub(r"\s+", " ", raw).casefold()
    for button in get_menu_buttons():
        if not isinstance(button, dict):
            continue
        label = re.sub(r"\s+", " ", str(button.get("label", ""))).strip().casefold()
        if label and label == key:
            action = menu_action_of_button(button)
            if action:
                return action
    return LEGACY_MENU_ACTION_BY_TEXT.get(key.replace("\U0001f510", "").strip(), "")


def build_group_otp_keyboard(otp, group):
    """Copy-OTP button + the admin defined extra buttons of one OTP group."""
    kb = [[{"text": otp, "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": otp}, "style": "success"}]]
    for btn in (group or {}).get("buttons", []):
        if not isinstance(btn, dict):
            continue
        b_obj = {"text": btn.get("text", ""), "url": btn.get("url", ""), "style": "primary"}
        if "icon_custom_emoji_id" in btn:
            b_obj["icon_custom_emoji_id"] = btn["icon_custom_emoji_id"]
        kb.append([b_obj])
    return {"inline_keyboard": kb}


def render_group_otp_message(group, display_num, app_full_name, lang, prem_html, otp, random_style=None):
    """Group message in the global style, or in that group's own style."""
    style_id = str((group or {}).get("style") or "auto")
    if style_id in ("", "auto"):
        style_id = None
    # 🎲 All mode: every group of this delivery shares one randomly picked style.
    if style_id == RANDOM_OTP_STYLE_ID or (style_id is None and active_otp_style_id(True) == RANDOM_OTP_STYLE_ID):
        style_id = str(((random_style or next_random_otp_style("group")) or {}).get("id") or OTP_STYLE_LIBRARY[0]["id"])
    return render_body_text(format_otp_display(
        display_num, app_full_name, lang, masked=True, prem_html=prem_html,
        otp=otp, style_id=style_id, for_group=True,
    ))


def send_otp_to_groups(num, otp, app_full_name, lang, prem_html, display_num, panel_name=""):
    """Send one OTP to every OTP group. Returns how many groups accepted it."""
    group_ok = 0
    groups = bot_settings.get("fw_groups", []) or []
    # 🎲 All mode: pick ONE style for this OTP so every group sees the same card,
    # and the next OTP gets a different one.
    random_style = None
    if active_otp_style_id(True) == RANDOM_OTP_STYLE_ID or any(
        str((g or {}).get("style") or "auto") == RANDOM_OTP_STYLE_ID for g in groups
    ):
        random_style = next_random_otp_style("group")
    for fw in groups:
        try:
            msg = render_group_otp_message(fw, display_num, app_full_name, lang, prem_html, otp,
                                           random_style=random_style)
            kb = build_group_otp_keyboard(otp, fw)
            res = send_message(fw["chat_id"], msg, reply_markup=kb)
            if res.get("ok"):
                group_ok += 1
            else:
                print(f"❌ Group send failed [{fw['chat_id']}]: {res.get('description', 'Unknown error')}")
        except Exception as exc:
            print(f"❌ Group render error [{fw.get('chat_id')}]: {str(exc)[:80]}")
    return group_ok


# ==========================================
# Admin UI: Main Menu Button Manager
# ==========================================
def menu_button_manager_text(notice=""):
    buttons = get_menu_buttons()
    lines = []
    if notice:
        lines.extend([notice, ""])
    lines.append(f"{PEM['gear']} <b>MENU BUTTON MANAGER</b>")
    lines.append("\u2501" * 16)
    lines.append(f"Total buttons: <b>{len(buttons)}</b> | Per row: <b>{get_menu_per_row()}</b>")
    lines.append("✅ visible · 🚫 hidden · 🎨 has emoji · 👑 admin only")
    lines.append("")
    if not buttons:
        lines.append("<i>No buttons yet — add one below.</i>")
    for idx, button in enumerate(buttons):
        if not isinstance(button, dict):
            continue
        state = "✅" if button.get("enabled", True) else "🚫"
        emoji_state = "🎨" if button.get("emoji") else "▫️"
        admin_state = " 👑" if button.get("admin_only") else ""
        lines.append(
            f"{idx + 1}. {state}{emoji_state}{admin_state} <b>{html.escape(menu_button_label(button))}</b> "
            f"→ <code>{html.escape(str(button.get('action', '')))}</code>"
        )
    lines.append("")
    lines.append("<i>Tap a button below to rename it, change emoji, move it or delete it.</i>")
    return render_body_text("\n".join(lines))


def menu_button_manager_keyboard():
    kb = []
    for idx, button in enumerate(get_menu_buttons()):
        if not isinstance(button, dict):
            continue
        emoji = str(button.get("emoji") or DEFAULT_BUTTON_EMOJI["admin_panel"])
        kb.append([{
            "text": f"{idx + 1}. {menu_button_label(button)}",
            "icon_custom_emoji_id": emoji,
            "callback_data": f"mb_btn_{idx}",
            "style": button.get("style", "primary"),
        }])
    kb.append([
        {"text": "➕ Add Button", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "mb_add", "style": "success"},
        {"text": f"↔️ Per Row: {get_menu_per_row()}", "icon_custom_emoji_id": "5192739271886282680", "callback_data": "mb_perrow", "style": "primary"},
    ])
    kb.append([
        {"text": "⚙️ System Buttons", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "sys_menu", "style": "primary"},
        {"text": "👀 Preview", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "mb_preview", "style": "success"},
    ])
    kb.append([{"text": "♻️ Reset Menu Buttons", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "mb_reset", "style": "danger"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}])
    return {"inline_keyboard": kb}


def menu_button_detail_text(idx):
    button = get_menu_buttons()[idx]
    lines = [
        f"{PEM['gear']} <b>EDIT BUTTON #{idx + 1}</b>",
        "\u2501" * 16,
        f"📝 Label: <b>{html.escape(menu_button_label(button))}</b>",
        f"⚙️ Action: <code>{html.escape(str(button.get('action', '')))}</code>",
        f"😀 Emoji ID: <code>{html.escape(str(button.get('emoji') or 'None'))}</code>",
        f"🎨 Style: <b>{button.get('style', 'primary')}</b>",
        f"👁 Visible: <b>{'YES' if button.get('enabled', True) else 'NO'}</b>",
        f"👑 Admin only: <b>{'YES' if button.get('admin_only') else 'NO'}</b>",
    ]
    return render_body_text("\n".join(lines))


def menu_button_detail_keyboard(idx):
    button = get_menu_buttons()[idx]
    visible = button.get("enabled", True)
    return {"inline_keyboard": [
        [{"text": "✏️ Rename Button", "icon_custom_emoji_id": "5395444784611480792", "callback_data": f"mb_ren_{idx}", "style": "primary"}],
        [{"text": "😀 Set Emoji", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"mb_emo_{idx}", "style": "success"},
         {"text": "🗑 Remove Emoji", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"mb_emoclr_{idx}", "style": "danger"}],
        [{"text": f"🎨 Style: {button.get('style', 'primary')}", "icon_custom_emoji_id": "5190751148704833975", "callback_data": f"mb_style_{idx}", "style": "primary"},
         {"text": f"👁 {'Visible' if visible else 'Hidden'}", "icon_custom_emoji_id": "5352694861990501856", "callback_data": f"mb_tog_{idx}", "style": "success" if visible else "danger"}],
        [{"text": f"👑 Admin Only: {'YES' if button.get('admin_only') else 'NO'}", "icon_custom_emoji_id": "5420155432272438703", "callback_data": f"mb_adm_{idx}", "style": "primary"}],
        [{"text": "⬆️ Move Up", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"mb_up_{idx}", "style": "primary"},
         {"text": "⬇️ Move Down", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"mb_dn_{idx}", "style": "primary"}],
        [{"text": "🗑 Delete Button", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"mb_del_{idx}", "style": "danger"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "mb_menu", "style": "danger"}],
    ]}


def menu_action_picker_keyboard():
    kb = []
    for action, label in MENU_ACTION_LABELS.items():
        kb.append([{
            "text": label,
            "icon_custom_emoji_id": DEFAULT_BUTTON_EMOJI.get(action, "5420155432272438703"),
            "callback_data": f"mb_new_{action}",
            "style": "success",
        }])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "mb_menu", "style": "danger"}])
    return {"inline_keyboard": kb}


# ==========================================
# Admin UI: OTP message style manager
# ==========================================
def _sample_style_message(style_id=None, for_group=True):
    return render_body_text(build_otp_message(
        "+8801712345678", "FACEBOOK", "#EN", masked=for_group,
        otp="123456", style_id=style_id, for_group=for_group,
    ))


def _style_name(style_id):
    if str(style_id) == RANDOM_OTP_STYLE_ID:
        return RANDOM_OTP_STYLE_LABEL
    return str(get_otp_style(style_id).get("name") or style_id)


def sms_style_page_text(notice=""):
    group_style = preview_otp_style(for_group=True)
    user_style = preview_otp_style(for_group=False)
    lines = []
    if notice:
        lines.extend([notice, ""])
    lines.append(f"{PEM['msg']} <b>SMS / OTP STYLE MANAGER</b>")
    lines.append("\u2501" * 16)
    group_label = _style_name(active_otp_style_id(True))
    user_label = _style_name(active_otp_style_id(False))
    lines.append(f"👥 <b>Group style:</b> {html.escape(group_label)}"
                 + ("  <i>(প্রতি SMS-এ এলোমেলো নতুন স্টাইল)</i>" if active_otp_style_id(True) == RANDOM_OTP_STYLE_ID else ""))
    lines.append(_sample_style_message(group_style["id"], for_group=True))
    lines.append("")
    lines.append(f"👤 <b>User style:</b> {html.escape(user_label)}"
                 + ("  <i>(এলোমেলো)</i>" if active_otp_style_id(False) == RANDOM_OTP_STYLE_ID else ""))
    lines.append(_sample_style_message(user_style["id"], for_group=False))
    lines.append("")
    lines.append(f"🎨 Total styles: <b>{len(all_otp_styles())}</b> "
                 f"(built-in {len(OTP_STYLE_LIBRARY)}, custom {len(get_custom_otp_styles())})")
    lines.append(f"🔤 Placeholders: <code>{html.escape(OTP_STYLE_PLACEHOLDERS)}</code>")
    return render_body_text("\n".join(lines))


def sms_style_page_keyboard():
    return {"inline_keyboard": [
        [{"text": f"👥 Group Style: {_style_name(active_otp_style_id(True))}"[:60], "icon_custom_emoji_id": "5193063022226086560", "callback_data": "ostyle_pick_g", "style": "primary"}],
        [{"text": f"👤 User Style: {_style_name(active_otp_style_id(False))}"[:60], "icon_custom_emoji_id": "5352861489541714456", "callback_data": "ostyle_pick_u", "style": "primary"}],
        [{"text": "➕ Add Custom Style", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "ostyle_add", "style": "success"},
         {"text": f"🗂 Custom ({len(get_custom_otp_styles())})", "icon_custom_emoji_id": "5352721946054268944", "callback_data": "ostyle_custom", "style": "primary"}],
        [{"text": "♻️ Reset Styles", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "ostyle_reset", "style": "danger"},
         {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}],
    ]}


def sms_style_picker_text(for_group=True):
    kind = "GROUP" if for_group else "USER"
    current = active_otp_style_id(for_group)
    lines = [
        f"🎨 <b>SELECT {kind} STYLE</b>",
        "\u2501" * 16,
        f"Active: <b>{html.escape(_style_name(current))}</b>",
        "",
        "🎲 <b>All / Random</b> — প্রতি SMS-এ অটো এলোমেলো একটা স্টাইল যাবে,",
        "পরপর দুইটা SMS একই স্টাইলে যাবে না।",
        "",
        "<i>Tap a style to apply it. 👀 sends a live preview to you.</i>",
    ]
    return render_body_text("\n".join(lines))


def sms_style_picker_keyboard(for_group=True):
    kind = "g" if for_group else "u"
    current = active_otp_style_id(for_group)
    kb = []
    kb.append([{
        "text": ("✅ " if current == RANDOM_OTP_STYLE_ID else "🎲 ") + "All — Random (mix every style)",
        "callback_data": f"ostyle_set_{kind}__{RANDOM_OTP_STYLE_ID}",
        "style": "success" if current == RANDOM_OTP_STYLE_ID else "primary",
    }])
    for style in all_otp_styles():
        style_id = style["id"]
        mark = "✅ " if style_id == current else ""
        kb.append([
            {"text": f"{mark}{str(style.get('name') or style_id)[:32]}", "callback_data": f"ostyle_set_{kind}__{style_id}", "style": "success" if style_id == current else "primary"},
            {"text": "👀", "icon_custom_emoji_id": "5352552689983067014", "callback_data": f"ostyle_prev_{kind}__{style_id}", "style": "primary"},
        ])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "ostyle_menu", "style": "danger"}])
    return {"inline_keyboard": kb}


def sms_custom_style_text():
    styles = get_custom_otp_styles()
    lines = [f"{PEM['file']} <b>CUSTOM STYLES</b>", "\u2501" * 16]
    if not styles:
        lines.append("<i>No custom style yet. Tap ➕ Add Custom Style.</i>")
    for style in styles:
        mask_state = "masked" if style.get("mask", True) else "full number"
        lines.append(f"• <b>{html.escape(str(style.get('name')))}</b> (<code>{html.escape(str(style.get('id')))}</code>) · {mask_state}")
    lines.append("")
    lines.append(f"🔤 Placeholders: <code>{html.escape(OTP_STYLE_PLACEHOLDERS)}</code>")
    return render_body_text("\n".join(lines))


def sms_custom_style_keyboard():
    kb = []
    for style in get_custom_otp_styles():
        style_id = str(style.get("id"))
        kb.append([
            {"text": f"✏️ {str(style.get('name'))[:28]}", "icon_custom_emoji_id": "5395444784611480792", "callback_data": f"ostyle_edit__{style_id}", "style": "primary"},
            {"text": "👁", "icon_custom_emoji_id": "5352552689983067014", "callback_data": f"ostyle_mask__{style_id}", "style": "success"},
            {"text": "🗑", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"ostyle_del__{style_id}", "style": "danger"},
        ])
    kb.append([{"text": "➕ Add Custom Style", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "ostyle_add", "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "ostyle_menu", "style": "primary"}])
    return {"inline_keyboard": kb}


def sms_style_preview_send(chat_id, for_group=True, style_id=None):
    text = _sample_style_message(style_id, for_group=for_group)
    kb = {"inline_keyboard": [[{"text": "123456", "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": "123456"}, "style": "success"}]]}
    return send_message(chat_id, text, reply_markup=kb)


def otp_group_style_text(idx):
    groups = bot_settings.get("fw_groups", [])
    if not isinstance(idx, int) or not (0 <= idx < len(groups)):
        return render_body_text("❌ Group not found.")
    group = groups[idx]
    current = str(group.get("style") or "auto")
    label = "Auto (global)" if current == "auto" else _style_name(current)
    return render_body_text(
        f"🎨 <b>GROUP STYLE</b>\n" + "\u2501" * 16 +
        f"\n👥 Group: <code>{html.escape(str(group.get('chat_id')))}</code>\n"
        f"Active: <b>{html.escape(label)}</b>\n\n"
        "<i>This group can use its own style, or follow the global group style.</i>"
    )


def otp_group_style_keyboard(idx):
    groups = bot_settings.get("fw_groups", [])
    current = str((groups[idx] or {}).get("style") or "auto") if 0 <= idx < len(groups) else "auto"
    kb = [[{"text": ("✅ " if current == "auto" else "") + "Auto (global)", "callback_data": f"fwset__{idx}__auto", "style": "success" if current == "auto" else "primary"}]]
    kb.append([{
        "text": ("✅ " if current == RANDOM_OTP_STYLE_ID else "🎲 ") + "All — Random (mix every style)",
        "callback_data": f"fwset__{idx}__{RANDOM_OTP_STYLE_ID}",
        "style": "success" if current == RANDOM_OTP_STYLE_ID else "primary",
    }])
    for style in all_otp_styles():
        style_id = style["id"]
        mark = "✅ " if current == style_id else ""
        kb.append([{"text": f"{mark}{str(style.get('name'))[:36]}", "callback_data": f"fwset__{idx}__{style_id}", "style": "success" if current == style_id else "primary"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_otp_groups", "style": "danger"}])
    return {"inline_keyboard": kb}


# ==========================================
# Admin UI: Waiting SMS designer
# ==========================================
WSMS_PLACEHOLDERS = "{numbers} · {count} · {service} · {country}"


def _wsms_entry(key):
    store = bot_settings.setdefault("custom_messages", {})
    entry = store.get(key)
    if not isinstance(entry, dict):
        entry = {"text": (DEFAULT_CUSTOM_MESSAGES.get(key) or {}).get("text", ""), "buttons": []}
        store[key] = entry
    if not isinstance(entry.get("buttons"), list):
        entry["buttons"] = []
    if not str(entry.get("text") or "").strip():
        entry["text"] = (DEFAULT_CUSTOM_MESSAGES.get(key) or {}).get("text", "")
    return entry


def wsms_sample_session():
    return {
        "nums": ["237628374519"],
        "service": "FACEBOOK",
        "country": "Cameroon",
        "remove_cc": False,
        "change_callback": "ignore",
        "custom_menu": "waiting",
    }


def _wsms_preview(key="waiting"):
    if key == "waiting":
        return waiting_screen_text(wsms_sample_session())
    return waiting_expired_text()


def wsms_page_text(notice=""):
    entry = _wsms_entry("waiting")
    expired_entry = _wsms_entry("waiting_expired")
    buttons = [str(b.get("text", "?")) for b in entry.get("buttons", []) if isinstance(b, dict)]
    lines = []
    if notice:
        lines.extend([notice, ""])
    lines.append(f"{PEM['msg']} <b>WAITING SMS DESIGNER</b>")
    lines.append("\u2501" * 16)
    lines.append("<b>Current Waiting message:</b>")
    lines.append(_wsms_preview("waiting"))
    lines.append("")
    lines.append(f"🔤 Placeholders: <code>{WSMS_PLACEHOLDERS}</code>")
    lines.append(f"🔘 Inline buttons: <b>{len(buttons)}</b>" + (f" → {html.escape(' | '.join(buttons))}" if buttons else ""))
    _flags = waiting_action_flags()
    _visible = sum(1 for _k, _l in WAITING_ACTION_DEFS if _flags.get(_k, True))
    lines.append(f"👁 Action buttons: <b>{_visible}/{len(WAITING_ACTION_DEFS)}</b> visible (numbers always shown)")
    lines.append("")
    lines.append("<b>Expired message:</b>")
    lines.append(_wsms_preview("waiting_expired"))
    return render_body_text("\n".join(lines))


def wsms_page_keyboard():
    return {"inline_keyboard": [
        [{"text": "✏️ Edit Waiting Text", "icon_custom_emoji_id": "5395444784611480792", "callback_data": "wsms_edit", "style": "primary"},
         {"text": "⏳ Edit Expired Text", "icon_custom_emoji_id": "5336997731481193790", "callback_data": "wsms_exp", "style": "primary"}],
        [{"text": "🔘 Waiting Buttons (add/remove)", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "wsms_btns", "style": "success"},
         {"text": "⏳ Expired Buttons", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "wsms_btns_exp", "style": "success"}],
        [{"text": "👁 Hide / Show Buttons", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "wsms_hide", "style": "danger"}],
        [{"text": "👀 Send Live Preview", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "wsms_preview", "style": "primary"}],
        [{"text": "♻️ Reset To Default", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "wsms_reset", "style": "danger"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}],
    ]}


def wsms_buttons_keyboard(expired=False):
    key = "waiting_expired" if expired else "waiting"
    entry = _wsms_entry(key)
    kb = []
    for idx, btn in enumerate(entry.get("buttons", [])):
        if not isinstance(btn, dict):
            continue
        label = str(btn.get("text", "Button"))[:40]
        kb.append([
            {"text": f"🗑 {label}", "icon_custom_emoji_id": str(btn.get("icon_custom_emoji_id") or "5420130255174145507"), "callback_data": f"wsms_delbtn_{'e' if expired else 'w'}_{idx}", "style": "danger"},
        ])
    add_cb = "wsms_addbtn_exp" if expired else "wsms_addbtn"
    kb.append([{"text": "➕ Add Inline Button", "icon_custom_emoji_id": "5420323438508155202", "callback_data": add_cb, "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wsms_menu", "style": "primary"}])
    return {"inline_keyboard": kb}


def wsms_buttons_text(expired=False):
    key = "waiting_expired" if expired else "waiting"
    entry = _wsms_entry(key)
    count = len([b for b in entry.get("buttons", []) if isinstance(b, dict)])
    title = "EXPIRED MESSAGE BUTTONS" if expired else "WAITING MESSAGE BUTTONS"
    return render_body_text(
        f"{PEM['gear']} <b>{title}</b>\n" + "\u2501" * 16 +
        f"\nButtons: <b>{count}</b>\n\n"
        "<i>Tap 🗑 to remove a button, or ➕ to add one.\n"
        "New button format: <code>Button Text - https://link.com</code>\n"
        "Premium emoji is supported in the button text.</i>"
    )


def wsms_preview_send(chat_id):
    session = wsms_sample_session()
    kb = waiting_sms_keyboard(session)
    kb = _insert_waiting_custom_buttons(kb, session)
    return send_message(chat_id, waiting_screen_text(session), reply_markup={"inline_keyboard": kb})


# ==========================================
# Admin UI: Inline Button Editor (per menu)
# ==========================================
def menu_inline_button_detail_text(menu_key, idx):
    buttons = bot_settings.get("custom_messages", {}).get(menu_key, {}).get("buttons", [])
    btn = buttons[idx]
    lines = [
        f"{PEM['gear']} <b>INLINE BUTTON #{idx + 1}</b>",
        "\u2501" * 16,
        f"📋 Menu: <code>{html.escape(menu_key)}</code>",
        f"📝 Label: <b>{html.escape(str(btn.get('text', '')))}</b>",
        f"🔗 URL: <code>{html.escape(str(btn.get('url') or 'None'))}</code>",
        f"😀 Emoji ID: <code>{html.escape(str(btn.get('icon_custom_emoji_id') or 'None'))}</code>",
        f"🎨 Style: <b>{btn.get('style', 'primary')}</b>",
    ]
    return render_body_text("\n".join(lines))


def menu_inline_button_detail_keyboard(menu_key, idx):
    return {"inline_keyboard": [
        [{"text": "✏️ Rename", "icon_custom_emoji_id": "5395444784611480792", "callback_data": f"mi_ren_{menu_key}_{idx}", "style": "primary"}],
        [{"text": "😀 Set Emoji", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"mi_emo_{menu_key}_{idx}", "style": "success"},
         {"text": "🗑 Remove Emoji", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"mi_emoclr_{menu_key}_{idx}", "style": "danger"}],
        [{"text": "🔗 Change URL", "icon_custom_emoji_id": "5420517437885943844", "callback_data": f"mi_url_{menu_key}_{idx}", "style": "primary"}],
        [{"text": "🎨 Change Style", "icon_custom_emoji_id": "5190751148704833975", "callback_data": f"mi_style_{menu_key}_{idx}", "style": "primary"}],
        [{"text": "🗑 Delete Button", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"md_delbtn_{menu_key}_{idx}", "style": "danger"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"md_btns_{menu_key}", "style": "danger"}],
    ]}


def system_buttons_list_text():
    lines = [
        f"{PEM['gear']} <b>SYSTEM BUTTONS</b>",
        "\u2501" * 16,
        "<i>These buttons are part of the user flow (waiting screen, 2FA, support…).\n"
        "Rename them or change their emoji here — their action stays the same.</i>",
        "",
    ]
    store = _system_button_store()
    for key, default in SYSTEM_BUTTON_DEFAULTS.items():
        override = store.get(key) if isinstance(store.get(key), dict) else {}
        label = override.get("text") or default.get("text")
        emoji_id = override["emoji"] if "emoji" in override else default.get("emoji")
        emoji_state = "🎨" if emoji_id else "▫️"
        edited = " ✏️" if override else ""
        lines.append(f"• {emoji_state} <b>{html.escape(str(label))}</b>{edited} — <code>{key}</code>")
    return render_body_text("\n".join(lines))


def system_buttons_list_keyboard():
    kb = []
    store = _system_button_store()
    for key, default in SYSTEM_BUTTON_DEFAULTS.items():
        override = store.get(key) if isinstance(store.get(key), dict) else {}
        label = str(override.get("text") or default.get("text"))[:40]
        emoji_id = override["emoji"] if "emoji" in override else default.get("emoji")
        item = {"text": label, "callback_data": f"sys_btn_{key}", "style": default.get("style", "primary")}
        if emoji_id:
            item["icon_custom_emoji_id"] = str(emoji_id)
        kb.append([item])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "mb_menu", "style": "danger"}])
    return {"inline_keyboard": kb}


def system_button_detail_text(key):
    default = SYSTEM_BUTTON_DEFAULTS.get(key, {})
    store = _system_button_store()
    override = store.get(key) if isinstance(store.get(key), dict) else {}
    emoji_id = override["emoji"] if "emoji" in override else default.get("emoji")
    lines = [
        f"{PEM['gear']} <b>SYSTEM BUTTON</b> · <code>{html.escape(key)}</code>",
        "\u2501" * 16,
        f"📝 Current label: <b>{html.escape(str(override.get('text') or default.get('text')))}</b>",
        f"😀 Emoji ID: <code>{html.escape(str(emoji_id) if emoji_id else 'None')}</code>",
        f"🎨 Style: <b>{default.get('style', 'primary')}</b>",
        f"✏️ Customised: <b>{'YES' if override else 'NO'}</b>",
    ]
    return render_body_text("\n".join(lines))


def system_button_detail_keyboard(key):
    default = SYSTEM_BUTTON_DEFAULTS.get(key, {})
    emoji_id = _system_button_store().get(key, {})
    emoji_id = emoji_id.get("emoji") if isinstance(emoji_id, dict) else None
    if emoji_id is None:
        emoji_id = default.get("emoji")
    kb = [
        [{"text": "✏️ Rename", "icon_custom_emoji_id": "5395444784611480792", "callback_data": f"sys_ren_{key}", "style": "primary"}],
        [{"text": "😀 Set Emoji", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"sys_emo_{key}", "style": "success"},
         {"text": "🗑 Remove Emoji", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"sys_emoclr_{key}", "style": "danger"}],
        [{"text": "♻️ Reset This Button", "icon_custom_emoji_id": "5192812028632274956", "callback_data": f"sys_reset_{key}", "style": "danger"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "sys_menu", "style": "primary"}],
    ]
    return {"inline_keyboard": kb}


def _button_cancel_row(callback_data):
    return {"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": callback_data, "style": "danger"}]]}


def _button_target_object(target):
    if not isinstance(target, dict):
        return None
    if target.get("kind") == "system":
        return _system_target_entry(str(target.get("key", "")))
    idx = target.get("idx")
    if not isinstance(idx, int):
        return None
    if target.get("kind") == "menu":
        buttons = get_menu_buttons()
        if 0 <= idx < len(buttons) and isinstance(buttons[idx], dict):
            return buttons[idx]
        return None
    if target.get("kind") == "inline":
        menu_key = str(target.get("menu", ""))
        buttons = bot_settings.get("custom_messages", {}).get(menu_key, {}).get("buttons", [])
        if 0 <= idx < len(buttons) and isinstance(buttons[idx], dict):
            return buttons[idx]
        return None
    if target.get("kind") == "system":
        return None
    return None


def _system_target_entry(key):
    """Mutable override dict for one fixed system button."""
    if key not in SYSTEM_BUTTON_DEFAULTS:
        return None
    store = _system_button_store()
    entry = store.get(key)
    if not isinstance(entry, dict):
        entry = {}
        store[key] = entry
    return entry


def _button_target_field_key(target, field):
    kind = (target or {}).get("kind")
    mapping = {
        ("menu", "label"): "label",
        ("menu", "emoji"): "emoji",
        ("inline", "label"): "text",
        ("inline", "emoji"): "icon_custom_emoji_id",
        ("menu", "url"): "url",
        ("inline", "url"): "url",
        ("system", "label"): "text",
        ("system", "emoji"): "emoji",
    }
    return mapping.get((kind, field), field)


def _set_button_target_field(chat_id, field, value):
    target = (temp_data.get(chat_id) or {}).get("btn_target")
    obj = _button_target_object(target)
    if obj is None:
        return False
    key = _button_target_field_key(target, field)
    if value in (None, ""):
        # System buttons must remember an explicitly removed emoji ("") so the
        # default premium emoji does not come back.
        if (target or {}).get("kind") == "system" and key == "emoji":
            obj["emoji"] = ""
        else:
            obj.pop(key, None)
    else:
        obj[key] = value
    save_db()
    return True


def _edit_button_screen(chat_id, msg_id, target, notice=""):
    target = target or {}
    if target.get("kind") == "menu":
        idx = target.get("idx")
        buttons = get_menu_buttons()
        if isinstance(idx, int) and 0 <= idx < len(buttons):
            text = menu_button_detail_text(idx)
            if notice:
                text = render_body_text(notice) + "\n\n" + text
            edit_message(chat_id, msg_id, text, reply_markup=menu_button_detail_keyboard(idx))
            return
        text = menu_button_manager_text(notice)
        edit_message(chat_id, msg_id, text, reply_markup=menu_button_manager_keyboard())
        return
    if target.get("kind") == "system":
        key = str(target.get("key", ""))
        if key in SYSTEM_BUTTON_DEFAULTS:
            text = system_button_detail_text(key)
            if notice:
                text = render_body_text(notice) + "\n\n" + text
            edit_message(chat_id, msg_id, text, reply_markup=system_button_detail_keyboard(key))
            return
        edit_message(chat_id, msg_id, system_buttons_list_text(), reply_markup=system_buttons_list_keyboard())
        return
    menu_key = str(target.get("menu", ""))
    idx = target.get("idx")
    buttons = bot_settings.get("custom_messages", {}).get(menu_key, {}).get("buttons", [])
    if isinstance(idx, int) and 0 <= idx < len(buttons):
        text = menu_inline_button_detail_text(menu_key, idx)
        if notice:
            text = render_body_text(notice) + "\n\n" + text
        edit_message(chat_id, msg_id, text, reply_markup=menu_inline_button_detail_keyboard(menu_key, idx))
        return
    edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>Edit Inline Buttons: {html.escape(menu_key.upper())}</b>"), reply_markup=menu_buttons_list_keyboard(menu_key))


# ==========================================
# OTP pipeline helpers (FastX / VoltX / Stex + Nexa)
# ==========================================
otp_pipeline_stats = {}
otp_pipeline_events = deque(maxlen=80)


def _otp_stats_for(panel_name):
    key = str(panel_name or "Panel")
    stats = otp_pipeline_stats.get(key)
    if not isinstance(stats, dict):
        stats = {
            "polls": 0, "fetched": 0, "user": 0, "group": 0, "unmatched": 0,
            "errors": 0, "last_poll": 0, "last_note": "", "last_error": "",
        }
        otp_pipeline_stats[key] = stats
    return stats


def _otp_log_event(panel_name, number, otp, owners, groups, delivered):
    otp_pipeline_events.append({
        "time": time.time(),
        "panel": str(panel_name or "Panel"),
        "number": str(number or ""),
        "otp": str(otp or ""),
        "owners": list(owners or []),
        "groups": int(groups or 0),
        "delivered": bool(delivered),
    })


def _numbers_match(left, right):
    a = str(left or "").replace("+", "").replace(" ", "").replace("-", "").strip()
    b = str(right or "").replace("+", "").replace(" ", "").replace("-", "").strip()
    if not a or not b:
        return False
    if a == b:
        return True
    if len(a) >= 8 and a.endswith(b[-8:]):
        return True
    if len(b) >= 8 and b.endswith(a[-8:]):
        return True
    return False


def find_otp_owners(num):
    """Return every user that owns this number (live session + saved assignments).

    VoltX/FastX numbers are stored in voltx_assigned_numbers and Nexa numbers in
    nexa_assigned_numbers, so ownership survives bot restarts.
    """
    owners = []
    for uid, session_data in list(user_active_sessions.items()):
        for act_num in session_data.get("nums", []):
            if _numbers_match(act_num, num):
                owners.append(uid)
                break
    if not owners:
        for source in (voltx_assigned_numbers, nexa_assigned_numbers):
            try:
                items = list(source.items())
            except Exception:
                continue
            for saved_num, owner in items:
                if _numbers_match(saved_num, num):
                    owners.append(owner)
    return list(dict.fromkeys([owner for owner in owners if owner]))


def extract_number_panel_otps(payload):
    """Normalise a FastX / VoltX / Stex getmsg response into OTP records."""
    records = []
    if isinstance(payload, list):
        records = payload
    elif isinstance(payload, dict):
        candidates = [payload.get("otps"), payload.get("results"), payload.get("records")]
        data = payload.get("data")
        if isinstance(data, list):
            candidates.insert(0, data)
        elif isinstance(data, dict):
            candidates = [data.get("otps"), data.get("data"), data.get("list"),
                          data.get("results"), data.get("records")] + candidates
        for candidate in candidates:
            if isinstance(candidate, list):
                records = candidate
                break
    items = []
    for record in records:
        if not isinstance(record, dict):
            continue
        number = str(
            record.get("number") or record.get("full_number") or record.get("no_plus_number")
            or record.get("phone") or record.get("mobile") or ""
        ).strip()
        message = str(
            record.get("message") or record.get("sms") or record.get("text")
            or record.get("msg") or record.get("body") or ""
        ).strip()
        otp = str(record.get("otp") or record.get("code") or "").strip()
        if not otp and message:
            otp = extract_otp_code(message)
        unique = str(record.get("otp_id") or record.get("id") or "").strip()
        if not unique:
            unique = f"{number}|{otp}|{message[:40]}"
        if not number and not message:
            continue
        items.append({
            "number": number.replace("+", "").replace(" ", "").strip(),
            "otp": otp,
            "message": message,
            "unique": unique,
            "raw": record,
        })
    return items


def otp_delivery_check_text():
    lines = [f"{PEM['graph']} <b>OTP DELIVERY CHECK</b>", "\u2501" * 16]
    panels = [p for p in bot_settings.get("panels", []) if isinstance(p, dict)]
    if not panels:
        lines.append("❌ <b>No panel added yet.</b>")
    totals = {"fetched": 0, "user": 0, "group": 0, "unmatched": 0}
    for panel in panels:
        name = str(panel.get("name") or "Panel")
        stats = _otp_stats_for(name)
        for key in totals:
            totals[key] += int(stats.get(key, 0) or 0)
        status = "🟢 ON" if panel.get("status") == "ON" else "🔴 OFF"
        last_poll = stats.get("last_poll") or 0
        ago = "never" if not last_poll else f"{int(max(0, time.time() - last_poll))}s ago"
        lines.append("")
        lines.append(f"<b>{html.escape(name)}</b> · {html.escape(str(panel.get('type', 'API Panel')))} · {status}")
        lines.append(
            f"   📥 fetched {int(stats.get('fetched', 0) or 0)} | 👤 users {int(stats.get('user', 0) or 0)} | "
            f"👥 groups {int(stats.get('group', 0) or 0)} | ⚠️ no owner {int(stats.get('unmatched', 0) or 0)}"
        )
        note = str(stats.get("last_note") or "-")
        lines.append(f"   ⏱ last poll: {ago} · <code>{html.escape(note[:70])}</code>")
        if is_number_api_panel(panel):
            claimed = int(panel.get("last_getnum_count", 0) or 0)
            num_err = str(panel.get("last_getnum_error") or "")[:60]
            disp_err = str(panel.get("last_display_error") or "")[:60]
            lines.append(f"   🔢 last getnum claimed: <b>{claimed}</b>" + (f" · ⚠️ {html.escape(num_err)}" if num_err else ""))
            if disp_err:
                lines.append(f"   📵 Telegram display error: <code>{html.escape(disp_err)}</code>")
    lines.append("")
    lines.append("\u2501" * 16)
    lines.append("📊 <b>SESSION TOTALS</b>")
    lines.append(f"📥 Fetched: <b>{totals['fetched']}</b>")
    lines.append(f"👤 Delivered to users: <b>{totals['user']}</b>")
    lines.append(f"👥 Delivered to groups: <b>{totals['group']}</b>")
    lines.append(f"⚠️ No owner found: <b>{totals['unmatched']}</b>")
    lines.append("")
    lines.append(f"👥 OTP Groups: <b>{len(bot_settings.get('fw_groups', []))}</b>")
    lines.append(f"📡 Waiting sessions: <b>{len(user_active_sessions)}</b>")
    lines.append(f"🗂 Saved assignments: <b>{len(voltx_assigned_numbers) + len(nexa_assigned_numbers)}</b>")
    if otp_pipeline_events:
        lines.append("")
        lines.append("\u2501" * 16)
        lines.append("🕘 <b>LAST OTP EVENTS</b>")
        for event in list(otp_pipeline_events)[-8:][::-1]:
            stamp = datetime.fromtimestamp(event["time"]).strftime("%H:%M:%S")
            owners_txt = ", ".join(str(o) for o in event["owners"]) or "—"
            number_tail = html.escape(str(event["number"])[-6:])
            lines.append(
                f"<code>{stamp}</code> {html.escape(event['panel'][:14])} · …{number_tail} · "
                f"OTP <code>{html.escape(str(event['otp']))}</code> → 👤{owners_txt} 👥{event['groups']}"
            )
    lines.append("")
    lines.append("<i>Use 🧪 Live Test to check one panel right now.</i>")
    return render_body_text("\n".join(lines))


def otp_delivery_check_keyboard():
    kb = []
    for idx, panel in enumerate(bot_settings.get("panels", [])):
        if not is_number_api_panel(panel):
            continue
        kb.append([{
            "text": f"🧪 Live Test: {panel.get('name', 'Panel')}",
            "icon_custom_emoji_id": "5352694861990501856",
            "callback_data": f"otp_check_p_{idx}",
            "style": "success",
        }])
    kb.append([{"text": "📨 Send Test OTP To Me", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "otp_test_self", "style": "primary"}])
    kb.append([{"text": "👥 Test OTP Group Delivery", "icon_custom_emoji_id": "5190447043545438788", "callback_data": "otp_test_group", "style": "danger"}])
    kb.append([
        {"text": "🔄 Refresh", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "otp_check", "style": "success"},
        {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"},
    ])
    return {"inline_keyboard": kb}


def run_panel_otp_probe(panel_idx):
    """Live probe: fetch OTPs from one panel and show exactly where they go."""
    panels = bot_settings.get("panels", [])
    if not isinstance(panel_idx, int) or not (0 <= panel_idx < len(panels)):
        return "❌ Panel not found."
    panel = panels[panel_idx]
    if not is_number_api_panel(panel):
        return "❌ This panel is not a FastX / VoltX / Stex number panel."
    name = html.escape(str(panel.get("name") or "Panel"))
    base_url = str(panel.get("base_url", "")).strip()
    api_key = str(panel.get("api_key", "")).strip()
    if not base_url or not api_key:
        return f"❌ <b>{name}</b> is missing Base URL or API Key."
    getmsg_url = get_number_panel_url(panel, "getmsg_url")
    headers = get_number_panel_headers(panel)
    started = time.time()
    stats = _otp_stats_for(panel.get("name"))
    try:
        response = requests.get(getmsg_url, headers=headers, timeout=15)
    except Exception as exc:
        stats["errors"] = int(stats.get("errors", 0)) + 1
        stats["last_error"] = str(exc)[:120]
        return f"❌ <b>{name}</b> request failed: <code>{html.escape(str(exc)[:160])}</code>"
    elapsed = time.time() - started
    if response.status_code != 200:
        stats["errors"] = int(stats.get("errors", 0)) + 1
        stats["last_error"] = f"HTTP {response.status_code}"
        return (
            f"❌ <b>{name}</b> — HTTP {response.status_code}\n"
            f"🔗 <code>{html.escape(getmsg_url)}</code>\n"
            f"📄 <code>{html.escape(str(response.text)[:300])}</code>"
        )
    try:
        payload = response.json()
    except Exception:
        return f"❌ <b>{name}</b> — response is not JSON\n📄 <code>{html.escape(str(response.text)[:300])}</code>"
    items = extract_number_panel_otps(payload)
    seen = panel.get("lastSeenGetnumIds")
    seen = seen if isinstance(seen, list) else []
    new_items = [item for item in items if item.get("unique") and item["unique"] not in seen]
    lines = [
        f"🧪 <b>LIVE OTP TEST — {name}</b>",
        "\u2501" * 16,
        f"✅ HTTP 200 ({elapsed:.2f}s)",
        f"🔗 <code>{html.escape(getmsg_url)}</code>",
        f"📨 OTP rows in queue: <b>{len(items)}</b>",
        f"🆕 Not seen before: <b>{len(new_items)}</b>",
    ]
    sample = items[0] if items else None
    if not sample:
        lines.append("")
        lines.append("⚠️ <i>The panel returned no OTP rows. Either no SMS arrived yet, or the GetMsg URL / API Key is wrong.</i>")
        stats["last_note"] = "probe: 0 rows"
        return render_body_text("\n".join(lines))
    number = str(sample.get("number") or "")
    otp = str(sample.get("otp") or "")
    message = str(sample.get("message") or "")[:160]
    owners = find_otp_owners(number)
    groups = bot_settings.get("fw_groups", [])
    lines.extend([
        "",
        f"📱 Sample number: <code>{html.escape(('+' + number) if number else '?')}</code>",
        f"🔐 OTP: <code>{html.escape(otp or 'not detected')}</code>",
        f"📝 Message: <code>{html.escape(message)}</code>",
        "",
        f"👤 Owner match: {'✅ ' + ', '.join(str(o) for o in owners) if owners else '❌ none'}",
        f"👥 OTP groups: <b>{len(groups)}</b>",
    ])
    if owners and groups:
        lines.append("➡️ Result: <b>user + groups will receive it</b> ✅")
    elif owners:
        lines.append("➡️ Result: <b>user only</b> (no OTP group configured)")
    elif groups:
        lines.append("➡️ Result: <b>groups only</b> ⚠️ — no user is assigned this number")
    else:
        lines.append("➡️ Result: <b>nowhere</b> ❌ — no owner and no OTP group")
    lines.append("")
    lines.append("<i>Restart-proof: VoltX/FastX/Nexa assignments are stored in the JSON DB.</i>")
    stats["last_note"] = f"probe: rows={len(items)} owner={'yes' if owners else 'no'}"
    return render_body_text("\n".join(lines))


def build_test_otp_card(masked=True, style_id=None, for_group=True, otp="123456"):
    """Test card rendered with the same style engine the groups use."""
    test_number = "+8801700000000"
    active_id = active_otp_style_id(for_group) if style_id in (None, "") else str(style_id)
    picked = resolve_otp_style(style_id, for_group=for_group)
    style_label = html.escape(str(picked.get("name") or picked.get("id") or "-"))
    if active_id == RANDOM_OTP_STYLE_ID:
        style_label += " · 🎲 random"
    body = (
        f"{PEM['graph']} <b>OTP DELIVERY TEST</b>\n"
        f"🎨 Style: <b>{style_label}</b>\n"
        + format_otp_display(test_number, "TEST SERVICE", "#EN", masked=masked,
                             otp=otp, style_id=str(picked.get("id") or style_id), for_group=for_group)
    )
    return render_body_text(body)


def build_test_otp_keyboard(otp="123456"):
    return {"inline_keyboard": [[{"text": otp, "icon_custom_emoji_id": "5353022963132174959",
                                  "copy_text": {"text": otp}, "style": "success"}]]}


def send_test_otp_card(target_chat_id, masked=True, style_id=None, otp="123456"):
    return send_message(target_chat_id, build_test_otp_card(masked=masked, style_id=style_id, otp=otp),
                        reply_markup=build_test_otp_keyboard(otp))



def normalize_lookup_name(value):
    """Names used for service/country lookups should be case-insensitive."""
    return re.sub(r"\s+", " ", str(value or "").strip()).casefold()

def service_names_equal(left, right):
    return normalize_lookup_name(left) == normalize_lookup_name(right)

def country_names_equal(left, right):
    left_key = normalize_lookup_name(left)
    right_key = normalize_lookup_name(right)
    if left_key == right_key:
        return True
    return normalize_lookup_name(canonical_country_name(left)) == normalize_lookup_name(canonical_country_name(right))

def canonical_service_name(service):
    """Use the premium app's display name when one exists."""
    clean = re.sub(r"\s+", " ", str(service or "").strip())
    normalized = normalize_lookup_name(clean)
    for app_key, app_data in bot_settings.get("premium_apps", {}).items():
        app_name = app_data.get("name", app_key)
        if normalized in {normalize_lookup_name(app_key), normalize_lookup_name(app_name)}:
            return str(app_name).strip()
    return clean

def canonical_country_name(country):
    """Use one display name for country aliases such as BD/BANGLADESH."""
    clean = re.sub(r"\s+", " ", str(country or "").strip())
    normalized = normalize_lookup_name(clean)
    for code, info in COUNTRY_DB.items():
        if normalized in {normalize_lookup_name(code), normalize_lookup_name(info.get("iso")), normalize_lookup_name(info.get("name"))}:
            return info["name"]
    for code, info in bot_settings.get("premium_flags", {}).items():
        if normalized in {normalize_lookup_name(code), normalize_lookup_name(info.get("iso")), normalize_lookup_name(info.get("name"))}:
            return info.get("name", clean)
    return clean

def get_service_country_ranges(service_map, service, country):
    """Merge ranges from duplicate service/country keys without duplicating them."""
    merged = []
    for service_name, countries in (service_map or {}).items():
        if not service_names_equal(service_name, service):
            continue
        for country_name, ranges in (countries or {}).items():
            if country_names_equal(country_name, country):
                for item in ranges or []:
                    if item not in merged:
                        merged.append(item)
    return merged

def get_available_services():
    service_groups = {}
    all_services = (
        [b.get("service") for b in number_batches.values() if b.get("numbers")]
        + list(bot_settings.get("nexa_services", {}).keys())
    )
    for panel in bot_settings.get("panels", []):
        if is_number_api_panel(panel):
            all_services.extend(get_panel_services(panel).keys())
    # Legacy data is retained only as a fallback for databases with no
    # configured VoltX panel yet.
    all_services += list(bot_settings.get("voltx_services", {}).keys())
    for service in all_services:
        if service:
            key = normalize_lookup_name(service)
            service_groups.setdefault(key, []).append(service)

    return sorted(
        [canonical_service_name(names[0]) for names in service_groups.values()],
        key=str.casefold,
    )

def get_service_selection_ui():
    c_msg = bot_settings["custom_messages"].get("get_number", {})
    txt = render_body_text(c_msg.get("text", f"{PEM['pin']} Select Service"))
    apps_db = bot_settings.get("premium_apps", {})
    kb = []

    for service in get_available_services():
        emoji_id = "5352694861990501856"
        for app_key, app_data in apps_db.items():
            if service.upper() == app_key or service.upper() in app_key or app_key in service.upper():
                if "id" in app_data:
                    emoji_id = app_data["id"]
                    break
        kb.append([{"text": f"{service}", "icon_custom_emoji_id": emoji_id, "callback_data": f"g_s_{service}", "style": "primary"}])

    for button in c_msg.get("buttons", []):
        button_copy = button.copy()
        if "style" not in button_copy:
            button_copy["style"] = "primary"
        kb.append([button_copy])
    kb.append([{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}])
    return txt, {"inline_keyboard": kb}

def get_country_selection_ui(service):
    options = []
    seen_options = set()

    def add_option(country, source, panel_idx=None, label=""):
        key = (
            normalize_lookup_name(country),
            source,
            panel_idx,
        )
        if key in seen_options:
            return
        seen_options.add(key)
        options.append({
            "country": country,
            "source": source,
            "panel_idx": panel_idx,
            "label": label,
        })

    for option in get_number_source_options(service):
        add_option(
            option["country"],
            option["source"],
            option.get("panel_idx"),
            option.get("label", ""),
        )

    # Nexa is also a distinct source. It must not be merged with a same-name
    # country from VoltX/FastX.
    for service_name, countries in bot_settings.get("nexa_services", {}).items():
        if service_names_equal(service_name, service):
            for country_name, ranges in (countries or {}).items():
                if ranges:
                    add_option(
                        canonical_country_name(country_name),
                        "nexa",
                        None,
                        "Nexa",
                    )

    options.sort(
        key=lambda item: (
            str(item["country"]).casefold(),
            str(item.get("label", "")).casefold(),
        )
    )

    c_msg = bot_settings["custom_messages"].get("select_country", {})
    raw_txt = c_msg.get("text", "📌 Select a country for {service}:").replace("{service}", service)
    txt = render_body_text(raw_txt)
    flags_db = bot_settings.get("premium_flags", {})
    kb = []

    country_buttons = []
    for option_index, option in enumerate(options):
        country = option["country"]
        emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID
        for _, flag_data in flags_db.items():
            iso = flag_data.get("iso", "").upper()
            name = flag_data.get("name", "").upper()
            if country.upper() == iso or country.upper() == name or country.upper() in name or name in country.upper():
                if "id" in flag_data:
                    emoji_id = flag_data["id"]
                    break
        # Keep the provider source invisible to users. Duplicate countries
        # intentionally remain as separate identical buttons; their callback
        # data silently carries the owning panel index.
        button_text = country
        if option.get("source") == "panel":
            callback_data = f"g_c_{service}_{country}__P{option['panel_idx']}"
        else:
            callback_data = f"g_c_{service}_{country}__S{option['source']}"
        country_buttons.append({
            "text": button_text,
            "icon_custom_emoji_id": emoji_id,
            "callback_data": callback_data,
            "style": "success",
        })

    # Show two country buttons per row instead of one country per line.
    for index in range(0, len(country_buttons), 2):
        kb.append(country_buttons[index:index + 2])

    for button in c_msg.get("buttons", []):
        button_copy = button.copy()
        if "style" not in button_copy:
            button_copy["style"] = "primary"
        kb.append([button_copy])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "change_service", "style": "danger"}])
    return txt, {"inline_keyboard": kb}

def get_otp_link():
    try:
        return str(bot_settings.get("otp_link") or "").strip()
    except Exception:
        return ""


def otp_group_row():
    """OTP Group button, or nothing when the link is empty (empty url breaks the keyboard)."""
    link = get_otp_link()
    if not link.startswith(("http://", "https://", "tg://")):
        return []
    return [sys_button("otp_group", url=link)]


def waiting_sms_cc_button(remove_cc=False):
    return [{
        "text": "Return CC" if remove_cc else "remove CC",
        "icon_custom_emoji_id": "5336972142066047577",
        "callback_data": "toggle_cc",
        "style": "primary",
    }]

def waiting_sms_navigation_buttons(remove_cc=False):
    return [[
        sys_button("change_service", callback_data="change_service"),
        sys_button("change_country", callback_data="change_country"),
    ]]

WAITING_ACTION_DEFS = [
    ("cc", "🔄 CC toggle (remove CC / Return CC)"),
    ("change_number", "📱 Change Number"),
    ("otp_group", "💬 OTP Group link"),
    ("nav", "🔀 Change App / Change Country"),
    ("custom", "➕ Custom buttons"),
    ("close", "✖️ Close"),
]
DEFAULT_WAITING_ACTIONS = {key: True for key, _label in WAITING_ACTION_DEFS}


def waiting_action_label(key):
    for item_key, label in WAITING_ACTION_DEFS:
        if item_key == key:
            return label
    return str(key)


def waiting_action_flags():
    """Per-button visibility for the Waiting screen. Number buttons are never in here."""
    flags = dict(DEFAULT_WAITING_ACTIONS)
    saved = bot_settings.get("waiting_buttons")
    if isinstance(saved, dict):
        for key in list(flags.keys()):
            if key in saved:
                try:
                    flags[key] = bool(saved[key])
                except Exception:
                    pass
    return flags


def waiting_action_enabled(key):
    try:
        return bool(waiting_action_flags().get(key, True))
    except Exception:
        return True


def set_waiting_action(key, value):
    if key != "all" and key not in DEFAULT_WAITING_ACTIONS:
        return False
    flags = waiting_action_flags()
    if key == "all":
        flags = {k: bool(value) for k in flags}
    else:
        flags[key] = bool(value)
    bot_settings["waiting_buttons"] = flags
    save_db()
    return True


def waiting_action_rows(change_callback=None, remove_cc=False, custom_menu="get_number"):
    """Tail rows of the Waiting screen.

    Only the action buttons are filtered here — the number (copy) buttons and the
    app/service header are added by the caller and therefore can never be hidden.
    """
    flags = waiting_action_flags()
    rows = []

    if flags.get("cc", True):
        rows.append(waiting_sms_cc_button(remove_cc=remove_cc))

    if flags.get("change_number", True):
        row = [sys_button("change_number", callback_data=change_callback)] if change_callback else []
        if flags.get("otp_group", True):
            row = row + otp_group_row()
        if row:
            rows.append(row)
    elif flags.get("otp_group", True):
        link_row = otp_group_row()
        if link_row:
            rows.append(link_row)

    if flags.get("nav", True):
        rows.extend(waiting_sms_navigation_buttons(remove_cc=remove_cc))

    if flags.get("custom", True):
        for c_btn in (bot_settings.get("custom_messages", {}).get(custom_menu, {}) or {}).get("buttons", []) or []:
            if not isinstance(c_btn, dict):
                continue
            button_copy = dict(c_btn)
            button_copy.setdefault("style", "primary")
            rows.append([button_copy])

    if flags.get("close", True):
        rows.append([sys_button("close", callback_data="close_msg")])

    return rows


def waiting_buttons_text(notice=""):
    flags = waiting_action_flags()
    visible = sum(1 for key, _l in WAITING_ACTION_DEFS if flags.get(key, True))
    lines = [f"{PEM['gear']} <b>WAITING SCREEN BUTTONS</b>", "\u2501" * 16]
    if notice:
        lines.extend([notice, ""])
    lines.append("Tap a button below to <b>hide</b> or <b>show</b> it on the Waiting screen.")
    lines.append("<i>Number buttons always stay visible — they can never be hidden.</i>")
    lines.append("")
    for key, label in WAITING_ACTION_DEFS:
        mark = "✅" if flags.get(key, True) else "🚫"
        lines.append(f"{mark} {label}")
    lines.append("")
    lines.append(f"👁 Visible: <b>{visible}/{len(WAITING_ACTION_DEFS)}</b> action buttons")
    return render_body_text("\n".join(lines))


def waiting_buttons_keyboard():
    flags = waiting_action_flags()
    kb = []
    for key, label in WAITING_ACTION_DEFS:
        on = flags.get(key, True)
        kb.append([{
            "text": f"{'✅' if on else '🚫'} {label}",
            "callback_data": f"wbtgl_{key}",
            "style": "success" if on else "danger",
        }])
    kb.append([
        {"text": "👀 Live Preview", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "wsms_preview", "style": "primary"},
        {"text": "♻️ Show All", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "wbtgl_all", "style": "success"},
    ])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wsms_menu", "style": "danger"}])
    return {"inline_keyboard": kb}


def format_waiting_number(num, remove_cc=False):
    """Format a waiting-screen number with or without its country code."""
    clean = str(num or "").replace("+", "").replace(" ", "").replace("-", "")
    if remove_cc:
        dial_code, _ = _find_dial_code(clean)
        local_number = clean[len(dial_code):] if dial_code else clean
        return local_number or clean
    return f"+{clean}" if clean else ""

def waiting_sms_keyboard(session):
    """Build the complete Waiting For SMS keyboard for CC toggle refreshes."""
    nums = session.get("nums", [])
    service = session.get("service")
    remove_cc = session.get("remove_cc", False)
    flags_db = bot_settings.get("premium_flags", {})
    kb = []

    if service:
        app_full_name, _ = get_service_info_html(service)
        emoji_id_srv = "5337302974806922068"
        for app_key, app_data in bot_settings.get("premium_apps", {}).items():
            app_name = app_data.get("name", app_key)
            if service_names_equal(service, app_key) or service_names_equal(service, app_name):
                if "id" in app_data:
                    emoji_id_srv = app_data["id"]
                break
        kb.append([{"text": f"{app_full_name}", "icon_custom_emoji_id": emoji_id_srv, "callback_data": "ignore", "style": "success"}])

    for num in nums:
        _, iso = get_flag_and_code(num)
        display_num = format_waiting_number(num, remove_cc=remove_cc)
        emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID
        for flag_data in flags_db.values():
            if iso == flag_data.get("iso"):
                if "id" in flag_data:
                    emoji_id = flag_data["id"]
                break
        kb.append([{"text": display_num, "icon_custom_emoji_id": emoji_id, "copy_text": {"text": display_num}, "style": "primary"}])

    # Action buttons (CC toggle / Change Number / nav / custom / close) are
    # filtered by the admin's hide-show settings; numbers above are untouched.
    kb.extend(waiting_action_rows(
        session.get("change_callback"),
        remove_cc=remove_cc,
        custom_menu=session.get("custom_menu", "get_number"),
    ))
    return kb

def get_admin_text():
    users_count = len(all_known_users) # 🌟 Zero Cost User Count!
    total_files = len(number_batches)
    available_nums = sum(len(b["numbers"]) for b in number_batches.values())

    txt = f"""
{PEM['admin']} <b>ADMIN CONTROL PANEL</b> {PEM['admin']}
━━━━━━━━━━━━━━━━━━

{PEM['graph']} <b>DATABASE OVERVIEW</b>
— — — — — — — — — —
{PEM['user']} Users      » {users_count}
{PEM['file']} Files      » {total_files}
{PEM['num']} Numbers    » {total_uploaded_stats}
{PEM['ok']} Assigned   » {total_assigned_stats}
{PEM['rocket']} Available  » {available_nums}

{PEM['graph']} <b>STOCK LEVEL</b>
— — — — — — — — — —
[██████░░░░░░░░░] {available_nums} free

{PEM['money']} Pending Withdrawals » {wd_stats()['pending']} (total {wd_stats()['pending_amount']} USDT)

{PEM['gear']} <b>BUILD</b> » {BOT_BUILD}
"""
    return render_body_text(txt)

def admin_panel_keyboard():
    return {"inline_keyboard": [
        [{"text": "LEADER BOARD SYSTEM", "icon_custom_emoji_id": "5353032893096567467", "callback_data": "lb_main", "style": "success"}],
        [{"text": "Upload Number", "icon_custom_emoji_id": "5353001161878182134", "callback_data": "upload_num", "style": "primary"},
         {"text": "Delete files", "icon_custom_emoji_id": "5422557736330106570", "callback_data": "delete_files", "style": "danger"}],
        [{"text": "Broadcast", "icon_custom_emoji_id": "5789428375261023681", "callback_data": "broadcast_msg", "style": "success"},
         {"text": "System", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "system_settings", "style": "primary"}],
        [{"text": f"💰 Withdraw Pending ({wd_stats()['pending']})", "icon_custom_emoji_id": "5352585194295564660", "callback_data": "wd_pending", "style": "danger" if wd_stats()['pending'] else "primary"},
         {"text": "📜 Withdraw History", "icon_custom_emoji_id": "5422557736330106570", "callback_data": "wd_menu", "style": "primary"}],
        [{"text": "Used (OTP Received)", "icon_custom_emoji_id": "5352694861990501856", "callback_data": "show_used", "style": "success"},
         {"text": "Unused (No OTP)", "icon_custom_emoji_id": "5352597830089347330", "callback_data": "show_unused", "style": "success"}],
        [{"text": "💾 Backup / Restore (Download · Import)", "icon_custom_emoji_id": "5257969839313526622", "callback_data": "backup_menu", "style": "success"}],
        [{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}]
    ]}

def system_settings_keyboard():
    return {"inline_keyboard": [
        [{"text": "Nexa Control", "icon_custom_emoji_id": "5336972142066047577", "callback_data": "nexa_control", "style": "success"}],
        [{"text": "Force Join System", "icon_custom_emoji_id": "5420517437885943844", "callback_data": "manage_fj", "style": "primary"},
         {"text": "Admin Management", "icon_custom_emoji_id": "5420145051336485498", "callback_data": "manage_admins", "style": "danger"}],
        [{"text": "OTP Group", "icon_custom_emoji_id": "5190447043545438788", "callback_data": "manage_otp_groups", "style": "danger"},
         {"text": "User Management", "icon_custom_emoji_id": "5193063022226086560", "callback_data": "user_management", "style": "primary"}], 
        [{"text": "Panel MANAGEMENT", "icon_custom_emoji_id": "5336879280578138635", "callback_data": "manage_panels", "style": "danger"},
         {"text": "Subscription", "icon_custom_emoji_id": "5190899075968441286", "callback_data": "dummy_alert", "style": "success"}],
        [{"text": "SHAHADOT X DEV CONTROL", "icon_custom_emoji_id": "5193100774988617665", "callback_data": "abhi_control", "style": "primary"},
         {"text": "Premium Emoji", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "manage_emojis", "style": "success"}],
        [{"text": "💬 Waiting SMS", "icon_custom_emoji_id": "5337302974806922068", "callback_data": "wsms_menu", "style": "success"},
         {"text": "Menu Design", "icon_custom_emoji_id": "5190751148704833975", "callback_data": "menu_design_list", "style": "primary"}], 
        [{"text": "Test", "icon_custom_emoji_id": "5190781475468915802", "callback_data": "test_message_flow", "style": "primary"},
         {"text": "🎨 SMS Style", "icon_custom_emoji_id": "5352877703043258544", "callback_data": "ostyle_menu", "style": "success"}], 
        [{"text": "🎛 Button Manager", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "mb_menu", "style": "success"},
         {"text": "🔎 OTP Check", "icon_custom_emoji_id": "5352694861990501856", "callback_data": "otp_check", "style": "danger"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]
    ]}

def get_user_management_text():
    # 🌟 Fast & Free User Management Stats!
    total = len(all_known_users)
    
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    txt = f"""➖➖➖➖➖➖➖➖
《 👋 USER VIEW 》
➖➖➖➖➖➖➖➖
📊 LIVE STATISTICS:
➖➖➖➖➖➖➖➖
🫂 TOTAL USERS: {total}
✅ VERIFIED USERS: (Hidden to save DB Cost)
🚫 BANNED USERS: (Hidden to save DB Cost)
➖➖➖➖➖➖➖➖
⌛ UPDATED: {now_str}"""
    return render_body_text(txt)

def user_management_keyboard():
    return {"inline_keyboard": [
        [{"text": "Manage Balance", "icon_custom_emoji_id": "5190576863226933563", "callback_data": "um_manage_balance", "style": "primary"},
         {"text": "Ban/Unban User", "icon_custom_emoji_id": "5334807341109908955", "callback_data": "um_ban_unban", "style": "danger"}],
        [{"text": "User Profile", "icon_custom_emoji_id": "5352861489541714456", "callback_data": "um_user_profile", "style": "success"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "primary"}]
    ]}

def menu_design_list_keyboard():
    return {"inline_keyboard": [
        [{"text": "Edit /start Menu", "icon_custom_emoji_id": "5395444784611480792", "callback_data": "md_edit_start", "style": "primary"}],
        [{"text": "Edit GET NUMBER", "icon_custom_emoji_id": "6217644551771790254", "callback_data": "md_edit_get_number", "style": "success"},
         {"text": "Edit Search Number", "icon_custom_emoji_id": "5190645917711114179", "callback_data": "md_edit_search_number", "style": "success"}],
        [{"text": "Edit Select Country", "icon_custom_emoji_id": "5336972142066047577", "callback_data": "md_edit_select_country", "style": "primary"}],
        [{"text": "Edit Waiting Message", "icon_custom_emoji_id": "5336997731481193790", "callback_data": "md_edit_waiting", "style": "success"},
         {"text": "Edit Expired", "icon_custom_emoji_id": "5318840353510408444", "callback_data": "md_edit_waiting_expired", "style": "danger"}],
        [{"text": "Edit TRAFFIC", "icon_custom_emoji_id": "5353032893096567467", "callback_data": "md_edit_traffic", "style": "primary"},
         {"text": "Edit Refer", "icon_custom_emoji_id": "5420396762189831222", "callback_data": "md_edit_refer", "style": "primary"}],
        [{"text": "Edit WITHDRAWAL", "icon_custom_emoji_id": "5352585194295564660", "callback_data": "md_edit_withdrawal", "style": "danger"},
         {"text": "Edit SUPPORT", "icon_custom_emoji_id": "5420145051336485498", "callback_data": "md_edit_support", "style": "danger"}],
        [{"text": "Reset Defaults", "icon_custom_emoji_id": "5192812028632274956", "callback_data": "md_reset_defaults", "style": "success"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "primary"}]
    ]}

def menu_edit_options_keyboard(menu_key):
    return {"inline_keyboard": [
        [{"text": "Edit Body (Text)", "icon_custom_emoji_id": "5395444784611480792", "callback_data": f"md_text_{menu_key}", "style": "primary"}],
        [{"text": "Edit Inline Buttons", "icon_custom_emoji_id": "5420155432272438703", "callback_data": f"md_btns_{menu_key}", "style": "success"}],
        [{"text": "Back to Menus", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "menu_design_list", "style": "danger"}]
    ]}

def menu_buttons_list_keyboard(menu_key):
    kb = []
    btns = bot_settings["custom_messages"].get(menu_key, {}).get("buttons", [])
    for idx, btn in enumerate(btns):
        label = str(btn.get("text", "Button"))[:40]
        kb.append([
            {"text": f"✏️ {label}", "icon_custom_emoji_id": str(btn.get("icon_custom_emoji_id") or "5420323438508155202"), "callback_data": f"mi_btn_{menu_key}_{idx}", "style": "primary"},
            {"text": "🗑", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"md_delbtn_{menu_key}_{idx}", "style": "danger"},
        ])
    kb.append([{"text": "Add Inline Button", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"md_addbtn_{menu_key}", "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"md_edit_{menu_key}", "style": "primary"}])
    return {"inline_keyboard": kb}

def generate_emoji_txt(kind="flags"):
    """Build a TXT file for premium flags/apps that round-trips with the uploader."""
    lines = []
    if kind == "flags":
        for code, info in bot_settings.get("premium_flags", {}).items():
            if not isinstance(info, dict):
                continue
            emoji_id = str(info.get("id", "") or "")
            if not emoji_id:
                continue
            char = str(info.get("char", "") or "")
            name = str(info.get("name", "") or code)
            iso = str(info.get("iso", "") or "")
            payload = json.dumps({"emoji": char, "id": emoji_id}, ensure_ascii=False)
            lines.append(f"{name} ({code}) ({iso}) {char} {payload}")
    else:
        for key, info in bot_settings.get("premium_apps", {}).items():
            if not isinstance(info, dict):
                continue
            emoji_id = str(info.get("id", "") or "")
            if not emoji_id:
                continue
            char = str(info.get("char", "") or "")
            name = str(info.get("name", "") or key)
            payload = json.dumps({"emoji": char, "id": emoji_id}, ensure_ascii=False)
            lines.append(f"{name} {char} {payload}")
    return "\n".join(lines).strip()


def emoji_settings_keyboard():
    return {"inline_keyboard": [
        [{"text": "Upload Flags (TXT)", "icon_custom_emoji_id": "5353001161878182134", "callback_data": "up_flags_txt", "style": "primary"},
         {"text": "Download Flags", "icon_custom_emoji_id": "5257969839313526622", "callback_data": "dl_flags_txt", "style": "success"}],
        [{"text": "Upload Services (TXT)", "icon_custom_emoji_id": "5353001161878182134", "callback_data": "up_apps_txt", "style": "primary"},
         {"text": "Download Services", "icon_custom_emoji_id": "5257969839313526622", "callback_data": "dl_apps_txt", "style": "success"}],
        [{"text": "Delete All Flags", "icon_custom_emoji_id": "5422557736330106570", "callback_data": "del_all_flags", "style": "danger"},
         {"text": "Add Single Emoji", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_single_emoji", "style": "success"}],
        [{"text": "🚩 Reset To Default Flag Pack", "icon_custom_emoji_id": DEFAULT_FLAG_CUSTOM_EMOJI_ID, "callback_data": "flag_pack_reset", "style": "success"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}]
    ]}

def fj_settings_keyboard():
    status_text = 'ON' if bot_settings['fj_on'] else 'OFF'
    status_icon = "5352694861990501856" if bot_settings['fj_on'] else "5318840353510408444"
    kb = [[{"text": f"STATUS: {status_text}", "icon_custom_emoji_id": status_icon, "callback_data": "toggle_fj", "style": "primary"}]]
    for idx, entry in enumerate(bot_settings["fj_channels"]):
        info = _get_fj_info(entry)
        ch_type = info.get("type", "channel")
        title = info.get("title", str(info.get("chat_id", "")))
        is_priv = info.get("is_private", False)
        type_tag = "Channel" if ch_type == "channel" else "Group"
        priv_tag = "Private" if is_priv else "Public"
        btn_label = f"{title} [{type_tag} | {priv_tag}]"
        kb.append([{"text": btn_label, "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"del_fj_{idx}", "style": "danger"}])
    kb.append([{"text": "Add Channel / Group", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_fj", "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "primary"}])
    return {"inline_keyboard": kb}

def admin_settings_keyboard():
    kb = []
    for idx, adm in enumerate(bot_settings["admins"]):
        text_btn = f"Owner: {adm}" if adm == OWNER_ID else f"Delete: {adm}"
        icon_id = "5353032893096567467" if adm == OWNER_ID else "5420130255174145507"
        cb_data = "ignore" if adm == OWNER_ID else f"del_adm_{idx}"
        kb.append([{"text": text_btn, "icon_custom_emoji_id": icon_id, "callback_data": cb_data, "style": "danger" if adm != OWNER_ID else "primary"}])
    kb.append([{"text": "Add Admin", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_adm", "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "primary"}])
    return {"inline_keyboard": kb}

def otp_groups_list_keyboard():
    kb = [[{"text": "Edit OTP Button Link", "icon_custom_emoji_id": "5420517437885943844", "callback_data": "edit_otp_link", "style": "primary"}]]
    for idx, fg in enumerate(bot_settings["fw_groups"]):
        style_label = str(fg.get("style") or "auto")
        style_label = "auto" if style_label == "auto" else _style_name(style_label)
        kb.append([
            {"text": f"Group: {fg['chat_id']}", "icon_custom_emoji_id": "5193063022226086560", "callback_data": f"manage_fw_{idx}", "style": "primary"},
            {"text": f"🎨 {style_label}"[:32], "icon_custom_emoji_id": "5352877703043258544", "callback_data": f"fwstyle__{idx}", "style": "success"},
        ])
    kb.append([{"text": "Add Forward Group", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_fw", "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}])
    return {"inline_keyboard": kb}

def nexa_control_keyboard():
    return {"inline_keyboard": [
        [{"text": "Add Nexa Key", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_nexa_key", "style": "success"},
         {"text": "View/Del Keys", "icon_custom_emoji_id": "5422557736330106570", "callback_data": "view_nexa_keys", "style": "danger"}],
        [{"text": "Manage Nexa Services", "icon_custom_emoji_id": "5192739271886282680", "callback_data": "manage_nexa_srv", "style": "success"}],
        [{"text": "Search Country", "icon_custom_emoji_id": "5336972142066047577", "callback_data": "nexa_search_country", "style": "primary"}],
        [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "primary"}]
    ]}

def specific_fw_group_keyboard(idx):
    group = bot_settings["fw_groups"][idx]
    kb = []
    for b_idx, btn in enumerate(group.get("buttons", [])):
        kb.append([{"text": f"Del: {btn['text']}", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"del_fwbtn_{idx}_{b_idx}", "style": "danger"}])
    
    kb.append([{"text": "Add Inline Button", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"add_fwbtn_{idx}", "style": "success"}])
    kb.append([{"text": "Delete Entire Group", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"del_fw_{idx}", "style": "danger"}])
    kb.append([{"text": "Back to Groups", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_otp_groups", "style": "primary"}])
    return {"inline_keyboard": kb}

def abhi_control_keyboard():
    w_status = "ON" if bot_settings["withdraw_on"] else "OFF"
    sup_status = "ON" if bot_settings.get("support_link") else "OFF"
    grp_status = "ON" if bot_settings.get("w_group") else "OFF"
    return {"inline_keyboard": [
        [{"text": f"WITHDRAW: {w_status}", "icon_custom_emoji_id": "5348469219761626211", "callback_data": "abhi_toggle_w", "style": "primary"}],
        [{"text": f"MIN WITHDRAW: {bot_settings['min_withdraw']}", "icon_custom_emoji_id": "5352877703043258544", "callback_data": "abhi_min_w", "style": "success"},
         {"text": f"OTP REWARD: {bot_settings['otp_reward']}", "icon_custom_emoji_id": "5190576863226933563", "callback_data": "abhi_otp_r", "style": "primary"}],
        [{"text": f"REFER REWARD: {bot_settings['refer_reward']}", "icon_custom_emoji_id": "5420396762189831222", "callback_data": "abhi_ref_r", "style": "success"},
         {"text": f"COOLDOWN: {bot_settings['cooldown']}s", "icon_custom_emoji_id": "5337172996211648018", "callback_data": "abhi_cool", "style": "primary"}],
        [{"text": f"NUM/REQ: {bot_settings['num_req']}", "icon_custom_emoji_id": "6217644551771790254", "callback_data": "abhi_num_req", "style": "success"},
         {"text": f"NUM/SHARE: {bot_settings['num_share']}", "icon_custom_emoji_id": "5352862640592949843", "callback_data": "abhi_num_share", "style": "primary"}],
        [{"text": f"SUPPORT LINK: {sup_status}", "icon_custom_emoji_id": "5420145051336485498", "callback_data": "abhi_sup_link", "style": "success"},
         {"text": "W. METHODS", "icon_custom_emoji_id": "5190899075968441286", "callback_data": "manage_w_methods", "style": "primary"}],
        [{"text": f"W. GROUP: {grp_status}", "icon_custom_emoji_id": "5420517437885943844", "callback_data": "abhi_w_group", "style": "success"},
         {"text": "BACK", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}],
        [{"text": "🌍 Country OTP Reward", "icon_custom_emoji_id": "5352877703043258544", "callback_data": "cor_list", "style": "success"},
         {"text": "👨‍💻 Main Developer", "icon_custom_emoji_id": "5353027129250453493", "callback_data": "main_developer", "style": "primary"}],
        [{"text": f"✨ Premium Emoji: {'ON ✅' if bot_settings.get('premium_emoji_on') else 'OFF ❌'}", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "abhi_toggle_prem_emoji", "style": "success" if bot_settings.get("premium_emoji_on") else "danger"}]
    ]}

def w_methods_keyboard():
    kb = []
    for idx, m in enumerate(bot_settings["w_methods"]):
        kb.append([{"text": f"Delete: {m}", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"del_wm_{idx}", "style": "danger"}])
    kb.append([{"text": "Add Method", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_wm", "style": "success"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "abhi_control", "style": "primary"}])
    return {"inline_keyboard": kb}

def country_otp_rewards_keyboard():
    """Show existing country-specific OTP rewards with delete buttons."""
    cor = bot_settings.get("country_otp_rewards", {})
    kb = []
    for iso, reward in sorted(cor.items()):
        # find country name
        country_name = iso
        for code, info in COUNTRY_DB.items():
            if info.get("iso", "").upper() == iso.upper():
                country_name = info.get("name", iso)
                break
        flag = get_flag_emoji(iso)
        kb.append([
            {"text": f"{flag} {country_name}: {reward} USDT", "callback_data": "ignore", "style": "success"},
            {"text": "🗑 Delete", "callback_data": f"cor_del_{iso}", "style": "danger"}
        ])
    kb.append([{"text": "➕ Add Country Reward", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "cor_add_p0", "style": "primary"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "abhi_control", "style": "danger"}])
    return {"inline_keyboard": kb}

def cor_add_keyboard(page=0):
    """Paginated list of countries to pick for setting OTP reward."""
    all_entries = sorted(COUNTRY_DB.items(), key=lambda x: x[1]["name"])
    page_size = 15
    total_pages = (len(all_entries) + page_size - 1) // page_size
    start = page * page_size
    chunk = all_entries[start:start + page_size]
    kb = []
    for _, info in chunk:
        iso = info["iso"]
        name = info["name"]
        flag = get_flag_emoji(iso)
        existing = bot_settings.get("country_otp_rewards", {}).get(iso, "")
        label = f"{flag} {name}" + (f" ({existing} USDT)" if existing != "" else "")
        kb.append([{"text": label, "callback_data": f"cor_pick_{iso}", "style": "primary"}])
    nav = []
    if page > 0:
        nav.append({"text": "◀ Prev", "callback_data": f"cor_add_p{page-1}", "style": "primary"})
    if page < total_pages - 1:
        nav.append({"text": "Next ▶", "callback_data": f"cor_add_p{page+1}", "style": "primary"})
    if nav:
        kb.append(nav)
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "cor_list", "style": "danger"}])
    return {"inline_keyboard": kb}

def typed_panels_list_keyboard(p_type):
    kb = []
    for idx, p in enumerate(bot_settings["panels"]):
        if p.get("type", "API Panel") != p_type: continue
        action_text = f"Turn OFF {panel_name(p)}" if panel_status(p) == 'ON' else f"Turn ON {panel_name(p)}"
        action_icon = "5318840353510408444" if panel_status(p) == 'ON' else "5192812028632274956"
        icon_id = "5420155432272438703" 
        kb.append([
            {"text": action_text, "icon_custom_emoji_id": action_icon, "callback_data": f"tog_pnl_{idx}", "style": "danger" if panel_status(p) == 'ON' else "success"},
            {"text": f"{panel_name(p)}", "icon_custom_emoji_id": icon_id, "callback_data": f"conf_pnl_{idx}", "style": "primary"}
        ])
    if p_type == "API Panel": add_cb = "add_api_panel"
    elif p_type == "VoltX Panel": add_cb = "add_voltx_panel"
    elif p_type == "FastX Panel": add_cb = "add_fastx_panel"
    elif p_type == "Stex Panel": add_cb = "add_stex_panel"
    else: add_cb = "add_cpt_panel"
    if p_type == "API Panel": del_cb = "list_del_api"
    elif p_type == "VoltX Panel": del_cb = "list_del_voltx"
    elif p_type == "FastX Panel": del_cb = "list_del_fastx"
    elif p_type == "Stex Panel": del_cb = "list_del_stex"
    else: del_cb = "list_del_cpt"
    kb.append([{"text": "Add New Provider", "icon_custom_emoji_id": "5420323438508155202", "callback_data": add_cb, "style": "success"}])
    kb.append([{"text": "Delete Provider", "icon_custom_emoji_id": "5336944168944047463", "callback_data": del_cb, "style": "danger"}])
    kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_panels", "style": "primary"}])
    return {"inline_keyboard": kb}

def panel_config_keyboard(idx):
    p = bot_settings["panels"][idx]
    
    kb = []
    action_text = "Turn OFF" if panel_status(p) == 'ON' else "Turn ON"
    action_icon = "5318840353510408444" if panel_status(p) == 'ON' else "5192812028632274956"
    kb.append([{"text": action_text, "icon_custom_emoji_id": action_icon, "callback_data": f"tog_pnl_{idx}", "style": "danger" if panel_status(p) == 'ON' else "success"}])
    
    if is_number_api_panel(p):
        kb.append([{"text": "🌐 Set Base URL", "icon_custom_emoji_id": "5336972142066047577", "callback_data": f"set_p_vbase_{idx}", "style": "primary"}])
        kb.append([{"text": f"🔑 Set API Key", "icon_custom_emoji_id": "5353022963132174959", "callback_data": f"set_p_vkey_{idx}", "style": "primary"}])
        kb.append([{"text": "📥 Set GetNum URL", "icon_custom_emoji_id": "6217644551771790254", "callback_data": f"set_p_vgetnum_{idx}", "style": "primary"}])
        kb.append([{"text": "📨 Set GetMsg URL", "icon_custom_emoji_id": "5395444784611480792", "callback_data": f"set_p_vgetmsg_{idx}", "style": "primary"}])
        kb.append([{"text": "📊 Set Traffic URL", "icon_custom_emoji_id": "5352877703043258544", "callback_data": f"set_p_vtraf_{idx}", "style": "primary"}])
        if p["type"] == "FastX Panel":
            service_label = "Manage FastX Services"
        elif p["type"] == "Stex Panel":
            service_label = "Manage Stex Services"
        else:
            service_label = "Manage VoltX Services"
        kb.append([{"text": f"🔧 {service_label}", "icon_custom_emoji_id": "5192739271886282680", "callback_data": f"manage_vx_srv_{idx}", "style": "success"}])
    elif p["type"] != "Auto Captcha Panel":
        rec_count_text = "All (Unlimited)" if p.get('records', 0) == 0 else str(p.get('records'))
        kb.append([{"text": "Set API URL", "icon_custom_emoji_id": "5420517437885943844", "callback_data": f"set_p_api_{idx}", "style": "primary"}])
        kb.append([{"text": "Set Token", "icon_custom_emoji_id": "5353022963132174959", "callback_data": f"set_p_tok_{idx}", "style": "primary"}])
        kb.append([{"text": "🌐 Full API (URL+Token)", "icon_custom_emoji_id": "5420517437885943844", "callback_data": f"set_p_fapi_{idx}", "style": "primary"}])
        kb.append([{"text": f"Set Records Count: {rec_count_text}", "icon_custom_emoji_id": "5192739271886282680", "callback_data": f"set_p_rec_{idx}", "style": "primary"}])
        
    kb.append([{"text": "Test Connection", "icon_custom_emoji_id": "5352694861990501856", "callback_data": f"test_p_conn_{idx}", "style": "success"}])
    if is_number_api_panel(p):
        kb.append([{"text": "🔎 OTP Pipeline Test", "icon_custom_emoji_id": "5352894480764227283", "callback_data": f"otp_check_p_{idx}", "style": "success"}])
        kb.append([{"text": "🧪 Get-Num Test (claim 1)", "icon_custom_emoji_id": "5352552689983067014", "callback_data": f"getnum_test_{idx}", "style": "primary"}])
    
    if p.get("type") == "Auto Captcha Panel": back_data = "manage_cpt_panels"
    elif p.get("type") == "VoltX Panel": back_data = "manage_voltx_panels"
    elif p.get("type") == "FastX Panel": back_data = "manage_fastx_panels"
    elif p.get("type") == "Stex Panel": back_data = "manage_stex_panels"
    else: back_data = "manage_api_panels"
    kb.append([{"text": "Back to Providers", "icon_custom_emoji_id": "5267490665117275176", "callback_data": back_data, "style": "danger"}])
    return {"inline_keyboard": kb}

def panel_services_manager_view(panel_idx):
    panel = get_number_panel_for_source(panel_idx)
    if not panel:
        return "❌ Panel not found.", {"inline_keyboard": []}
    services = get_panel_service_items(panel)
    kb = []
    for service_idx, (service, countries) in enumerate(services):
        kb.append([{
            "text": f"📦 {service} ({len(countries or {})} countries)",
            "icon_custom_emoji_id": "5192739271886282680",
            "callback_data": f"pvs_srv_{panel_idx}_{service_idx}",
            "style": "primary",
        }])
    kb.append([{
        "text": "➕ Add Service",
        "icon_custom_emoji_id": "5420323438508155202",
        "callback_data": f"pvs_add_srv_{panel_idx}",
        "style": "success",
    }])
    kb.append([{
        "text": "Back",
        "icon_custom_emoji_id": "5267490665117275176",
        "callback_data": f"conf_pnl_{panel_idx}",
        "style": "danger",
    }])
    provider = panel.get("type", "Number Panel").replace(" Panel", "")
    return (
        f"📦 <b>{provider} Services</b>\n"
        f"<i>Every range added here will request numbers from {panel.get('name', provider)} only.</i>",
        {"inline_keyboard": kb},
    )

def panel_service_countries_view(panel_idx, service_idx):
    panel = get_number_panel_for_source(panel_idx)
    if not panel:
        return "❌ Panel not found.", {"inline_keyboard": []}
    services = get_panel_service_items(panel)
    if not (0 <= service_idx < len(services)):
        return "❌ Service not found.", {"inline_keyboard": []}
    service, countries = services[service_idx]
    kb = []
    for country_idx, (country, ranges) in enumerate((countries or {}).items()):
        kb.append([{
            "text": f"🏳️ {country} ({len(ranges or [])} ranges)",
            "icon_custom_emoji_id": DEFAULT_FLAG_CUSTOM_EMOJI_ID,
            "callback_data": f"pvs_cnt_{panel_idx}_{service_idx}_{country_idx}",
            "style": "primary",
        }])
    kb.append([{
        "text": "➕ Add Country",
        "icon_custom_emoji_id": "5420323438508155202",
        "callback_data": f"pvs_add_cnt_{panel_idx}_{service_idx}",
        "style": "success",
    }])
    kb.append([{
        "text": "🗑 Delete Service",
        "icon_custom_emoji_id": "5422557736330106570",
        "callback_data": f"pvs_del_srv_{panel_idx}_{service_idx}",
        "style": "danger",
    }])
    kb.append([{
        "text": "Back",
        "icon_custom_emoji_id": "5267490665117275176",
        "callback_data": f"pvs_manage_{panel_idx}",
        "style": "primary",
    }])
    return (
        f"🌍 <b>{panel.get('name', 'Panel')} → {service}</b>\n"
        f"<i>These countries and ranges belong to this panel only.</i>",
        {"inline_keyboard": kb},
    )

def panel_service_country_view(panel_idx, service_idx, country_idx):
    panel = get_number_panel_for_source(panel_idx)
    if not panel:
        return "❌ Panel not found.", {"inline_keyboard": []}
    services = get_panel_service_items(panel)
    if not (0 <= service_idx < len(services)):
        return "❌ Service not found.", {"inline_keyboard": []}
    service, countries = services[service_idx]
    countries = list((countries or {}).items())
    if not (0 <= country_idx < len(countries)):
        return "❌ Country not found.", {"inline_keyboard": []}
    country, ranges = countries[country_idx]
    kb = []
    for range_idx, range_value in enumerate(ranges or []):
        kb.append([{
            "text": f"❌ {range_value}",
            "icon_custom_emoji_id": "5422557736330106570",
            "callback_data": f"pvs_del_rng_{panel_idx}_{service_idx}_{country_idx}_{range_idx}",
            "style": "danger",
        }])
    kb.append([{
        "text": "➕ Add Range/Prefix",
        "icon_custom_emoji_id": "5420323438508155202",
        "callback_data": f"pvs_add_rng_{panel_idx}_{service_idx}_{country_idx}",
        "style": "success",
    }])
    kb.append([{
        "text": "🗑 Delete Country",
        "icon_custom_emoji_id": "5422557736330106570",
        "callback_data": f"pvs_del_cnt_{panel_idx}_{service_idx}_{country_idx}",
        "style": "danger",
    }])
    kb.append([{
        "text": "Back",
        "icon_custom_emoji_id": "5267490665117275176",
        "callback_data": f"pvs_srv_{panel_idx}_{service_idx}",
        "style": "primary",
    }])
    ranges_text = "\n".join(f"• <code>{r}</code>" for r in (ranges or []))
    if not ranges_text:
        ranges_text = "<i>No ranges yet</i>"
    return (
        f"📱 <b>{panel.get('name', 'Panel')} → {service} → {country}</b>\n\n"
        f"{ranges_text}",
        {"inline_keyboard": kb},
    )

def build_traffic_ui():
    global recent_traffic
    current_time = time.time()
    recent_traffic = [t for t in recent_traffic if current_time - t.get("time", 0) <= 3600]
    
    stats = {}
    for t in recent_traffic:
        srv = t.get("service", "Unknown")
        iso = t.get("iso", "XX")
        flag = t.get("flag", "🌍")
        
        if srv not in stats:
            stats[srv] = {}
        if iso not in stats[srv]:
            stats[srv][iso] = {"count": 0, "flag": flag}
        stats[srv][iso]["count"] += 1
        
    txt = "╔═════════════════╗\n║  📈 <b>NETWORK TRAFFIC</b>\n╚═════════════════╝\n\n"
    
    kb = []
    if not stats:
        txt += "<i>No recent traffic found in the last hour...</i>\n"
    else:
        srv_totals = []
        for srv, countries in stats.items():
            total = sum(c["count"] for c in countries.values())
            srv_totals.append((srv, total, countries))
        
        srv_totals.sort(key=lambda x: x[1], reverse=True)
        
        for srv, total, countries in srv_totals:
            app_full_name, prem_app_html = get_service_info_html(srv)
            txt += f"[ {prem_app_html} <b>{app_full_name}</b> ]\n│\n"
            
            c_list = sorted(countries.items(), key=lambda x: x[1]["count"], reverse=True)
            c_list = c_list[:7] 
            
            for i, (iso, c_data) in enumerate(c_list):
                prem_flag_html = get_flag_info_html(iso)
                count = c_data["count"]
                
                c_name = iso
                for code, fdata in bot_settings.get("premium_flags", {}).items():
                    if fdata.get("iso") == iso:
                        c_name = fdata.get("name", iso)
                        break
                        
                txt += f"├ {prem_flag_html} <b>{c_name} ({iso})</b>\n"
                txt += f"│ ╰ Success: {count}\n"
                if i < len(c_list) - 1:
                    txt += "│\n"
            txt += "\n"
        
        # 🌟 FIX: [:3] limit removed, now all services will show buttons below!
        for srv, _, _ in srv_totals: 
            safe_srv = srv[:20] 
            # To show full name nicely in button
            app_full_name, _ = get_service_info_html(safe_srv, safe_srv)
            kb.append([{"text": f"Explore {app_full_name} Range", "icon_custom_emoji_id": "5190645917711114179", "callback_data": f"exp_rng_{safe_srv}", "style": "success"}])
            
    txt = render_body_text(txt)
    kb.append([{"text": "Refresh", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "refresh_traffic", "style": "primary"}])
    kb.append([{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}])
    
    return txt, {"inline_keyboard": kb}

# ==========================================
# Message Handler
# ==========================================
def handle_message(msg):
    global total_uploaded_stats
    chat_id = msg["chat"]["id"]
    chat_type = msg["chat"].get("type", "private")
    
    if chat_type != "private":
        return
        
    text = msg.get("text", "")
    register_user_local(chat_id) # 🌟 Save User locally for Free Broadcasts!

    if is_user_banned(chat_id):
        send_message(chat_id, render_body_text("🚫 <b>You are banned from using this bot!</b>\nIf you think this is a mistake, please contact support."))
        return
    
    # --- REFERRAL FIX: Save inviter BEFORE Force Join ---
    if text.startswith("/start"):
        parts = text.split()
        if len(parts) > 1 and parts[1].isdigit():
            inviter = int(parts[1])
            if inviter != chat_id:
                u_data = _get_local_user(chat_id)
                if not u_data.get("referred_by"):
                    _update_local_user(chat_id, {"referred_by": inviter, "ref_paid": False})
                        
    if not check_force_join(chat_id):
        send_force_join_msg(chat_id)
        return
        
    menu_action = resolve_menu_action(text)
    
    is_main_cmd = False
    editing_button_state = user_states.get(chat_id) in ("wait_for_btn_label", "wait_for_btn_emoji", "wait_for_btn_url")
    if (menu_action or text.startswith("/start")) and not editing_button_state:
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        is_main_cmd = True
    
    if chat_id in user_states and not is_main_cmd:
        state = user_states[chat_id]
        
        # 🌟 Auto Captcha Panel Setup Flow 
        if state == "wait_for_cpanel_url" and text:
            temp_data.setdefault(chat_id, {}).setdefault("p_data", {})
            temp_data[chat_id]["p_data"]["login_url"] = text.strip()
            user_states[chat_id] = "wait_for_cpanel_user"
            send_message(chat_id, render_body_text("2️⃣ <b>Username</b>\n➡️ Enter Panel Username:"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_user" and text:
            temp_data[chat_id]["p_data"]["username"] = text.strip()
            user_states[chat_id] = "wait_for_cpanel_pass"
            send_message(chat_id, render_body_text("3️⃣ <b>Password</b>\n➡️ Enter Panel Password:"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_pass" and text:
            temp_data[chat_id]["p_data"]["password"] = text.strip()
            user_states[chat_id] = "wait_for_cpanel_msg_link"
            send_message(chat_id, render_body_text("4️⃣ <b>Message Link</b>\n➡️ Enter the link where SMS/OTP data (JSON) comes from:"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_msg_link" and text:
            temp_data[chat_id]["p_data"]["msg_link"] = text.strip()
            user_states[chat_id] = "wait_for_cpanel_num_col_name"
            send_message(chat_id, render_body_text("5️⃣ <b>Number Column Name</b>\n➡️ What is the Number column name in Data? (e.g.: number, phone):"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_num_col_name" and text:
            temp_data[chat_id]["p_data"]["num_col_name"] = text.strip()
            user_states[chat_id] = "wait_for_cpanel_num_col_idx"
            send_message(chat_id, render_body_text("6️⃣ <b>Number Column Serial</b>\n➡️ What is the Number Column Serial Number? (e.g.: 3, 5):"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_num_col_idx" and text:
            if text.isdigit():
                temp_data[chat_id]["p_data"]["num_col_idx"] = int(text)
                user_states[chat_id] = "wait_for_cpanel_msg_col_name"
                send_message(chat_id, render_body_text("7️⃣ <b>Message Column Name</b>\n➡️ What is the Message/OTP column name? (e.g.: message, sms):"), reply_markup=get_cancel_kb())
            else:
                 send_message(chat_id, render_body_text("❌ Please enter a valid number serial!"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_msg_col_name" and text:
            temp_data[chat_id]["p_data"]["msg_col_name"] = text.strip()
            user_states[chat_id] = "wait_for_cpanel_msg_col_idx"
            send_message(chat_id, render_body_text("8️⃣ <b>Message Column Serial</b>\n➡️ What is the Message Column Serial Number? (e.g.: 5, 7):"), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_cpanel_msg_col_idx" and text:
            if text.isdigit():
                temp_data[chat_id]["p_data"]["msg_col_idx"] = int(text)
                temp_data[chat_id]["p_data"]["login_status"] = "⏳ Pending Auto-Login..."
                
                # Save the panel configuration
                temp_data[chat_id]["p_data"]["needs_warmup"] = True
                bot_settings["panels"].append(temp_data[chat_id]["p_data"])
                save_db()
                
                send_message(chat_id, render_body_text(f"{PEM['ok']} <b>Auto Captcha Panel Added Successfully!</b>\nBot will now automatically solve captcha and login in background."), reply_markup=main_menu(chat_id))
                
                msg_id = temp_data[chat_id]["msg_id"]
                handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_cpt_panels", "id": "internal"})
                
                del user_states[chat_id]
                del temp_data[chat_id]
            else:
                 send_message(chat_id, render_body_text("❌ Please enter a valid number serial!"), reply_markup=get_cancel_kb())
            return

        # --- User Management Flows ---
        elif state == "wait_for_um_bal_uid" and text:
            target_uid_str = text.strip()
            if not target_uid_str.isdigit():
                send_message(chat_id, render_body_text("❌ Invalid ID! Please send a numeric User ID."), reply_markup=get_cancel_kb())
                return
            target_uid = int(target_uid_str)
            user_data = _get_local_user(target_uid)
            current_bal = user_data.get('balance', 0.0)
            temp_data[chat_id]["target_uid"] = target_uid
            user_states[chat_id] = "wait_for_um_bal_amt"
            send_message(chat_id, render_body_text(f"✅ User found!\n💰 Current Balance: {current_bal} USDT\n\n📝 Send the amount to ADD (e.g. 50) or REMOVE (e.g. -50):"), reply_markup=get_cancel_kb())
            return

        elif state == "wait_for_um_bal_amt" and text:
            try:
                amt = float(text.strip())
                target_uid = temp_data[chat_id]["target_uid"]
                old_bal = _get_local_user(target_uid).get('balance', 0.0)
                update_balance(target_uid, amt)
                new_bal = _get_local_user(target_uid).get('balance', 0.0)
                send_message(chat_id, render_body_text(f"{PEM['ok']} Balance updated!\n{PEM['user']} User: <code>{target_uid}</code>\n💰 Old: {old_bal} USDT → New: {new_bal} USDT"), reply_markup=main_menu(chat_id))
                
                if amt >= 0:
                    notif_text = f"{PEM['gift']} <b>Balance Added!</b>\n➖➖➖➖➖➖➖\n💰 <b>Amount:</b> +{amt} USDT\n💰 <b>New Balance:</b> {new_bal} USDT\n➖➖➖➖➖➖➖\n👨‍⚖️ <b>By Admin</b>"
                else:
                    notif_text = f"{PEM['warn']} <b>Balance Removed!</b>\n➖➖➖➖➖➖➖\n💰 <b>Amount:</b> {amt} USDT\n💰 <b>New Balance:</b> {new_bal} USDT\n➖➖➖➖➖➖➖\n👨‍⚖️ <b>By Admin</b>"
                send_message(target_uid, render_body_text(notif_text))
                del user_states[chat_id]
                del temp_data[chat_id]
            except ValueError:
                send_message(chat_id, render_body_text("❌ Invalid amount! Please send a number."), reply_markup=get_cancel_kb())
            return

        elif state == "wait_for_um_ban_uid" and text:
            target_uid_str = text.strip()
            if not target_uid_str.isdigit():
                send_message(chat_id, render_body_text("❌ Invalid ID!"), reply_markup=get_cancel_kb())
                return
            target_uid = int(target_uid_str)
            user_data = _get_local_user(target_uid)
            current_status = user_data.get("banned", False)
            new_status = not current_status
            _update_local_user(target_uid, {"banned": new_status})
            
            user_banned_cache[target_uid] = {'banned': new_status, 'time': time.time()}
            
            status_text = "BANNED 🚫" if new_status else "UNBANNED ✅"
            send_message(chat_id, render_body_text(f"✅ User {target_uid} has been {status_text}!"), reply_markup=main_menu(chat_id))
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_um_prof_uid" and text:
            target_uid_str = text.strip()
            if not target_uid_str.isdigit():
                send_message(chat_id, render_body_text("❌ Invalid ID!"), reply_markup=get_cancel_kb())
                return
            target_uid = int(target_uid_str)
            data = _get_local_user(target_uid)
            is_verified = True if data.get('total_otps', 0) > 0 else data.get('verified', False)
            prof_text = f"""➖➖➖➖➖➖➖➖
👤 <b>USER PROFILE</b>
➖➖➖➖➖➖➖➖
🆔 ID: <code>{target_uid}</code>
💰 Balance: {data.get('balance', 0.0)} USDT
🤝 Total Refers: {data.get('total_refers', 0)}
🔐 Total OTPs: {data.get('total_otps', 0)}
✅ Verified: {is_verified}
🚫 Banned: {data.get('banned', False)}
➖➖➖➖➖➖➖➖"""
            kb = {"inline_keyboard": [[{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "user_management", "style": "primary"}]]}
            send_message(chat_id, render_body_text(prof_text), reply_markup=kb)
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        # --- Custom OTP style flows ---
        elif state == "wait_for_style_name" and text:
            style_name = re.sub(r"\s+", " ", text.strip())[:40]
            if not style_name:
                send_message(chat_id, render_body_text("❌ Name cannot be empty."))
                return
            existing_ids = {str(s.get("id")) for s in get_custom_otp_styles()}
            n = 1
            while f"custom{n}" in existing_ids:
                n += 1
            temp_data[chat_id]["style_name"] = style_name
            temp_data[chat_id]["style_id_new"] = f"custom{n}"
            user_states[chat_id] = "wait_for_style_template"
            try:
                delete_message(chat_id, msg["message_id"])
            except Exception:
                pass
            send_message(chat_id, render_body_text(
                f"2️⃣ <b>Template for “{html.escape(style_name)}”</b>\n\n"
                f"Send the message template.\n\n"
                f"🔤 Placeholders: <code>{html.escape(OTP_STYLE_PLACEHOLDERS)}</code>\n\n"
                f"<i>Example:</i>\n<code>━━━━━━━━━━\n{{flag}} {{iso}} {{app}}\n📱 {{number}}\n🔑 {{otp}}\n━━━━━━━━━━</code>"
            ), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "ostyle_menu", "style": "danger"}]]})
            return

        elif state == "wait_for_style_template" and text:
            template = extract_premium_html(msg)
            if not str(template or "").strip():
                send_message(chat_id, render_body_text("❌ Template cannot be empty."))
                return
            pending = temp_data.get(chat_id) or {}
            style_id = pending.get("style_id") or pending.get("style_id_new") or "custom1"
            style_name = pending.get("style_name")
            if pending.get("style_id"):
                for style in get_custom_otp_styles():
                    if str(style.get("id")) == str(style_id):
                        style["template"] = template
                        break
                notice = f"{PEM['ok']} <b>Style updated!</b>"
            else:
                bot_settings.setdefault("otp_styles", []).append({
                    "id": style_id,
                    "name": pending.get("style_name") or style_id,
                    "template": template,
                    "mask": True,
                })
                notice = f"{PEM['ok']} <b>Style “{html.escape(str(style_name))}” added!</b>"
                # instant preview in the active sample
                notice += "\n\nPreview:\n" + render_otp_style(
                    {"template": template, "mask": True},
                    otp_style_context("+8801712345678", "FACEBOOK", "#EN", True, None, "123456"),
                    fallback_mask=True,
                )
            save_db()
            try:
                delete_message(chat_id, msg["message_id"])
            except Exception:
                pass
            if chat_id in user_states: del user_states[chat_id]
            if chat_id in temp_data: del temp_data[chat_id]
            screen_msg_id = pending.get("msg_id")
            if screen_msg_id:
                edit_message(chat_id, screen_msg_id, sms_custom_style_text(), reply_markup=sms_custom_style_keyboard())
            send_message(chat_id, render_body_text(notice), reply_markup=sms_style_page_keyboard())
            return

        # --- Waiting SMS designer text flow ---
        elif state == "wait_for_wsms_text" and text:
            configured_key = (temp_data.get(chat_id) or {}).get("wsms_key", "waiting")
            screen_msg_id = (temp_data.get(chat_id) or {}).get("msg_id")
            formatted_html_text = extract_premium_html(msg)
            if not str(formatted_html_text or "").strip():
                send_message(chat_id, render_body_text("❌ Message cannot be empty."), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wsms_menu", "style": "danger"}]]})
                return
            entry = _wsms_entry(configured_key)
            entry["text"] = formatted_html_text
            save_db()
            try:
                delete_message(chat_id, msg["message_id"])
            except Exception:
                pass
            if chat_id in user_states: del user_states[chat_id]
            if chat_id in temp_data: del temp_data[chat_id]
            label = "Expired" if configured_key == "waiting_expired" else "Waiting"
            if screen_msg_id:
                edit_message(chat_id, screen_msg_id, wsms_page_text(notice=f"{PEM['ok']} <b>{label} message updated!</b>"), reply_markup=wsms_page_keyboard())
            else:
                send_message(chat_id, wsms_page_text(notice=f"{PEM['ok']} <b>{label} message updated!</b>"), reply_markup=wsms_page_keyboard())
            return

        # --- Menu Button Manager Flows (rename / emoji / url) ---
        elif state in ("wait_for_btn_label", "wait_for_btn_emoji", "wait_for_btn_url") and text:
            target = (temp_data.get(chat_id) or {}).get("btn_target") or {}
            screen_msg_id = (temp_data.get(chat_id) or {}).get("msg_id")
            if target.get("kind") == "inline":
                cancel_cb = f"mi_btn_{target.get('menu', '')}_{target.get('idx', 0)}"
            elif target.get("kind") == "system":
                cancel_cb = f"sys_btn_{target.get('key', '')}"
            else:
                cancel_cb = f"mb_btn_{target.get('idx', 0)}"
            if _button_target_object(target) is None:
                send_message(chat_id, render_body_text("❌ That button no longer exists."), reply_markup=main_menu(chat_id))
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
                return

            if state == "wait_for_btn_label":
                new_label = re.sub(r"\s+", " ", text.strip())[:64]
                if not new_label:
                    send_message(chat_id, render_body_text("❌ Button name cannot be empty."), reply_markup=_button_cancel_row(cancel_cb))
                    return
                _set_button_target_field(chat_id, "label", new_label)
                notice = f"{PEM['ok']} <b>Renamed to:</b> {html.escape(new_label)}"
            elif state == "wait_for_btn_emoji":
                emoji_id = ""
                for ent in (msg.get("entities") or []):
                    if ent.get("type") == "custom_emoji" and ent.get("custom_emoji_id"):
                        emoji_id = str(ent["custom_emoji_id"])
                        break
                if not emoji_id:
                    digits = re.sub(r"\D", "", str(text or ""))
                    if len(digits) >= 8:
                        emoji_id = digits
                if not emoji_id:
                    send_message(chat_id, render_body_text("❌ No premium emoji found. Send the premium emoji itself or paste its numeric emoji ID."), reply_markup=_button_cancel_row(cancel_cb))
                    return
                _set_button_target_field(chat_id, "emoji", emoji_id)
                notice = f"{PEM['ok']} <b>Emoji set:</b> <code>{html.escape(emoji_id)}</code>"
            else:
                url = str(text or "").strip()
                if not re.match(r"^(https?://|tg://)", url, re.I):
                    send_message(chat_id, render_body_text("❌ Invalid link. Send a full URL starting with <code>https://</code> or <code>tg://</code>"), reply_markup=_button_cancel_row(cancel_cb))
                    return
                _set_button_target_field(chat_id, "url", url)
                notice = f"{PEM['ok']} <b>Link updated:</b> <code>{html.escape(url)}</code>"

            try:
                delete_message(chat_id, msg["message_id"])
            except Exception:
                pass
            if chat_id in user_states: del user_states[chat_id]
            if chat_id in temp_data: del temp_data[chat_id]
            _edit_button_screen(chat_id, screen_msg_id, target, notice)
            return

        # --- Menu Design Flow ---
        elif state == "wait_for_menu_text" and text:
            try:
                menu_key = temp_data[chat_id]["menu_key"]
                formatted_html_text = extract_premium_html(msg)
                
                bot_settings["custom_messages"][menu_key]["text"] = formatted_html_text
                save_db()
                
                delete_message(chat_id, msg["message_id"])
                
                preview_text = render_body_text(formatted_html_text)
                success_text = f"{PEM['ok']} <b>Message Body Updated successfully!</b>\n\n🎨 <b>Editing: {menu_key.upper()}</b>\n\nPreview of current Text:\n{preview_text}"
                edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(success_text), reply_markup=menu_edit_options_keyboard(menu_key))
            except Exception as e:
                send_message(chat_id, f"❌ Error saving text: {e}")
            finally:
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
            return
            
        elif state == "wait_for_menu_btn" and text:
            try:
                menu_key = temp_data[chat_id]["menu_key"]
                if "-" in text:
                    parts = text.split("-", 1)
                    btn_text = parts[0].strip()
                    btn_url = parts[1].strip()
                    
                    emoji_id = None
                    emoji_char = ""
                    for ent in msg.get("entities", []):
                        if ent.get("type") == "custom_emoji":
                            emoji_id = ent.get("custom_emoji_id")
                            offset = ent.get("offset", 0)
                            length = ent.get("length", 0)
                            b_text = text.encode('utf-16-le')
                            emoji_char = b_text[offset*2:(offset+length)*2].decode('utf-16-le')
                            break
                            
                    if emoji_char:
                        btn_text = btn_text.replace(emoji_char, "").strip()
                        
                    btn_data = {"text": btn_text, "url": btn_url, "style": "primary"}
                    if emoji_id:
                        btn_data["icon_custom_emoji_id"] = emoji_id
                        
                    bot_settings["custom_messages"][menu_key]["buttons"].append(btn_data)
                    save_db()
                    delete_message(chat_id, msg["message_id"])
                    edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(f"{PEM['gear']} <b>Edit Inline Buttons: {menu_key.upper()}</b>"), reply_markup=menu_buttons_list_keyboard(menu_key))
                else:
                    send_message(chat_id, render_body_text(f"{PEM['no']} Invalid format. Use <code>Button Text - https://link.com</code>"))
            except Exception as e:
                 pass
            finally:
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
            return

        elif state == "wait_for_sim_input" and text:
            # Expected format: 🇧🇩 BD Facebook 880 #EN [otp_template]
            raw = text.strip()
            parts = raw.split()
            if len(parts) < 4:
                send_message(chat_id, render_body_text(
                    "❌ <b>Invalid format!</b>\n\n"
                    "Use: <code>🇧🇩 BD Facebook 880 #EN</code>\n\n"
                    "• <b>Flag emoji</b> (🇧🇩)\n"
                    "• <b>ISO code</b> (BD)\n"
                    "• <b>Platform name</b> (Facebook)\n"
                    "• <b>Dial code</b> (880)\n"
                    "• <b>Language tag</b> (#EN) <i>optional</i>\n"
                    "• <b>OTP pattern</b> (12345 / 123-45 / 123-456) <i>optional</i>"
                ), reply_markup=get_cancel_kb())
                return

            flag = parts[0]
            iso  = parts[1].upper()
            lang = "#EN"
            dial_code = ""
            platform_parts = []
            otp_template_str = None
            dial_code_found = False

            for part in parts[2:]:
                if part.startswith("#"):
                    lang = part.upper()
                elif part.isdigit() and not dial_code_found:
                    dial_code = part
                    dial_code_found = True
                elif dial_code_found and _is_otp_template(part):
                    otp_template_str = part
                else:
                    platform_parts.append(part)

            if not dial_code:
                send_message(chat_id, render_body_text(
                    "❌ <b>Dial code not found!</b>\n\nPlease include the numeric dial code, e.g. <code>880</code>"
                ), reply_markup=get_cancel_kb())
                return

            platform = " ".join(platform_parts) if platform_parts else "Unknown"
            otp_template_parts = _parse_otp_template(otp_template_str) if otp_template_str else None

            sim_id = str(uuid.uuid4())[:8]
            stop_event = threading.Event()

            active_test_simulations[sim_id] = {
                "flag": flag,
                "iso": iso,
                "platform": platform,
                "dial_code": dial_code,
                "lang": lang,
                "otp_template_parts": otp_template_parts,
                "otp_template_str": otp_template_str,
                "stop_event": stop_event,
                "running": False,
                "total_sent": 0,
                "start_time": time.time(),
            }

            t = threading.Thread(target=run_test_simulation, args=(sim_id,), daemon=True)
            t.start()

            otp_line = f"\n🔑 <b>OTP Pattern:</b> <code>{otp_template_str}</code>" if otp_template_str else ""
            orig_msg_id = temp_data.get(chat_id, {}).get("msg_id")
            success_txt = (
                f"✅ <b>Test Simulation Started!</b>\n\n"
                f"🌍 <b>Country:</b> {flag} {iso}\n"
                f"📱 <b>Platform:</b> {platform}\n"
                f"📞 <b>Dial Code:</b> {dial_code}\n"
                f"🌐 <b>Language:</b> {lang}"
                f"{otp_line}\n\n"
                f"<i>Sending 2,880 fake messages over 24 hours to all Forward Groups.</i>"
            )
            kb = {"inline_keyboard": [
                [{"text": "📊 View All Simulations", "icon_custom_emoji_id": "5190781475468915802", "callback_data": "test_message_flow", "style": "success"}]
            ]}
            if orig_msg_id:
                try:
                    edit_message(chat_id, orig_msg_id, render_body_text(success_txt), reply_markup=kb)
                except:
                    send_message(chat_id, render_body_text(success_txt), reply_markup=kb)
            else:
                send_message(chat_id, render_body_text(success_txt), reply_markup=kb)

            del user_states[chat_id]
            if chat_id in temp_data: del temp_data[chat_id]
            return

        elif state == "wait_for_emoji_extract":
            entities = msg.get("entities", [])
            custom_emoji_id = None
            emoji_text = ""
            for ent in entities:
                if ent.get("type") == "custom_emoji":
                    custom_emoji_id = ent.get("custom_emoji_id")
                    offset = ent.get("offset", 0)
                    length = ent.get("length", 0)
                    b_text = msg.get("text", "").encode('utf-16-le')
                    emoji_text = b_text[offset*2:(offset+length)*2].decode('utf-16-le')
                    break
            
            if custom_emoji_id:
                temp_data[chat_id] = {"id": custom_emoji_id, "char": emoji_text}
                user_states[chat_id] = "wait_for_emoji_details"
                send_message(chat_id, render_body_text(f"{PEM['ok']} Emoji ID found: <code>{custom_emoji_id}</code>\n\n📌 Now type and enter the name to save it.\n\n<b>Format:</b>\n`FLAG | 880 | BD | Bangladesh`\nor\n`APP | WhatsApp`"), reply_markup=get_cancel_kb())
            else:
                send_message(chat_id, render_body_text(f"{PEM['no']} No Premium Emoji found! Please send a Custom Emoji."), reply_markup=get_cancel_kb())
            return
            
        elif state == "wait_for_emoji_details" and text:
            parts = [p.strip() for p in text.split("|")]
            mode = parts[0].upper()
            eid = temp_data[chat_id]["id"]
            char = temp_data[chat_id]["char"]
            
            if mode == "FLAG" and len(parts) == 4:
                code, iso, name = parts[1], parts[2], parts[3]
                bot_settings["premium_flags"][code] = {"char": char, "iso": iso.upper(), "name": name, "id": eid}
                save_db()
                send_message(chat_id, render_body_text(f"{PEM['ok']} Flag Emoji saved!\nCode: {code} | Name: {name}"), reply_markup=emoji_settings_keyboard())
            elif mode == "APP" and len(parts) == 2:
                name = parts[1]
                bot_settings["premium_apps"][name.upper()] = {"char": char, "id": eid, "name": name.title()}
                save_db()
                send_message(chat_id, render_body_text(f"{PEM['ok']} App Emoji saved!\nName: {name}"), reply_markup=emoji_settings_keyboard())
            else:
                send_message(chat_id, render_body_text(f"{PEM['no']} Wrong format!\n\nCorrect format:\n`FLAG | 880 | BD | Bangladesh`\n`APP | WhatsApp`"))
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state in ["wait_for_flag_txt", "wait_for_app_txt"] and "document" in msg:
            doc = msg["document"]
            if not doc["file_name"].endswith(".txt"):
                send_message(chat_id, render_body_text(f"{PEM['no']} Please upload a .txt file only."))
                return
            file_id = doc["file_id"]
            file_info = requests.get(f"{BASE_URL}/getFile?file_id={file_id}").json()
            file_path = file_info["result"]["file_path"]
            content = requests.get(f"{FILE_URL}{file_path}").text
            
            mode = "flags" if state == "wait_for_flag_txt" else "apps"
            count = 0
            
            if mode == "flags":
                for line in content.splitlines():
                    json_match = re.search(r'(\{.*\})', line)
                    if json_match:
                        try:
                            data = json.loads(json_match.group(1))
                            char = data.get("emoji")
                            eid = data.get("id")
                            
                            prefix_str = line[:json_match.start()].strip()
                            code_match = re.search(r'\((\d+)\)', prefix_str)
                            iso_match = re.search(r'\(([A-Za-z]+)\)', prefix_str)
                            
                            if code_match and iso_match and char and eid:
                                code = code_match.group(1)
                                iso = iso_match.group(1).upper()
                                name = prefix_str.replace(f"({code})", "").replace(f"({iso_match.group(1)})", "").replace(char, "").strip()
                                bot_settings["premium_flags"][code] = {"char": char, "iso": iso, "name": name, "id": eid}
                                count += 1
                        except: pass
            else:
                for line in content.splitlines():
                    json_match = re.search(r'(\{.*\})', line)
                    if json_match:
                        try:
                            data = json.loads(json_match.group(1))
                            char = data.get("emoji")
                            eid = data.get("id")
                            
                            name_part = line[:json_match.start()].strip()
                            name = name_part.replace(char, '').strip() if char else name_part
                            
                            if char and eid and name:
                                bot_settings["premium_apps"][name.upper()] = {"char": char, "id": eid, "name": name}
                                count += 1
                        except: pass
            
            save_db()
            send_message(chat_id, render_body_text(f"{PEM['ok']} Successfully loaded {count} Emojis!"), reply_markup=emoji_settings_keyboard())
            del user_states[chat_id]
            return

        elif state == "wait_for_broadcast":
            msg_id = msg["message_id"]
            send_message(chat_id, render_body_text(f"{PEM['ok']} Broadcast started..."))
            threading.Thread(target=broadcast_copymessage, args=(chat_id, msg_id), daemon=True).start()
            del user_states[chat_id]
            return

        elif state == "wait_for_backup_file" and not msg.get("document") and text:
            send_message(chat_id, render_body_text(
                f"{PEM['no']} ফাইল হিসেবে পাঠান — <b>📎 → File</b> দিয়ে সেই <code>.json</code> ব্যাকআপ ফাইলটা দিন।\n\n"
                "বাতিল করতে: /start"
            ), reply_markup={"inline_keyboard": [[
                {"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "backup_menu", "style": "danger"}
            ]]})
            return

        elif state == "wait_for_backup_file" and "document" in msg:
            doc = msg["document"]
            file_name = str(doc.get("file_name") or "")
            if not file_name.lower().endswith((".json", ".txt")):
                send_message(chat_id, render_body_text(
                    f"{PEM['no']} Please send the <code>.json</code> backup file (from 📥 Download Data File)."
                ))
                return
            try:
                file_info = requests.get(f"{BASE_URL}/getFile?file_id={doc['file_id']}").json()
                file_path = file_info["result"]["file_path"]
                raw = requests.get(f"{FILE_URL}{file_path}").content.decode("utf-8")
                bundle = json.loads(raw)
            except Exception as exc:
                send_message(chat_id, render_body_text(f"{PEM['no']} Could not read the file: {str(exc)[:150]}"))
                return
            try:
                report = import_backup_bundle(bundle)
            except Exception as exc:
                send_message(chat_id, render_body_text(f"{PEM['no']} Import failed: {str(exc)[:150]}"))
                return
            if chat_id in user_states:
                del user_states[chat_id]
            temp_data.pop(chat_id, None)
            send_message(chat_id, backup_import_report_text(report), reply_markup=backup_menu_keyboard())
            return

        elif state == "wait_for_txt" and "document" in msg:
            doc = msg["document"]
            if not doc["file_name"].endswith(".txt"):
                send_message(chat_id, render_body_text(f"{PEM['no']} Please upload a .txt file only."))
                return
            file_id = doc["file_id"]
            file_info = requests.get(f"{BASE_URL}/getFile?file_id={file_id}").json()
            file_path = file_info["result"]["file_path"]
            file_content = requests.get(f"{FILE_URL}{file_path}").text
            
            temp_data[chat_id] = {"numbers": file_content.splitlines(), "filename": doc["file_name"]}
            user_states[chat_id] = "wait_for_service"
            send_message(chat_id, render_body_text(f"{PEM['ok']} File received.\n\n📌 Enter the service name (e.g., WHATSAPP):"), reply_markup=get_cancel_kb())
            return

        elif state == "wait_for_service" and text:
            temp_data[chat_id]["service"] = canonical_service_name(text)
            user_states[chat_id] = "wait_for_country"
            send_message(chat_id, render_body_text(f"{PEM['ok']} Service set.\n\n🌍 Enter the country name (e.g., YEMEN):"), reply_markup=get_cancel_kb())
            return

        elif state == "wait_for_country" and text:
            country = canonical_country_name(text)
            service = temp_data[chat_id]["service"]
            raw_numbers = temp_data[chat_id]["numbers"]
            
            clean_nums = []
            for num in raw_numbers:
                num = num.strip()
                if num:
                    if not num.startswith('+'): num = '+' + num
                    clean_nums.append(num)
            
            batch_id = str(uuid.uuid4())[:8]
            number_batches[batch_id] = {"filename": temp_data[chat_id]["filename"], "service": service, "country": country, "numbers": [{"num": n, "shares": 0, "used_by": []} for n in clean_nums]}
            total_uploaded_stats += len(clean_nums)
            save_db()
            
            app_full_name, prem_app_html = get_service_info_html(service)
            prem_flag_html = get_flag_info_html(clean_nums[0]) if clean_nums else f"{PEM['world']} "
            
            broadcast_txt = f"➖➖➖➖➖➖➖➖\n《 NEW NUMBERS 》\n➖➖➖➖➖➖➖➖\n{prem_flag_html} {country} {prem_app_html} {service}\n➖➖➖➖➖➖➖➖\n📤 Total Added: <b>{len(clean_nums)}</b>\n➖➖➖➖➖➖➖➖\nUse /start to get your numbers!"
            broadcast_txt = render_body_text(broadcast_txt)
            
            send_message(chat_id, render_body_text(f"{PEM['ok']} Numbers added to local stock! Starting broadcast..."))
            
            def simple_broadcast(txt):
                b_session = requests.Session()
                url = f"{BASE_URL}/sendMessage"
                for u_id in list(all_known_users):
                    try:
                        b_session.post(url, json={"chat_id": u_id, "text": txt, "parse_mode": "HTML", "disable_web_page_preview": True}, timeout=5)
                    except: pass
                    time.sleep(0.035)
            threading.Thread(target=simple_broadcast, args=(broadcast_txt,), daemon=True).start()
            
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_add_nexa_key" and text:
            bot_settings["nexa_keys"].append(text.strip())
            save_db()
            delete_message(chat_id, msg["message_id"])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(f"✅ Nexa API Key Added! Total Keys: {len(bot_settings.get('nexa_keys', []))}"), reply_markup=nexa_control_keyboard())
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_add_sc" and text:
            code = text.strip().replace("+", "")
            if "search_countries" not in bot_settings: bot_settings["search_countries"] = []
            bot_settings["search_countries"].append(code)
            save_db()
            delete_message(chat_id, msg["message_id"])
            kb = []
            for idx, c in enumerate(bot_settings.get("search_countries", [])):
                kb.append([{"text": f"❌ Delete {c}", "callback_data": f"del_sc_{idx}", "style": "danger"}])
            kb.append([{"text": "➕ Add Country Code", "callback_data": "add_search_country", "style": "success"}])
            kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "nexa_control", "style": "primary"}])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("🌍 <b>Allowed Search Countries:</b>\nOnly these country codes will be allowed in Search Number."), reply_markup={"inline_keyboard": kb})
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_nx_srv_name" and text:
            srv = text.strip().upper()
            if "nexa_services" not in bot_settings: bot_settings["nexa_services"] = {}
            if srv not in bot_settings["nexa_services"]: bot_settings["nexa_services"][srv] = {}
            save_db()
            delete_message(chat_id, msg["message_id"])
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": temp_data[chat_id]["msg_id"]}, "data": "manage_nexa_srv", "id": "internal"})
            del user_states[chat_id]
            return

        elif state == "wait_nx_cnt_name" and text:
            cnt = text.strip()
            srv = temp_data[chat_id].get("srv") or ""
            if not srv:
                del user_states[chat_id]
                send_message(chat_id, render_body_text("⚠️ Session expired — open Nexa Control again."))
                return
            svc_map = bot_settings.setdefault("nexa_services", {})
            if not isinstance(svc_map.get(srv), dict):
                svc_map[srv] = {}
            if cnt not in svc_map[srv]: svc_map[srv][cnt] = []
            save_db()
            delete_message(chat_id, msg["message_id"])
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": temp_data[chat_id]["msg_id"]}, "data": f"nx_srv_{srv}", "id": "internal"})
            del user_states[chat_id]
            return

        elif state == "wait_nx_addr" and text:
            srv, cnt = temp_data[chat_id].get("srv"), temp_data[chat_id].get("cnt")
            new_range = text.strip().replace("+", "")
            svc_map = bot_settings.setdefault("nexa_services", {})
            if not srv or not cnt or cnt not in (svc_map.get(srv) or {}):
                del user_states[chat_id]
                send_message(chat_id, render_body_text("⚠️ That country was removed — open Nexa Control again."))
                return
            
            if new_range not in svc_map[srv][cnt]:
                svc_map[srv][cnt].append(new_range)
                
                if "search_countries" not in bot_settings:
                    bot_settings["search_countries"] = []
                if new_range not in bot_settings["search_countries"]:
                    bot_settings["search_countries"].append(new_range)
                    
                save_db()
                
            delete_message(chat_id, msg["message_id"])
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": temp_data[chat_id]["msg_id"]}, "data": f"nx_cnt_{srv}_{cnt}", "id": "internal"})
            del user_states[chat_id]
            return

        elif state == "wait_for_add_wm" and text:
            bot_settings["w_methods"].append(text.strip())
            save_db()
            delete_message(chat_id, msg["message_id"])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("💳 <b>WITHDRAWAL METHODS</b>\n\nManage your withdrawal methods below:"), reply_markup=w_methods_keyboard())
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_add_fj" and text:
            raw_input = text.strip()
            # Handle private invite links (https://t.me/+xxx or https://t.me/joinchat/xxx)
            if "t.me/+" in raw_input or "t.me/joinchat/" in raw_input:
                # For private invite links, we need the numeric chat_id
                # Admin must also provide numeric ID for private chats
                delete_message(chat_id, msg["message_id"])
                edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("⚠️ <b>Private invite link detected!</b>\n\nPrivate channel/group ke liye numeric ID bhejein (e.g. <code>-1001234567890</code>)\n\nID kaise pata karein:\n1. Channel/Group mein koi message forward karein\n2. @userinfobot ko forward karein\n3. Woh aapko ID de dega"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_fj", "style": "danger"}]]})
                return
            parsed_id = parse_chat_id(raw_input)
            detected = auto_detect_chat(parsed_id)
            if detected:
                bot_settings["fj_channels"].append(detected)
                save_db()
                delete_message(chat_id, msg["message_id"])
                type_label = "Channel" if detected["type"] == "channel" else "Group"
                priv_label = "Private" if detected["is_private"] else "Public"
                edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(f"✅ <b>Successfully Added!</b>\n\n{type_label} | {priv_label}\n📌 Title: <b>{detected['title']}</b>\n🆔 ID: <code>{detected['chat_id']}</code>\n🔗 Link: {detected.get('invite_link', 'N/A')}"), reply_markup=fj_settings_keyboard())
            else:
                delete_message(chat_id, msg["message_id"])
                edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("❌ <b>Error!</b> Bot is not admin in this channel/group ya invalid ID hai.\n\nMake sure:\n1. Bot ko channel/group mein add karein\n2. Bot ko admin banaayein\n3. Phir dobara try karein"), reply_markup={"inline_keyboard": [[{"text": "?? Try Again", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_fj", "style": "success"}, {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_fj", "style": "danger"}]]})
            del user_states[chat_id]
            del temp_data[chat_id]
            return
            
        elif state == "wait_for_add_adm" and text:
            if text.isdigit():
                bot_settings["admins"].append(int(text))
                save_db()
            delete_message(chat_id, msg["message_id"])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("👥 <b>ADMIN MANAGEMENT</b>\nManage your bot admins below:"), reply_markup=admin_settings_keyboard())
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_add_fw_id" and text:
            bot_settings["fw_groups"].append({"chat_id": text.strip(), "buttons": []})
            save_db()
            delete_message(chat_id, msg["message_id"])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:"), reply_markup=otp_groups_list_keyboard())
            del user_states[chat_id]
            del temp_data[chat_id]
            return
            
        elif state == "wait_for_add_fw_btn" and text:
            fw_idx = temp_data[chat_id]["fw_idx"]
            if "-" in text:
                parts = text.split("-", 1)
                btn_text = parts[0].strip()
                btn_url = parts[1].strip()
                
                emoji_id = None
                emoji_char = ""
                for ent in msg.get("entities", []):
                    if ent.get("type") == "custom_emoji":
                        emoji_id = ent.get("custom_emoji_id")
                        offset = ent.get("offset", 0)
                        length = ent.get("length", 0)
                        b_text = text.encode('utf-16-le')
                        emoji_char = b_text[offset*2:(offset+length)*2].decode('utf-16-le')
                        break
                
                if emoji_char:
                    btn_text = btn_text.replace(emoji_char, "").strip()
                    
                btn_data = {"text": btn_text, "url": btn_url}
                if emoji_id:
                    btn_data["icon_custom_emoji_id"] = emoji_id
                    
                bot_settings["fw_groups"][fw_idx]["buttons"].append(btn_data)
                save_db()
            delete_message(chat_id, msg["message_id"])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(f"🛡 <b>Manage Group:</b> {bot_settings['fw_groups'][fw_idx]['chat_id']}"), reply_markup=specific_fw_group_keyboard(fw_idx))
            del user_states[chat_id]
            del temp_data[chat_id]
            return
            
        elif state == "wait_for_otp_link" and text:
            bot_settings["otp_link"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text("🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:"), reply_markup=otp_groups_list_keyboard())
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_panel_name" and text:
            p_name = text.strip()
            t_key = temp_data[chat_id].get("add_type", "api")
            msg_id = temp_data[chat_id]["msg_id"]
            delete_message(chat_id, msg["message_id"])
            
            if t_key == "logc":
                user_states[chat_id] = "wait_for_cpanel_url"
                temp_data[chat_id] = {"msg_id": msg_id, "p_data": {
                    "name": p_name, "type": "Auto Captcha Panel", "status": "ON", "records": 0, "login_status": "⏳ Pending First Login"
                }}
                edit_message(chat_id, msg_id, render_body_text("1️⃣ <b>Login URL</b>\n➡️ Enter Panel Login Link:"), reply_markup=get_cancel_kb())
                return
            elif t_key == "voltx":
                bot_settings["panels"].append({
                    "name": p_name, "type": "VoltX Panel", "status": "OFF",
                    "base_url": "", "api_key": "", "getnum_url": "", "getmsg_url": "", "traffic_url": "",
                    "lastSeenGetnumIds": [], "services": {}
                })
                save_db()
                handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_voltx_panels", "id": "internal"})
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
                return
            elif t_key == "fastx":
                bot_settings["panels"].append({
                    "name": p_name, "type": "FastX Panel", "status": "OFF",
                    "base_url": "", "api_key": "", "getnum_url": "", "getmsg_url": "", "traffic_url": "",
                    "lastSeenGetnumIds": [], "services": {}
                })
                save_db()
                handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_fastx_panels", "id": "internal"})
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
                return
            elif t_key == "stex":
                bot_settings["panels"].append({
                    "name": p_name, "type": "Stex Panel", "status": "OFF",
                    "base_url": STEX_DEFAULT_BASE_URL, "api_key": "", "getnum_url": "", "getmsg_url": "", "traffic_url": "",
                    "lastSeenGetnumIds": [], "services": {}
                })
                save_db()
                handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_stex_panels", "id": "internal"})
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
                return
            else:
                bot_settings["panels"].append({
                    "name": p_name, "type": "API Panel", "status": "OFF", "api_url": "", "token": "", "records": 0, "needs_warmup": True
                })
                save_db()
                handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_api_panels", "id": "internal"})
                if chat_id in user_states: del user_states[chat_id]
                if chat_id in temp_data: del temp_data[chat_id]
                return

        elif state == "wait_for_p_api" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["api_url"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>API URL:</b> <code>{p.get('api_url', 'None')}</code>\n<b>Token:</b> <code>{p.get('token', 'None')}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_p_tok" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["token"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>API URL:</b> <code>{p.get('api_url', 'None')}</code>\n<b>Token:</b> <code>{p.get('token', 'None')}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_p_fapi" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["full_api_url"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>API URL:</b> <code>{p.get('api_url', 'None')}</code>\n<b>Full API URL:</b> <code>{p.get('full_api_url', 'None')}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_p_rec" and text:
            if text.isdigit():
                idx = temp_data[chat_id]["p_idx"]
                bot_settings["panels"][idx]["records"] = int(text)
                save_db()
                delete_message(chat_id, msg["message_id"])
                p = bot_settings["panels"][idx]
                
                ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>API URL:</b> <code>{p.get('api_url', 'None')}</code>\n<b>Token:</b> <code>{p.get('token', 'None')}</code>"
                edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            else:
                send_message(chat_id, render_body_text("❌ Please enter a valid number! Try again."), reply_markup=get_cancel_kb())
            del user_states[chat_id]
            del temp_data[chat_id]
            return


        # ==========================================
        # 🌟 VoltX Panel Edit State Handlers
        # ==========================================
        elif state == "wait_for_voltx_base_url" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["base_url"] = text.strip().rstrip("/")
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            api_key_m = (p.get("api_key","")[:4]+"****"+p.get("api_key","")[-4:]) if len(p.get("api_key",""))>8 else p.get("api_key","None")
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p)=='ON' else '🔴 Stopped'}\n<b>Base URL:</b> <code>{p.get('base_url','None')}</code>\n<b>API Key:</b> <code>{api_key_m}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "wait_for_voltx_api_key" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["api_key"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            api_key_m = (p.get("api_key","")[:4]+"****"+p.get("api_key","")[-4:]) if len(p.get("api_key",""))>8 else p.get("api_key","None")
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p)=='ON' else '🔴 Stopped'}\n<b>Base URL:</b> <code>{p.get('base_url','None')}</code>\n<b>API Key:</b> <code>{api_key_m}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "wait_for_voltx_getnum_url" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["getnum_url"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>GetNum URL:</b> <code>{p.get('getnum_url','Auto')}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "wait_for_voltx_getmsg_url" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["getmsg_url"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>GetMsg URL:</b> <code>{p.get('getmsg_url','Auto')}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "wait_for_voltx_traffic_url" and text:
            idx = temp_data[chat_id]["p_idx"]
            bot_settings["panels"][idx]["traffic_url"] = text.strip()
            save_db()
            delete_message(chat_id, msg["message_id"])
            p = bot_settings["panels"][idx]
            ui_text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Traffic URL:</b> <code>{p.get('traffic_url','Auto')}</code>"
            edit_message(chat_id, temp_data[chat_id]["msg_id"], render_body_text(ui_text), reply_markup=panel_config_keyboard(idx))
            del user_states[chat_id]; del temp_data[chat_id]
            return

        # Panel-specific VoltX/FastX service and range state handlers.
        elif state == "wait_pvs_srv_name" and text:
            panel_idx = temp_data[chat_id]["panel_idx"]
            msg_id = temp_data[chat_id]["msg_id"]
            panel = get_number_panel_for_source(panel_idx)
            if not panel:
                send_message(chat_id, render_body_text("❌ Panel not found."))
                del user_states[chat_id]
                del temp_data[chat_id]
                return
            services = get_panel_services(panel, create=True)
            service = canonical_service_name(text)
            existing = next(
                (name for name in services if service_names_equal(name, service)),
                None,
            )
            if existing:
                service = existing
            else:
                services[service] = {}
            save_db()
            delete_message(chat_id, msg["message_id"])
            ui_text, markup = panel_services_manager_view(panel_idx)
            edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_pvs_cnt_name" and text:
            panel_idx = temp_data[chat_id]["panel_idx"]
            service_idx = temp_data[chat_id]["service_idx"]
            msg_id = temp_data[chat_id]["msg_id"]
            panel = get_number_panel_for_source(panel_idx)
            services = get_panel_service_items(panel) if panel else []
            if not panel or not (0 <= service_idx < len(services)):
                send_message(chat_id, render_body_text("❌ Service not found."))
                del user_states[chat_id]
                del temp_data[chat_id]
                return
            service, countries = services[service_idx]
            country = canonical_country_name(text)
            existing = next(
                (name for name in countries if country_names_equal(name, country)),
                None,
            )
            if existing:
                country = existing
            else:
                countries[country] = []
            save_db()
            delete_message(chat_id, msg["message_id"])
            ui_text, markup = panel_service_countries_view(panel_idx, service_idx)
            edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_pvs_range" and text:
            panel_idx = temp_data[chat_id]["panel_idx"]
            service_idx = temp_data[chat_id]["service_idx"]
            country_idx = temp_data[chat_id]["country_idx"]
            msg_id = temp_data[chat_id]["msg_id"]
            panel = get_number_panel_for_source(panel_idx)
            services = get_panel_service_items(panel) if panel else []
            if not panel or not (0 <= service_idx < len(services)):
                send_message(chat_id, render_body_text("❌ Service not found."))
                del user_states[chat_id]
                del temp_data[chat_id]
                return
            service, countries = services[service_idx]
            countries = list((countries or {}).items())
            if not (0 <= country_idx < len(countries)):
                send_message(chat_id, render_body_text("❌ Country not found."))
                del user_states[chat_id]
                del temp_data[chat_id]
                return
            country, ranges = countries[country_idx]
            new_range = text.strip().replace("+", "")
            if new_range and new_range not in ranges:
                ranges.append(new_range)
            save_db()
            delete_message(chat_id, msg["message_id"])
            ui_text, markup = panel_service_country_view(
                panel_idx,
                service_idx,
                country_idx,
            )
            edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        # 🌟 VoltX Services State Handlers
        elif state == "wait_vx_srv_name" and text:
            srv = canonical_service_name(text)
            msg_id = temp_data[chat_id]["msg_id"]
            if "voltx_services" not in bot_settings: bot_settings["voltx_services"] = {}
            existing_srv = next(
                (name for name in bot_settings["voltx_services"] if service_names_equal(name, srv)),
                None,
            )
            if existing_srv:
                srv = existing_srv
            else:
                bot_settings["voltx_services"][srv] = {}
            save_db()
            delete_message(chat_id, msg["message_id"])
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_vx_srv", "id": "internal"})
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "wait_vx_cnt_name" and text:
            srv = temp_data[chat_id].get("srv") or "FACEBOOK"
            msg_id = temp_data[chat_id].get("msg_id")
            cnt = canonical_country_name(text)
            vx_map = bot_settings.setdefault("voltx_services", {})
            if not isinstance(vx_map.get(srv), dict):
                vx_map[srv] = {}
            existing_cnt = next(
                (name for name in vx_map[srv] if country_names_equal(name, cnt)),
                None,
            )
            if existing_cnt:
                cnt = existing_cnt
            else:
                vx_map[srv][cnt] = []
            save_db()
            delete_message(chat_id, msg["message_id"])
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": f"vx_srv_{srv}", "id": "internal"})
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "wait_vx_addr" and text:
            srv = temp_data[chat_id].get("srv")
            cnt = temp_data[chat_id].get("cnt")
            msg_id = temp_data[chat_id].get("msg_id")
            new_range = text.strip()
            svc_map = bot_settings.setdefault("voltx_services", {})
            if not srv or not cnt or cnt not in (svc_map.get(srv) or {}):
                del user_states[chat_id]
                send_message(chat_id, render_body_text("⚠️ That country was removed — open VoltX Control again."))
                return
            if new_range not in svc_map[srv][cnt]:
                svc_map[srv][cnt].append(new_range)
            save_db()
            delete_message(chat_id, msg["message_id"])
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": f"vx_cnt_{srv}_{cnt}", "id": "internal"})
            del user_states[chat_id]; del temp_data[chat_id]
            return

        elif state == "set_abhi":
            msg_id = temp_data[chat_id]["msg_id"]
            key = temp_data[chat_id]["key"]
            try:
                if key in ["min_withdraw", "otp_reward", "refer_reward"]: bot_settings[key] = float(text)
                elif key in ["cooldown", "num_req", "num_share"]: bot_settings[key] = int(text)
                else: bot_settings[key] = text
                save_db()
                delete_message(chat_id, msg["message_id"])
                edit_message(chat_id, msg_id, render_body_text("🕹 <b>SHAHADOT X DEV CONTROL PANEL</b>"), reply_markup=abhi_control_keyboard())
            except:
                delete_message(chat_id, msg["message_id"])
                edit_message(chat_id, msg_id, render_body_text("🕹 <b>SHAHADOT X DEV CONTROL PANEL</b>\n\n❌ Invalid value!"), reply_markup=abhi_control_keyboard())
            del user_states[chat_id]
            del temp_data[chat_id]
            return

        elif state == "wait_for_cor_value" and text:
            msg_id = temp_data[chat_id]["msg_id"]
            iso = temp_data[chat_id]["cor_iso"]
            try:
                val = float(text.strip())
                if val < 0: raise ValueError
                if "country_otp_rewards" not in bot_settings:
                    bot_settings["country_otp_rewards"] = {}
                bot_settings["country_otp_rewards"][iso.upper()] = val
                save_db()
                delete_message(chat_id, msg["message_id"])
                country_name = iso
                for _, info in COUNTRY_DB.items():
                    if info.get("iso", "").upper() == iso.upper():
                        country_name = info.get("name", iso)
                        break
                answer_callback("", "")
                edit_message(chat_id, msg_id,
                    render_body_text(f"✅ <b>Country OTP Reward Set!</b>\n🌍 Country: <b>{country_name}</b>\n💰 Reward: <b>{val} USDT</b>"),
                    reply_markup=country_otp_rewards_keyboard())
            except:
                delete_message(chat_id, msg["message_id"])
                edit_message(chat_id, msg_id, render_body_text("❌ Invalid amount! Enter a positive number (e.g. 0.5):"),
                    reply_markup={"inline_keyboard": [[{"text": "Cancel", "callback_data": "cor_list", "style": "danger"}]]})
            if chat_id in user_states: del user_states[chat_id]
            if chat_id in temp_data: del temp_data[chat_id]
            return

        elif state == "wait_for_search" and text:
            query = text.strip().replace("+", "")
            if not query.isdigit() or len(query) < 3 or len(query) > 9:
                send_message(chat_id, render_body_text("❌ Please enter a valid 3 to 9 digit number!"))
                return
                
            wait_msg = send_message(chat_id, render_body_text("⌛ <i>Processing... Finding Number...</i>"))
            wait_msg_id = wait_msg.get("result", {}).get("message_id")
            
            # 🌟 1. First search number from Local (for any country)
            found_indices = []
            for b_id, b_data in number_batches.items():
                for idx, n_obj in enumerate(b_data["numbers"]):
                    if n_obj["num"].replace("+", "").startswith(query) and chat_id not in n_obj.get("used_by", []):
                        found_indices.append((b_id, idx))

            # Recycle: if no available numbers, reset all matching numbers and re-search
            if not found_indices:
                has_matching = False
                for b_id, b_data in number_batches.items():
                    for n_obj in b_data["numbers"]:
                        if n_obj["num"].replace("+", "").startswith(query):
                            has_matching = True
                            n_obj["shares"] = 0
                            n_obj["used_by"] = []
                if has_matching:
                    for b_id, b_data in number_batches.items():
                        for idx, n_obj in enumerate(b_data["numbers"]):
                            if n_obj["num"].replace("+", "").startswith(query):
                                found_indices.append((b_id, idx))

            fetched_nums = []
            if not found_indices:
                # 🌟 2. If not found in Local, then check if can get from Nexa
                allowed_countries = bot_settings.get("search_countries", [])
                
                is_nexa_allowed = False
                if not allowed_countries:
                    is_nexa_allowed = True
                elif any(query.startswith(c) for c in allowed_countries):
                    is_nexa_allowed = True
                    
                if not is_nexa_allowed:
                    if wait_msg_id: delete_message(chat_id, wait_msg_id)
                    send_message(chat_id, render_body_text("❌ number out of stock!"), reply_markup=main_menu(chat_id))
                    del user_states[chat_id]
                    return
                    
                if wait_msg_id: edit_message(chat_id, wait_msg_id, render_body_text("⌛ <i>Processing... Finding Number via API...</i>"))
                
                nexa_found = False
                nexa_keys = bot_settings.get("nexa_keys", [])
                
                t_len = 12
                if query.startswith("880"): t_len = 13
                elif query.startswith("1") and len(query) < 12: t_len = 11
                
                search_range = query + ("X" * (t_len - len(query))) if len(query) < t_len else query
                
                for _ in range(bot_settings.get("num_req", 1)):
                    for api_key in nexa_keys:
                        try:
                            headers = {"X-API-Key": api_key}
                            res = requests.post(f"{NEXA_BASE_URL}/api/v1/numbers/get", json={"range": search_range, "format": "normal"}, headers=headers, timeout=10)
                            data = res.json()
                            if data.get("success") and data.get("number"):
                                num_str = str(data["number"]).replace("+", "")
                                if num_str in fetched_nums:
                                    continue  # duplicate — try next key or next iteration
                                number_id = data.get("number_id")
                                fetched_nums.append(num_str)
                                nexa_assigned_numbers[num_str] = chat_id 
                                nexa_found = True
                                global total_assigned_stats
                                total_assigned_stats += 1
                                if number_id:
                                    threading.Thread(target=poll_otp_with_status, args=(number_id, num_str, chat_id, api_key), daemon=True).start()
                                break
                        except: continue
                        
                if not nexa_found:
                    if wait_msg_id: delete_message(chat_id, wait_msg_id)
                    send_message(chat_id, render_body_text("❌ Number out of stock!"), reply_markup=main_menu(chat_id))
                    del user_states[chat_id]
                    return
                save_db()
            else:
                random.shuffle(found_indices)
                for b_id, idx in found_indices:
                    if len(fetched_nums) >= bot_settings.get("num_req", 1): break
                    n_obj = number_batches[b_id]["numbers"][idx]
                    num_str = n_obj["num"]
                    
                    fetched_nums.append(num_str)
                    
                    n_obj["shares"] += 1
                    n_obj["used_by"].append(chat_id)
                    total_assigned_stats += 1
                    
                    if n_obj["shares"] >= bot_settings.get("num_share", 1):
                        if num_str not in used_numbers_list:
                            used_numbers_list.append(num_str)
                save_db()
                
            if wait_msg_id: edit_message(chat_id, wait_msg_id, render_body_text("✅ Number Found!"))
            kb = []
            flags_db = bot_settings.get("premium_flags", {})
            for num in fetched_nums:
                _, iso = get_flag_and_code(num)
                display_num = f"+{num}" if not num.startswith("+") else num
                
                emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID  # 🚩 default flag from the pack
                for flag_code, flag_data in flags_db.items():
                    if iso == flag_data.get("iso"):
                        if "id" in flag_data: emoji_id = flag_data["id"]
                        break
                kb.append([{"text": f"{display_num}", "icon_custom_emoji_id": emoji_id, "copy_text": {"text": display_num}, "style": "primary"}])
                
            kb.extend(waiting_action_rows(f"c_n_s_{query}", custom_menu="search_number"))
            
            shown, disp_error = show_waiting_screen(chat_id, wait_msg_id, kb, {
                "nums": fetched_nums,
                "service": None,
                "country": None,
                "remove_cc": False,
                "change_callback": f"c_n_s_{query}",
                "custom_menu": "search_number",
            })
            # show_waiting_screen() already stores the active session, so nothing
            # else to clean up here (this is the text/search flow, no callback).
            if not shown:
                send_message(chat_id, render_body_text(f"❌ Telegram error: {disp_error[:120]}"), reply_markup=main_menu(chat_id))
            return
            
        elif state == "wait_for_withdraw_amount" and text:
            msg_id_to_edit = temp_data[chat_id].get("msg_id")
            try:
                amount = float(text.strip())
                bal = temp_data[chat_id]["balance"]
                min_w = bot_settings['min_withdraw']
                
                if amount < min_w:
                    if msg_id_to_edit: edit_message(chat_id, msg_id_to_edit, render_body_text(f"❌ Minimum withdrawal is {min_w} USDT!\n💰 Balance: {bal} USDT\n\n📝 Enter again:"), reply_markup=get_cancel_kb())
                    return
                if amount > bal:
                    if msg_id_to_edit: edit_message(chat_id, msg_id_to_edit, render_body_text(f"❌ You don't have enough balance!\n💰 Balance: {bal} USDT\n\n📝 Enter again:"), reply_markup=get_cancel_kb())
                    return
                    
                temp_data[chat_id]["amount"] = amount
                user_states[chat_id] = "wait_for_withdraw_number"
                if msg_id_to_edit:
                    _method = temp_data[chat_id]["method"]
                    edit_message(chat_id, msg_id_to_edit, render_body_text(f"📝 Enter your {_method} wallet address:"), reply_markup=get_cancel_kb())
            except ValueError:
                if msg_id_to_edit: edit_message(chat_id, msg_id_to_edit, render_body_text("❌ Invalid amount! Please enter a valid number."), reply_markup=get_cancel_kb())
            return

        elif state == "wait_for_2fa_key":
            msg_id_to_edit = temp_data[chat_id].get("msg_id")
            if not msg_id_to_edit:
                send_message(chat_id, render_body_text("❌ Error: Message not found. Try again."))
                del user_states[chat_id]
                return

            try:
                secret = text.strip().replace(" ", "")
                totp = pyotp.TOTP(secret)
                code = totp.now()
                remaining_time = 30 - (int(time.time()) % 30)
                
                success_txt = (
                    f"━━━━━━━━━━━━━━━\n"
                    f"《 🔐 <b>2FA CODE</b> 》\n"
                    f"━━━━━━━━━━━━━━━\n"
                    f"🔐 <b>CODE:</b> <code>{code}</code>\n"
                    f"━━━━━━━━━━━━━━━\n"
                    f"🕓 <b>EXPIRES IN:</b> {remaining_time}s\n"
                    f"━━━━━━━━━━━━━━━"
                )
                kb = [[{"text": f"Click to copy {code}", "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": code}, "style": "success"}],
                      [{"text": "Refresh", "icon_custom_emoji_id": "5420155432272438703", "callback_data": f"ref_2fa_{secret}", "style": "primary"},
                       {"text": "New Code", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "gen_2fa", "style": "danger"}],
                      [{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}]]
                edit_message(chat_id, msg_id_to_edit, render_body_text(success_txt), reply_markup={"inline_keyboard": kb})
            except:
                error_txt = "━━━━━━━━━━━━━━━\n《 ❌ <b>INVALID KEY</b> 》\n━━━━━━━━━━━━━━━\n⚠️ Invalid 2FA secret key! Please check and try again.\n━━━━━━━━━━━━━━━"
                cancel_kb = {"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "cancel_2fa", "style": "danger"}]]}
                if msg_id_to_edit: edit_message(chat_id, msg_id_to_edit, render_body_text(error_txt), reply_markup=cancel_kb)
            return

        elif state == "wait_for_withdraw_number":
            msg_id_to_edit = temp_data[chat_id].get("msg_id")
            
            method = temp_data[chat_id]["method"]
            amount = temp_data[chat_id]["amount"]
            number = text
            req_id = f"W_{str(uuid.uuid4())[:6].upper()}"
            
            first_name = msg.get("from", {}).get("first_name", "User")
            last_name = msg.get("from", {}).get("last_name", "")
            full_name = f"{first_name} {last_name}".strip()
            
            update_balance(chat_id, -amount)
            pending_withdrawals[req_id] = {"user_id": chat_id, "amount": amount, "method": method, "number": number, "full_name": full_name}
            
            # Save withdrawal with FULL details so the admin panel can always
            # show it (even after a restart).
            _save_local_withdrawal(req_id, {
                "user_id": str(chat_id),
                "full_name": full_name,
                "amount": amount,
                "method": method,
                "number": number,
                "status": "pending",
                "created_at": time.time(),
                "total_otps": _get_local_user(chat_id).get("total_otps", 0),
            })
                
            admin_msg = f"🎙 <b>NEW WITHDRAWAL REQUEST</b>\n\n👤 <b>USER:</b> <a href='tg://user?id={chat_id}'>{full_name}</a>\n💳 <b>WITHDRAWAL:</b> {amount} USDT\n🍏 <b>NUMBER:</b> <code>{number}</code>\n🏦 <b>METHOD:</b> {method}\n\n🧾 <b>REQ ID:</b> {req_id}\n👨‍⚖️ <b>PROCESSED BY ADMIN</b>"
            wd_kb = {"inline_keyboard": [[{"text": "APPROVE", "icon_custom_emoji_id": "5352694861990501856", "callback_data": f"wapp_{req_id}", "style": "success"}, {"text": "REJECT", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"wrej_{req_id}", "style": "danger"}]]}
            rendered_admin_msg = render_body_text(admin_msg)
            # Track all sent message IDs for later editing on approve/reject
            sent_messages = []  # list of {"chat_id": ..., "message_id": ...}
            # Send to withdrawal group
            if bot_settings.get("w_group"):
                try:
                    res = send_message(bot_settings["w_group"], rendered_admin_msg, reply_markup=wd_kb)
                    if res.get("ok") and res.get("result"):
                        sent_messages.append({"chat_id": bot_settings["w_group"], "message_id": res["result"]["message_id"]})
                    else:
                        for adm_id in bot_settings.get("admins", []):
                            try: send_message(adm_id, render_body_text(f"⚠️ W.GROUP ({bot_settings['w_group']}) mein message send fail hua! Group ID check karein."))
                            except: pass
                except: pass
            # Send DM to each admin
            for adm_id in bot_settings.get("admins", []):
                if adm_id != chat_id:
                    try:
                        res = send_message(adm_id, rendered_admin_msg, reply_markup=wd_kb)
                        if res.get("ok") and res.get("result"):
                            sent_messages.append({"chat_id": adm_id, "message_id": res["result"]["message_id"]})
                    except: pass
            pending_withdrawals[req_id]["sent_messages"] = sent_messages
            
            kb = {"inline_keyboard": [[{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}]]}
            success_text = f"{PEM['ok']} Your withdrawal request has been submitted!\n\n🧾 <b>Req ID:</b> {req_id}\n💰 <b>Amount:</b> {amount} USDT\n🏦 <b>Method:</b> {method}\n📱 <b>Number:</b> <code>{number}</code>"
            
            if msg_id_to_edit:
                edit_message(chat_id, msg_id_to_edit, render_body_text(success_text), reply_markup=kb)
            else:
                send_message(chat_id, render_body_text(success_text), reply_markup=kb)
                
            del user_states[chat_id]
            del temp_data[chat_id]
            return

    # --- Regular Commands ---
    if text.startswith("/start"):
        get_user(chat_id)
        
        # --- PROCESS PENDING REFERRAL ---
        u_data = _get_local_user(chat_id)
        if u_data.get("referred_by") and not u_data.get("ref_paid"):
            inviter = u_data["referred_by"]
            _update_local_user(chat_id, {"ref_paid": True})
            reward = bot_settings.get("refer_reward", 0.0016)
            update_balance(inviter, reward)
            _increment_local_user(inviter, "total_refers", 1)
            ref_msg = (
                f"{PEM['gift']} <b>New Referral !</b>\n"
                f"------------------\n"
                f"🔥 <b>You Received {reward} USDT</b>\n"
                f"------------------\n"
                f"{PEM['user']} <b>From User ID:</b> <code>{chat_id}</code>"
            )
            send_message(inviter, render_body_text(ref_msg))

        c_msg = bot_settings["custom_messages"].get("start", {})
        txt = render_body_text(c_msg.get("text", f"{PEM['hi']} Welcome!"))
        kb = []
        for b in c_msg.get("buttons", []):
            b_copy = b.copy()
            if "style" not in b_copy: b_copy["style"] = "primary"
            kb.append([b_copy])
        
        if kb:
            send_message(chat_id, txt, reply_markup={"inline_keyboard": kb})
            send_message(chat_id, render_body_text(f"{PEM['gear']} Navigation Menu:"), reply_markup=main_menu(chat_id))
        else:
            send_message(chat_id, txt, reply_markup=main_menu(chat_id))
            
    elif menu_action == "traffic":
        txt, markup = build_traffic_ui()
        send_message(chat_id, txt, reply_markup=markup)
        
    elif menu_action == "refer":
        u_data = get_user(chat_id)
        ref_link = f"https://t.me/{BOT_USERNAME}?start={chat_id}"
        c_msg = bot_settings["custom_messages"].get("refer", {})
        
        raw_txt = c_msg.get("text", f"{PEM['gift']} Refer").replace("{ref_link}", ref_link).replace("{total_ref}", str(u_data.get('total_refers', 0))).replace("{ref_reward}", str(bot_settings['refer_reward']))
        txt = render_body_text(raw_txt)
        
        kb = [[sys_button("copy_link", copy_text={"text": ref_link})]]
        for b in c_msg.get("buttons", []): 
            b_copy = b.copy()
            if "style" not in b_copy: b_copy["style"] = "primary"
            kb.append([b_copy])
        kb.append([sys_button("close", callback_data="close_msg")])
        
        send_message(chat_id, txt, reply_markup={"inline_keyboard": kb})

    elif menu_action == "withdrawal":
        if not bot_settings["withdraw_on"]:
            send_message(chat_id, render_body_text(f"{PEM['no']} Withdrawals are currently disabled."))
            return
        
        u_data = get_user(chat_id)
        bal = u_data.get('balance', 0.0)
        
        c_msg = bot_settings["custom_messages"].get("withdrawal", {})
        raw_txt = c_msg.get("text", "Withdrawal").replace("{bal}", str(bal)).replace("{total_otp}", str(u_data.get('total_otps', 0))).replace("{total_ref}", str(u_data.get('total_refers', 0))).replace("{min_w}", str(bot_settings['min_withdraw']))
        txt = render_body_text(raw_txt)
        
        kb = []
        for m in bot_settings["w_methods"]:
            kb.append([{"text": m.strip(), "icon_custom_emoji_id": "5190899075968441286", "callback_data": f"sel_wm_{m.strip()}", "style": "primary"}])
        
        for b in c_msg.get("buttons", []): 
            b_copy = b.copy()
            if "style" not in b_copy: b_copy["style"] = "primary"
            kb.append([b_copy])
        kb.append([sys_button("cancel", callback_data="close_msg")])
        send_message(chat_id, txt, reply_markup={"inline_keyboard": kb})

    elif menu_action == "admin_panel" and is_admin(chat_id):
        send_message(chat_id, get_admin_text(), reply_markup=admin_panel_keyboard())

    elif menu_action == "get_number":
        if not get_available_services():
            send_message(chat_id, render_body_text(f"{PEM['no']} No numbers or services available!"))
        else:
            txt, markup = get_service_selection_ui()
            send_message(chat_id, txt, reply_markup=markup)

    elif menu_action == "search_number":
        user_states[chat_id] = "wait_for_search"
        c_msg = bot_settings["custom_messages"].get("search_number", {})
        txt = render_body_text(c_msg.get("text", f"{PEM['num']} Search Number"))
        kb = [[sys_button("cancel", callback_data="cancel_state")]]
        for b in c_msg.get("buttons", []): 
            b_copy = b.copy()
            if "style" not in b_copy: b_copy["style"] = "primary"
            kb.append([b_copy])
        send_message(chat_id, txt, reply_markup={"inline_keyboard": kb})

    elif menu_action == "2fa":
        txt = "━━━━━━━━━━━━━━━\n《 🔐 <b>2FA ONLINE</b> 》\n━━━━━━━━━━━━━━━\n<i>Generate your 2FA security code instantly using your secret key.</i>\n━━━━━━━━━━━━━━━"
        kb = [[sys_button("gen_2fa", callback_data="gen_2fa")],
              [sys_button("close", callback_data="close_msg")]]
        send_message(chat_id, render_body_text(txt), reply_markup={"inline_keyboard": kb})

    elif menu_action == "support":
        c_msg = bot_settings["custom_messages"].get("support", {})
        txt = render_body_text(c_msg.get("text", f"{PEM['msg']} Support"))
        if not txt.strip(): txt = render_body_text(f"{PEM['msg']} Support")
        kb = []
        for b in c_msg.get("buttons", []):
            b_copy = b.copy()
            if "style" not in b_copy: b_copy["style"] = "primary"
            kb.append([b_copy])
            
        sup_link = bot_settings.get("support_link", "")
        if sup_link:
            kb.insert(0, [sys_button("contact_support", url=sup_link)])
            
        kb.append([sys_button("close", callback_data="close_msg")])
        send_message(chat_id, txt, reply_markup={"inline_keyboard": kb} if kb else None)

def mark_message_expired(chat_id, prev_msg_id):
    """Turn an old Waiting screen into the 'Number Expired' screen."""
    if not prev_msg_id:
        return
    kb = {"inline_keyboard": [[{"text": "Number Expired", "icon_custom_emoji_id": "5336997731481193790", "callback_data": "ignore", "style": "danger"}]]}
    try:
        edit_message(chat_id, prev_msg_id, waiting_expired_text(), reply_markup=kb)
    except Exception:
        pass


def _expire_old_screen(chat_id, previous_msg_id):
    """Mark the old waiting screen as expired (only when it is a different message)."""
    if not previous_msg_id:
        return
    current = (user_active_sessions.get(chat_id) or {}).get("msg_id")
    if current and current == previous_msg_id:
        return
    mark_message_expired(chat_id, previous_msg_id)


def expire_previous_number(chat_id, mark_expired=True):
    """Clear the previous session.

    mark_expired=False keeps the old message untouched: it must stay showing its
    numbers until the NEW screen is really displayed. Otherwise the user is left
    looking at a Waiting screen with no number.
    """
    prev_msg_id = None
    if chat_id in user_active_sessions:
        prev_data = user_active_sessions[chat_id]
        prev_msg_id = prev_data.get("msg_id")
        nums = prev_data.get("nums", []) or []
        for num in nums:
            clean = str(num).replace("+", "").strip()
            if num in nexa_assigned_numbers:
                del nexa_assigned_numbers[num]
            if clean in nexa_assigned_numbers:
                del nexa_assigned_numbers[clean]
            if str(num) in voltx_assigned_numbers:
                del voltx_assigned_numbers[str(num)]
            if clean in voltx_assigned_numbers:
                del voltx_assigned_numbers[clean]
        save_db()
        if mark_expired:
            mark_message_expired(chat_id, prev_msg_id)
        del user_active_sessions[chat_id]
    return prev_msg_id

# ==========================================
# Callback Query Handler
# ==========================================
def handle_callback(call):
    global total_assigned_stats
    chat_id = call["message"]["chat"]["id"]
    chat_type = call["message"]["chat"].get("type", "private")
    data = call.get("data", "")

    # 🌟 Button Loading Fix: Give Response to Telegram immediately when button pressed, so button does not get stuck!
    if not data.startswith("test_p_conn_") and not data.startswith("c_n_") and not data.startswith("g_c_") and not data.startswith("otp_check_p_"):
        try: threading.Thread(target=answer_callback, args=(call["id"],), daemon=True).start()
        except: pass

    if data.startswith(("mb_", "mi_", "sys_", "wsms_", "wbtgl_", "ostyle_", "fwstyle", "fwset__", "otp_check", "otp_test_", "wd_", "wdq_", "flag_pack", "backup_")) and not is_admin(chat_id):
        answer_callback(call["id"], "❌ Admin only!", show_alert=True)
        return

    if chat_type != "private" and not (data.startswith("wapp_") or data.startswith("wrej_")):
        return

    msg_id = call["message"]["message_id"]

    if chat_type == "private":
        if is_user_banned(chat_id):
            answer_callback(call["id"], "🚫 You are banned from using this bot!", show_alert=True)
            return

        if not check_force_join(chat_id) and data != "check_fj":
            send_force_join_msg(chat_id)
            return

    if data == "check_fj":
        if check_force_join(chat_id):
            delete_message(chat_id, msg_id)
            send_message(chat_id, render_body_text(f"{PEM['ok']} Thanks for joining! You can now use the bot."), reply_markup=main_menu(chat_id))
            
            # --- PROCESS PENDING REFERRAL ---
            u_data = _get_local_user(chat_id)
            if u_data.get("referred_by") and not u_data.get("ref_paid"):
                inviter = u_data["referred_by"]
                _update_local_user(chat_id, {"ref_paid": True})
                reward = bot_settings.get("refer_reward", 0.0016)
                update_balance(inviter, reward)
                _increment_local_user(inviter, "total_refers", 1)
                ref_msg = (
                    f"{PEM['gift']} <b>New Referral !</b>\n"
                    f"------------------\n"
                    f"🔥 <b>You Received {reward} USDT</b>\n"
                    f"------------------\n"
                    f"{PEM['user']} <b>From User ID:</b> <code>{chat_id}</code>"
                )
                send_message(inviter, render_body_text(ref_msg))
        else:
            answer_callback(call["id"], "❌ You haven't joined all channels yet!", show_alert=True)
        return

    if data == "close_msg":
        delete_message(chat_id, msg_id)
        
    elif data == "cancel_state":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        delete_message(chat_id, msg_id)

    elif data == "cancel_2fa":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        txt = "━━━━━━━━━━━━━━━\n《 🔐 <b>2FA ONLINE</b> 》\n━━━━━━━━━━━━━━━\n<i>Generate your 2FA security code instantly using your secret key.</i>\n━━━━━━━━━━━━━━━"
        kb = [[sys_button("gen_2fa", callback_data="gen_2fa")],
              [sys_button("close", callback_data="close_msg")]]
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup={"inline_keyboard": kb})
        answer_callback(call["id"])

    elif data == "gen_2fa":
        user_states[chat_id] = "wait_for_2fa_key"
        temp_data[chat_id] = {"msg_id": msg_id}
        txt = "━━━━━━━━━━━━━━━\n《 🔑 <b>ENTER 2FA KEY</b> 》\n━━━━━━━━━━━━━━━\n📝 <b>SEND YOUR 2FA SECRET KEY</b>\n━━━━━━━━━━━━━━━"
        kb = {"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "cancel_2fa", "style": "danger"}]]}
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup=kb)
        answer_callback(call["id"])

    elif data.startswith("ref_2fa_"):
        secret = data.replace("ref_2fa_", "")
        try:
            totp = pyotp.TOTP(secret)
            code = totp.now()
            remaining_time = 30 - (int(time.time()) % 30)
            
            success_txt = (
                f"━━━━━━━━━━━━━━━\n"
                f"《 🔐 <b>2FA CODE</b> 》\n"
                f"━━━━━━━━━━━━━━━\n"
                f"🔐 <b>CODE:</b> <code>{code}</code>\n"
                f"━━━━━━━━━━━━━━━\n"
                f"🕓 <b>EXPIRES IN:</b> {remaining_time}s\n"
                f"━━━━━━━━━━━━━━━"
            )
            kb = [[{"text": f"Click to copy {code}", "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": code}, "style": "success"}],
                  [{"text": "Refresh", "icon_custom_emoji_id": "5420155432272438703", "callback_data": f"ref_2fa_{secret}", "style": "primary"},
                   {"text": "New Code", "icon_custom_emoji_id": "5352552689983067014", "callback_data": "gen_2fa", "style": "danger"}],
                  [{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}]]
            
            edit_message(chat_id, msg_id, render_body_text(success_txt), reply_markup={"inline_keyboard": kb})
        except:
            answer_callback(call["id"], "❌ Error refreshing code!", show_alert=True)

    elif data == "cancel_abhi_edit":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, render_body_text("🕹 <b>SHAHADOT X DEV CONTROL PANEL</b>"), reply_markup=abhi_control_keyboard())
        
    elif data == "dummy_alert":
        answer_callback(call["id"], "This feature will be added later!", show_alert=True)
        
    elif data == "refresh_traffic":
        txt, markup = build_traffic_ui()
        edit_message(chat_id, msg_id, txt, reply_markup=markup)
        answer_callback(call["id"], "✅ Traffic Refreshed!", show_alert=False)

    elif data.startswith("exp_rng_"):
        srv_query = data.replace("exp_rng_", "")
        
        country_stats = {}
        current_time = time.time()
        for t in recent_traffic:
            if current_time - t.get("time", 0) <= 3600:
                if t.get("service", "").startswith(srv_query):
                    iso = t.get("iso", "XX")
                    flag = t.get("flag", "🌍")
                    if iso not in country_stats:
                        country_stats[iso] = {"count": 0, "flag": flag}
                    country_stats[iso]["count"] += 1
        
        if not country_stats:
            answer_callback(call["id"], "❌ No recent traffic found for this service!", show_alert=True)
            return
            
        kb = []
        for iso, c_data in sorted(country_stats.items(), key=lambda x: x[1]["count"], reverse=True):
            count = c_data["count"]
            c_name = iso
            emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID
            for code, fdata in bot_settings.get("premium_flags", {}).items():
                if fdata.get("iso") == iso:
                    c_name = fdata.get("name", iso)
                    if "id" in fdata: emoji_id = fdata["id"]
                    break
            
            btn_text = f"{c_name} ({iso}) - {count} OTP"
            kb.append([{"text": btn_text, "icon_custom_emoji_id": emoji_id, "callback_data": f"exp_c_{srv_query}_{iso}", "style": "primary"}])
            
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "refresh_traffic", "style": "danger"}])
        
        app_full_name, prem_app_html = get_service_info_html(srv_query)
        edit_message(chat_id, msg_id, render_body_text(f"📊 <b>Explore Service: {prem_app_html} {app_full_name}</b>\n\nSelect a country to view available ranges:"), reply_markup={"inline_keyboard": kb})
        answer_callback(call["id"])

    elif data.startswith("exp_c_"):
        parts = data.split("_")
        srv_query = parts[2]
        iso_query = parts[3]
        
        nums = []
        current_time = time.time()
        for t in recent_traffic:
            if current_time - t.get("time", 0) <= 3600:
                if t.get("service", "").startswith(srv_query) and t.get("iso") == iso_query:
                    num = t.get("number", "").replace("+", "").strip()
                    if num: nums.append(num)
        
        if not nums:
            answer_callback(call["id"], "❌ No recent numbers found for this country!", show_alert=True)
            return
            
        # Only take range from Nexa Services (not Search Countries, as those only have country codes)
        known_ranges = set()
        for s_name, c_dict in bot_settings.get("nexa_services", {}).items():
            for c_name, r_list in c_dict.items():
                for r in r_list:
                    known_ranges.add(r)
                    
        sorted_known = sorted(list(known_ranges), key=len, reverse=True)
        
        r_counts = Counter()
        for num in nums:
            matched = False
            for r in sorted_known:
                if num.startswith(r):
                    r_counts[r] += 1
                    matched = True
                    break
            if not matched:
                if len(num) >= 7:
                    r_counts[num[:7]] += 1
                else:
                    r_counts[num] += 1
                    
        r_list = r_counts.most_common(12)
        
        kb = []
        for r, count in r_list:
            # One button per line
            kb.append([{"text": f"{r} ({count})", "icon_custom_emoji_id": "5352862640592949843", "copy_text": {"text": r}, "style": "primary"}])
            
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"exp_rng_{srv_query}", "style": "danger"}])
        
        app_full_name, prem_app_html = get_service_info_html(srv_query)
        prem_flag_html = get_flag_info_html(iso_query)
        
        edit_message(chat_id, msg_id, render_body_text(f"📊 <b>Ranges for {prem_app_html} {app_full_name} - {prem_flag_html} {iso_query}</b>\n\nClick on any range to copy it."), reply_markup={"inline_keyboard": kb})
        answer_callback(call["id"])

    # --- User Management Flows Integration ---
    elif data == "user_management":
        edit_message(chat_id, msg_id, get_user_management_text(), reply_markup=user_management_keyboard())

    elif data == "um_manage_balance":
        user_states[chat_id] = "wait_for_um_bal_uid"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the User ID to Manage Balance:"), reply_markup=get_cancel_kb())
        
    elif data == "um_ban_unban":
        user_states[chat_id] = "wait_for_um_ban_uid"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the User ID to Ban or Unban:"), reply_markup=get_cancel_kb())

    elif data == "um_user_profile":
        user_states[chat_id] = "wait_for_um_prof_uid"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the User ID to View Profile:"), reply_markup=get_cancel_kb())

    # --- Menu Design Integration ---
    # --- Withdrawal queue (one by one) ---
    elif data == "wd_menu":
        edit_message(chat_id, msg_id, wd_menu_text(), reply_markup=wd_menu_keyboard())

    elif data in ("wd_pending", "wdq_list"):
        ids = pending_withdrawal_ids()
        if not ids:
            edit_message(chat_id, msg_id, wd_menu_text(notice=f"{PEM['ok']} <b>No pending withdrawal!</b>"), reply_markup=wd_menu_keyboard())
        else:
            edit_message(chat_id, msg_id, wd_card_text(ids[0]), reply_markup=wd_card_keyboard(ids[0]))

    elif data.startswith("wdq_show_") or data.startswith("wdq_refresh_"):
        req_id = data.split("_", 2)[2]
        edit_message(chat_id, msg_id, wd_card_text(req_id), reply_markup=wd_card_keyboard(req_id))

    elif data.startswith("wdq_next_"):
        req_id = data.split("_", 2)[2]
        next_id = wd_next_pending_id(req_id)
        if not next_id:
            edit_message(chat_id, msg_id, wd_menu_text(notice=f"{PEM['ok']} <b>Queue finished — nothing pending.</b>"), reply_markup=wd_menu_keyboard())
        else:
            edit_message(chat_id, msg_id, wd_card_text(next_id), reply_markup=wd_card_keyboard(next_id))

    elif data.startswith("wdq_pay_"):
        req_id = data.split("_", 2)[2]
        ok, message, next_id = process_withdrawal_action(req_id, "PAY", chat_id)
        answer_callback(call["id"], message.replace("<b>", "").replace("</b>", ""), show_alert=True)
        if next_id:
            edit_message(chat_id, msg_id, wd_card_text(next_id, notice=message),
                         reply_markup=wd_card_keyboard(next_id))
        else:
            edit_message(chat_id, msg_id, wd_menu_text(notice=message + "\n🕘 <i>Queue empty now.</i>"), reply_markup=wd_menu_keyboard())

    elif data.startswith("wdq_rej_"):
        req_id = data.split("_", 2)[2]
        pending = _wd_pending_map().get(req_id)
        if not pending:
            answer_callback(call["id"], "❌ Already processed", show_alert=True)
            return
        confirm_text = render_body_text(
            f"{PEM['warn']} <b>REJECT THIS REQUEST?</b>\n" + "\u2501" * 16 +
            f"\n👤 {_wd_user_line(req_id, pending)}\n"
            f"💳 <b>{pending.get('amount', 0)} USDT</b> · {html.escape(str(pending.get('method', '-')))}\n"
            f"📱 <code>{html.escape(str(pending.get('number', '-')))}</code>\n\n"
            "<i>The amount will be refunded to the user's balance.</i>"
        )
        edit_message(chat_id, msg_id, confirm_text, reply_markup={"inline_keyboard": [
            [{"text": "✅ Yes, Reject & Refund", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"wdq_rejc_{req_id}", "style": "danger"}],
            [{"text": "↩️ Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"wdq_show_{req_id}", "style": "primary"}],
        ]})

    elif data.startswith("wdq_rejc_"):
        req_id = data.split("_", 2)[2]
        ok, message, next_id = process_withdrawal_action(req_id, "REJECT", chat_id)
        answer_callback(call["id"], message.replace("<b>", "").replace("</b>", ""), show_alert=True)
        if next_id:
            edit_message(chat_id, msg_id, wd_card_text(next_id, notice=message),
                         reply_markup=wd_card_keyboard(next_id))
        else:
            edit_message(chat_id, msg_id, wd_menu_text(notice=message + "\n🕘 <i>Queue empty now.</i>"), reply_markup=wd_menu_keyboard())

    elif data in ("wd_hist_a", "wd_hist_r", "wd_hist"):
        status = "rejected" if data.endswith("_r") else "approved"
        edit_message(chat_id, msg_id, wd_history_text(status), reply_markup=wd_history_keyboard())

    # --- SMS / OTP style manager ---
    elif data == "ostyle_menu":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, sms_style_page_text(), reply_markup=sms_style_page_keyboard())

    elif data in ("ostyle_pick_g", "ostyle_pick_u"):
        for_group = data.endswith("_g")
        edit_message(chat_id, msg_id, sms_style_picker_text(for_group), reply_markup=sms_style_picker_keyboard(for_group))

    elif data.startswith("ostyle_set_"):
        kind, _, style_id = data[len("ostyle_set_"):].partition("__")
        for_group = kind == "g"
        key = "otp_style_group" if for_group else "otp_style_user"
        if style_id == RANDOM_OTP_STYLE_ID or style_id in {s["id"] for s in all_otp_styles()}:
            bot_settings[key] = style_id
            reset_random_style_history("group" if for_group else "user")
            save_db()
            _set_msg = ("🎲 All / Random style set! প্রতি SMS-এ এলোমেলো নতুন স্টাইল যাবে।"
                        if style_id == RANDOM_OTP_STYLE_ID else
                        f"✅ {('Group' if for_group else 'User')} style set!")
            answer_callback(call["id"], _set_msg, show_alert=True)
            edit_message(chat_id, msg_id, sms_style_page_text(), reply_markup=sms_style_page_keyboard())
        else:
            answer_callback(call["id"], "❌ Style not found", show_alert=True)

    elif data.startswith("ostyle_prev_"):
        kind, _, style_id = data[len("ostyle_prev_"):].partition("__")
        for_group = kind == "g"
        answer_callback(call["id"], "👀 Preview sent")
        sms_style_preview_send(chat_id, for_group=for_group, style_id=style_id)

    elif data == "ostyle_custom":
        edit_message(chat_id, msg_id, sms_custom_style_text(), reply_markup=sms_custom_style_keyboard())

    elif data == "ostyle_add":
        user_states[chat_id] = "wait_for_style_name"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text(
            f"➕ <b>NEW CUSTOM STYLE</b>\n\nStep 1️⃣ — Send a <b>name</b> for this style (e.g. <code>Blue Box</code>)."
        ), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "ostyle_custom", "style": "danger"}]]})

    elif data.startswith("ostyle_edit__"):
        style_id = data[len("ostyle_edit__"):]
        target = next((s for s in get_custom_otp_styles() if str(s.get("id")) == style_id), None)
        if not target:
            answer_callback(call["id"], "❌ Custom style not found", show_alert=True)
            return
        user_states[chat_id] = "wait_for_style_template"
        temp_data[chat_id] = {"msg_id": msg_id, "style_id": style_id}
        edit_message(chat_id, msg_id, render_body_text(
            f"✏️ <b>EDIT STYLE: {html.escape(str(target.get('name')))}</b>\n\n"
            f"Send the new template.\n\nCurrent:\n<code>{html.escape(str(target.get('template')))}</code>\n\n"
            f"🔤 Placeholders: <code>{html.escape(OTP_STYLE_PLACEHOLDERS)}</code>"
        ), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "ostyle_custom", "style": "danger"}]]})

    elif data.startswith("ostyle_mask__"):
        style_id = data[len("ostyle_mask__"):]
        for style in get_custom_otp_styles():
            if str(style.get("id")) == style_id:
                style["mask"] = not bool(style.get("mask", True))
                save_db()
                answer_callback(call["id"], "✅ " + ("Number masked" if style["mask"] else "Full number shown"))
                break
        edit_message(chat_id, msg_id, sms_custom_style_text(), reply_markup=sms_custom_style_keyboard())

    elif data.startswith("ostyle_del__"):
        style_id = data[len("ostyle_del__"):]
        before = len(get_custom_otp_styles())
        bot_settings["otp_styles"] = [s for s in get_custom_otp_styles() if str(s.get("id")) != style_id]
        for key in ("otp_style_group", "otp_style_user"):
            if bot_settings.get(key) == style_id:
                bot_settings[key] = "border"
        for group in bot_settings.get("fw_groups", []):
            if str(group.get("style")) == style_id:
                group["style"] = "auto"
        save_db()
        answer_callback(call["id"], "🗑 Deleted" if len(get_custom_otp_styles()) < before else "❌ Not found", show_alert=True)
        edit_message(chat_id, msg_id, sms_custom_style_text(), reply_markup=sms_custom_style_keyboard())

    elif data == "ostyle_reset":
        bot_settings["otp_style_group"] = "border"
        bot_settings["otp_style_user"] = "border"
        for group in bot_settings.get("fw_groups", []):
            group["style"] = "auto"
        save_db()
        answer_callback(call["id"], "♻️ Styles reset to default", show_alert=True)
        edit_message(chat_id, msg_id, sms_style_page_text(), reply_markup=sms_style_page_keyboard())

    elif data.startswith("fwstyle__"):
        idx = int(data[len("fwstyle__"):])
        edit_message(chat_id, msg_id, otp_group_style_text(idx), reply_markup=otp_group_style_keyboard(idx))

    elif data.startswith("fwset__"):
        payload = data[len("fwset__"):]
        idx_str, _, style_id = payload.partition("__")
        idx = int(idx_str)
        groups = bot_settings.get("fw_groups", [])
        if 0 <= idx < len(groups):
            if style_id not in ("auto", RANDOM_OTP_STYLE_ID) and style_id not in {s["id"] for s in all_otp_styles()}:
                answer_callback(call["id"], "❌ Style not found", show_alert=True)
                return
            groups[idx]["style"] = "auto" if style_id == "auto" else style_id
            save_db()
            answer_callback(call["id"], "🎲 Random style saved for this group" if style_id == RANDOM_OTP_STYLE_ID
                            else "✅ Group style saved", show_alert=True)
            edit_message(chat_id, msg_id, otp_group_style_text(idx), reply_markup=otp_group_style_keyboard(idx))

    # --- Waiting SMS designer ---
    elif data == "wsms_menu":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, wsms_page_text(), reply_markup=wsms_page_keyboard())

    elif data == "wsms_edit":
        user_states[chat_id] = "wait_for_wsms_text"
        temp_data[chat_id] = {"msg_id": msg_id, "wsms_key": "waiting"}
        edit_message(chat_id, msg_id, render_body_text(
            f"{PEM['gear']} <b>EDIT WAITING TEXT</b>\n" + "\u2501" * 16 +
            f"\nSend the new Waiting message.\n\n"
            f"🔤 Placeholders: <code>{WSMS_PLACEHOLDERS}</code>\n"
            f"😀 Premium emoji + <b>HTML</b> supported.\n\n"
            f"<i>Example:</i>\n<code>╔═══════════════╗\n║ 💬 Waiting For SMS...\n╚═══════════════╝</code>"
        ), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wsms_menu", "style": "danger"}]]})

    elif data == "wsms_exp":
        user_states[chat_id] = "wait_for_wsms_text"
        temp_data[chat_id] = {"msg_id": msg_id, "wsms_key": "waiting_expired"}
        edit_message(chat_id, msg_id, render_body_text(
            f"{PEM['gear']} <b>EDIT EXPIRED TEXT</b>\n" + "\u2501" * 16 +
            f"\nSend the new 'Number Expired' message.\n\n"
            f"<i>Example:</i>\n<code>╔═══════════════╗\n║ 💬 Number Expired\n╚═══════════════╝</code>"
        ), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wsms_menu", "style": "danger"}]]})

    elif data == "wsms_hide":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, waiting_buttons_text(), reply_markup=waiting_buttons_keyboard())

    elif data.startswith("wbtgl_"):
        key = data.split("wbtgl_", 1)[1]
        if key == "all":
            set_waiting_action("all", True)
            answer_callback(call["id"], "✅ All action buttons are visible again.")
        elif key in DEFAULT_WAITING_ACTIONS:
            new_value = not waiting_action_enabled(key)
            set_waiting_action(key, new_value)
            answer_callback(
                call["id"],
                ("✅ Shown: " if new_value else "🚫 Hidden: ") + waiting_action_label(key),
                show_alert=False,
            )
        else:
            answer_callback(call["id"], "❌ Unknown button.", show_alert=True)
            return
        edit_message(chat_id, msg_id, waiting_buttons_text(), reply_markup=waiting_buttons_keyboard())

    elif data in ("wsms_btns", "wsms_btns_exp"):
        expired = data.endswith("_exp")
        edit_message(chat_id, msg_id, wsms_buttons_text(expired), reply_markup=wsms_buttons_keyboard(expired))

    elif data in ("wsms_addbtn", "wsms_addbtn_exp"):
        expired = data.endswith("_exp")
        user_states[chat_id] = "wait_for_menu_btn"
        temp_data[chat_id] = {"msg_id": msg_id, "menu_key": "waiting_expired" if expired else "waiting"}
        edit_message(chat_id, msg_id, render_body_text(
            f"➕ <b>Add Button</b>\n\nSend in this format:\n"
            f"<code>Button Text - https://link.com</code>\n\n<i>(Premium emoji supported in the text)</i>"
        ), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wsms_btns_exp" if expired else "wsms_btns", "style": "danger"}]]})

    elif data.startswith("wsms_delbtn_"):
        parts = data.split("_")
        flag = parts[-2]
        idx = int(parts[-1])
        key = "waiting_expired" if flag == "e" else "waiting"
        entry = _wsms_entry(key)
        buttons = entry.get("buttons", [])
        if 0 <= idx < len(buttons):
            removed = buttons.pop(idx)
            save_db()
            answer_callback(call["id"], f"🗑 Removed: {removed.get('text', 'button')}", show_alert=True)
        edit_message(chat_id, msg_id, wsms_buttons_text(key == "waiting_expired"), reply_markup=wsms_buttons_keyboard(key == "waiting_expired"))

    elif data == "wsms_preview":
        answer_callback(call["id"], "👀 Preview sent")
        wsms_preview_send(chat_id)

    elif data == "wsms_reset":
        bot_settings["custom_messages"]["waiting"] = deepcopy(DEFAULT_CUSTOM_MESSAGES["waiting"])
        bot_settings["custom_messages"]["waiting_expired"] = deepcopy(DEFAULT_CUSTOM_MESSAGES["waiting_expired"])
        save_db()
        answer_callback(call["id"], "♻️ Waiting/Expired messages reset!", show_alert=True)
        edit_message(chat_id, msg_id, wsms_page_text(), reply_markup=wsms_page_keyboard())

    # --- Main Menu Button Manager ---
    elif data == "mb_menu":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, menu_button_manager_text(), reply_markup=menu_button_manager_keyboard())

    elif data == "mb_preview":
        answer_callback(call["id"], "👀 Preview sent below")
        send_message(chat_id, render_body_text(f"{PEM['gear']} <b>Preview — exactly what users see:</b>"), reply_markup=main_menu(chat_id))

    elif data == "mb_perrow":
        bot_settings["menu_buttons_per_row"] = 1 if get_menu_per_row() == 2 else 2
        save_db()
        edit_message(chat_id, msg_id, menu_button_manager_text(), reply_markup=menu_button_manager_keyboard())

    elif data == "mb_reset":
        bot_settings["menu_buttons"] = deepcopy(DEFAULT_MENU_BUTTONS)
        bot_settings["menu_buttons_per_row"] = 2
        save_db()
        answer_callback(call["id"], "✅ Menu buttons reset to defaults!", show_alert=True)
        edit_message(chat_id, msg_id, menu_button_manager_text(), reply_markup=menu_button_manager_keyboard())

    elif data == "mb_add":
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>ADD BUTTON</b>\n\nChoose which action this new button will open:"), reply_markup=menu_action_picker_keyboard())

    elif data.startswith("mb_new_"):
        action = data.replace("mb_new_", "")
        if action not in MENU_ACTION_LABELS:
            answer_callback(call["id"], "❌ Unknown action", show_alert=True)
            return
        buttons = get_menu_buttons()
        buttons.append({
            "label": MENU_ACTION_LABELS[action],
            "emoji": DEFAULT_BUTTON_EMOJI.get(action, ""),
            "style": "primary",
            "action": action,
            "enabled": True,
            "admin_only": action == "admin_panel",
        })
        bot_settings["menu_buttons"] = buttons
        save_db()
        answer_callback(call["id"], "✅ Button added! Tap it to rename.", show_alert=True)
        edit_message(chat_id, msg_id, menu_button_manager_text(), reply_markup=menu_button_manager_keyboard())

    elif data.startswith("mb_btn_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(get_menu_buttons()):
            edit_message(chat_id, msg_id, menu_button_detail_text(idx), reply_markup=menu_button_detail_keyboard(idx))

    elif data.startswith("mb_ren_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(get_menu_buttons()):
            user_states[chat_id] = "wait_for_btn_label"
            temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "menu", "idx": idx}}
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>RENAME BUTTON</b>\n\nSend the new button name (max 64 characters):"), reply_markup=_button_cancel_row(f"mb_btn_{idx}"))

    elif data.startswith("mb_emoclr_"):
        idx = int(data.split("_")[2])
        buttons = get_menu_buttons()
        if 0 <= idx < len(buttons):
            buttons[idx].pop("emoji", None)
            save_db()
            answer_callback(call["id"], "🗑 Emoji removed")
            edit_message(chat_id, msg_id, menu_button_detail_text(idx), reply_markup=menu_button_detail_keyboard(idx))

    elif data.startswith("mb_emo_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(get_menu_buttons()):
            user_states[chat_id] = "wait_for_btn_emoji"
            temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "menu", "idx": idx}}
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>SET EMOJI</b>\n\nSend a premium emoji as a message, or paste its numeric emoji ID."), reply_markup=_button_cancel_row(f"mb_btn_{idx}"))

    elif data.startswith("mb_style_"):
        idx = int(data.split("_")[2])
        buttons = get_menu_buttons()
        if 0 <= idx < len(buttons):
            order = ["primary", "success", "danger"]
            current = buttons[idx].get("style", "primary")
            buttons[idx]["style"] = order[(order.index(current) + 1) % len(order)] if current in order else "primary"
            save_db()
            edit_message(chat_id, msg_id, menu_button_detail_text(idx), reply_markup=menu_button_detail_keyboard(idx))

    elif data.startswith("mb_tog_"):
        idx = int(data.split("_")[2])
        buttons = get_menu_buttons()
        if 0 <= idx < len(buttons):
            buttons[idx]["enabled"] = not buttons[idx].get("enabled", True)
            save_db()
            answer_callback(call["id"], "✅ Visible" if buttons[idx]["enabled"] else "🚫 Hidden")
            edit_message(chat_id, msg_id, menu_button_detail_text(idx), reply_markup=menu_button_detail_keyboard(idx))

    elif data.startswith("mb_adm_"):
        idx = int(data.split("_")[2])
        buttons = get_menu_buttons()
        if 0 <= idx < len(buttons):
            buttons[idx]["admin_only"] = not buttons[idx].get("admin_only", False)
            save_db()
            edit_message(chat_id, msg_id, menu_button_detail_text(idx), reply_markup=menu_button_detail_keyboard(idx))

    elif data.startswith("mb_up_") or data.startswith("mb_dn_"):
        is_up = data.startswith("mb_up_")
        idx = int(data.split("_")[2])
        buttons = get_menu_buttons()
        target_idx = idx - 1 if is_up else idx + 1
        if 0 <= idx < len(buttons) and 0 <= target_idx < len(buttons):
            buttons[idx], buttons[target_idx] = buttons[target_idx], buttons[idx]
            save_db()
            idx = target_idx
        if 0 <= idx < len(buttons):
            edit_message(chat_id, msg_id, menu_button_detail_text(idx), reply_markup=menu_button_detail_keyboard(idx))

    elif data.startswith("mb_del_"):
        idx = int(data.split("_")[2])
        buttons = get_menu_buttons()
        if 0 <= idx < len(buttons):
            removed = buttons.pop(idx)
            bot_settings["menu_buttons"] = buttons
            save_db()
            answer_callback(call["id"], f"🗑 Deleted: {menu_button_label(removed)}", show_alert=True)
        edit_message(chat_id, msg_id, menu_button_manager_text(), reply_markup=menu_button_manager_keyboard())

    # --- System buttons (fixed user-flow buttons) ---
    elif data == "sys_menu":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, system_buttons_list_text(), reply_markup=system_buttons_list_keyboard())

    elif data.startswith("sys_btn_"):
        key = data.replace("sys_btn_", "")
        if key in SYSTEM_BUTTON_DEFAULTS:
            edit_message(chat_id, msg_id, system_button_detail_text(key), reply_markup=system_button_detail_keyboard(key))

    elif data.startswith("sys_ren_"):
        key = data.replace("sys_ren_", "")
        if key in SYSTEM_BUTTON_DEFAULTS:
            user_states[chat_id] = "wait_for_btn_label"
            temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "system", "key": key}}
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>RENAME BUTTON</b>\n\nSend the new label for <code>{html.escape(key)}</code>:"), reply_markup=_button_cancel_row(f"sys_btn_{key}"))

    elif data.startswith("sys_emoclr_"):
        key = data.replace("sys_emoclr_", "")
        entry = _system_target_entry(key)
        if entry is not None:
            entry["emoji"] = ""
            save_db()
            answer_callback(call["id"], "🗑 Emoji removed")
            edit_message(chat_id, msg_id, system_button_detail_text(key), reply_markup=system_button_detail_keyboard(key))

    elif data.startswith("sys_emo_"):
        key = data.replace("sys_emo_", "")
        if key in SYSTEM_BUTTON_DEFAULTS:
            user_states[chat_id] = "wait_for_btn_emoji"
            temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "system", "key": key}}
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>SET EMOJI</b>\n\nSend a premium emoji or paste its numeric emoji ID."), reply_markup=_button_cancel_row(f"sys_btn_{key}"))

    elif data.startswith("sys_reset_"):
        key = data.replace("sys_reset_", "")
        store = _system_button_store()
        if key in store:
            store.pop(key, None)
            save_db()
            answer_callback(call["id"], "♻️ Button reset to default", show_alert=True)
        if key in SYSTEM_BUTTON_DEFAULTS:
            edit_message(chat_id, msg_id, system_button_detail_text(key), reply_markup=system_button_detail_keyboard(key))

    # --- Inline button editor (per menu) ---
    elif data.startswith("mi_btn_"):
        parts = data.split("_")
        idx = int(parts[-1])
        menu_key = "_".join(parts[2:-1])
        buttons = bot_settings.get("custom_messages", {}).get(menu_key, {}).get("buttons", [])
        if 0 <= idx < len(buttons):
            edit_message(chat_id, msg_id, menu_inline_button_detail_text(menu_key, idx), reply_markup=menu_inline_button_detail_keyboard(menu_key, idx))

    elif data.startswith("mi_ren_"):
        parts = data.split("_")
        idx = int(parts[-1])
        menu_key = "_".join(parts[2:-1])
        user_states[chat_id] = "wait_for_btn_label"
        temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "inline", "menu": menu_key, "idx": idx}}
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>RENAME INLINE BUTTON</b>\n\nSend the new button text:"), reply_markup=_button_cancel_row(f"mi_btn_{menu_key}_{idx}"))

    elif data.startswith("mi_emoclr_"):
        parts = data.split("_")
        idx = int(parts[-1])
        menu_key = "_".join(parts[2:-1])
        buttons = bot_settings.get("custom_messages", {}).get(menu_key, {}).get("buttons", [])
        if 0 <= idx < len(buttons):
            buttons[idx].pop("icon_custom_emoji_id", None)
            save_db()
            edit_message(chat_id, msg_id, menu_inline_button_detail_text(menu_key, idx), reply_markup=menu_inline_button_detail_keyboard(menu_key, idx))

    elif data.startswith("mi_emo_"):
        parts = data.split("_")
        idx = int(parts[-1])
        menu_key = "_".join(parts[2:-1])
        user_states[chat_id] = "wait_for_btn_emoji"
        temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "inline", "menu": menu_key, "idx": idx}}
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>SET INLINE EMOJI</b>\n\nSend a premium emoji or its numeric emoji ID."), reply_markup=_button_cancel_row(f"mi_btn_{menu_key}_{idx}"))

    elif data.startswith("mi_url_"):
        parts = data.split("_")
        idx = int(parts[-1])
        menu_key = "_".join(parts[2:-1])
        user_states[chat_id] = "wait_for_btn_url"
        temp_data[chat_id] = {"msg_id": msg_id, "btn_target": {"kind": "inline", "menu": menu_key, "idx": idx}}
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>CHANGE LINK</b>\n\nSend the new URL (https://... or tg://...):"), reply_markup=_button_cancel_row(f"mi_btn_{menu_key}_{idx}"))

    elif data.startswith("mi_style_"):
        parts = data.split("_")
        idx = int(parts[-1])
        menu_key = "_".join(parts[2:-1])
        buttons = bot_settings.get("custom_messages", {}).get(menu_key, {}).get("buttons", [])
        if 0 <= idx < len(buttons):
            order = ["primary", "success", "danger"]
            current = buttons[idx].get("style", "primary")
            buttons[idx]["style"] = order[(order.index(current) + 1) % len(order)] if current in order else "primary"
            save_db()
            edit_message(chat_id, msg_id, menu_inline_button_detail_text(menu_key, idx), reply_markup=menu_inline_button_detail_keyboard(menu_key, idx))

    # --- OTP delivery diagnostics ---
    elif data == "otp_check":
        edit_message(chat_id, msg_id, otp_delivery_check_text(), reply_markup=otp_delivery_check_keyboard())

    elif data.startswith("getnum_test_"):
        idx = int(data.split("_")[-1])
        answer_callback(call["id"], "🧪 Asking the panel for 1 number...")
        result = getnum_probe_text(idx, chat_id)
        edit_message(chat_id, msg_id, result, reply_markup=panel_config_keyboard(idx) if 0 <= idx < len(bot_settings.get("panels", [])) else None)

    elif data.startswith("otp_check_p_"):
        idx = int(data.split("_")[-1])
        answer_callback(call["id"], "⏳ Testing panel...")
        result = run_panel_otp_probe(idx)
        edit_message(chat_id, msg_id, result, reply_markup=otp_delivery_check_keyboard())

    elif data == "otp_test_self":
        answer_callback(call["id"], "📨 Sending test OTP card...")
        res = send_test_otp_card(chat_id, masked=True)
        if res.get("ok"):
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['ok']} <b>Test OTP card sent to you.</b>\nIf you received it above, Telegram delivery works."), reply_markup=otp_delivery_check_keyboard())
        else:
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['no']} <b>Send failed:</b> <code>{html.escape(str(res.get('description', 'unknown error')))}</code>"), reply_markup=otp_delivery_check_keyboard())

    elif data == "otp_test_group":
        groups = bot_settings.get("fw_groups", [])
        group_lines = "\n".join(f"• <code>{html.escape(str(g.get('chat_id', '')))}</code>" for g in groups) or "<i>No groups configured</i>"
        kb = {"inline_keyboard": [
            [{"text": f"✅ Yes, send to {len(groups)} group(s)", "icon_custom_emoji_id": "5352694861990501856", "callback_data": "otp_test_group_go", "style": "danger"}],
            [{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "otp_check", "style": "primary"}],
        ]}
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['warn']} <b>TEST OTP GROUP DELIVERY</b>\n\nThis sends a real test card to all <b>{len(groups)}</b> OTP groups:\n{group_lines}\n\nContinue?"), reply_markup=kb)

    elif data == "otp_test_group_go":
        answer_callback(call["id"], "📨 Sending...")
        groups = bot_settings.get("fw_groups", [])
        if not groups:
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['no']} No OTP groups configured."), reply_markup=otp_delivery_check_keyboard())
            return
        lines = [f"{PEM['graph']} <b>OTP GROUP TEST RESULT</b>", "\u2501" * 16]
        lines.append(f"🎨 Global group style: <b>{html.escape(_style_name(active_otp_style_id(True)))}</b>")
        lines.append("")
        ok_count = 0
        for group in groups:
            gid = group.get("chat_id")
            group_style = str(group.get("style") or "auto")
            style_for_group = None if group_style in ("", "auto") else group_style
            used_style = _style_name(style_for_group or active_otp_style_id(True))
            res = send_test_otp_card(gid, masked=True, style_id=style_for_group)
            if res.get("ok"):
                ok_count += 1
                lines.append(f"✅ <code>{html.escape(str(gid))}</code> · {html.escape(used_style)}")
            else:
                lines.append(f"❌ <code>{html.escape(str(gid))}</code> → {html.escape(str(res.get('description', 'error'))[:60])}")
        lines.append("")
        lines.append(f"<b>{ok_count}/{len(groups)}</b> groups OK")
        stats = _otp_stats_for("TEST")
        stats["group"] = int(stats.get("group", 0)) + ok_count
        edit_message(chat_id, msg_id, render_body_text("\n".join(lines)), reply_markup=otp_delivery_check_keyboard())

    elif data == "menu_design_list":
        edit_message(chat_id, msg_id, render_body_text(f"🎨 <b>Menu Design Editor</b>\n\nSelect a menu block to edit its Body Text and Inline Buttons. You can use Premium Emojis too!"), reply_markup=menu_design_list_keyboard())

    elif data == "md_reset_defaults":
        bot_settings["custom_messages"] = DEFAULT_CUSTOM_MESSAGES.copy()
        save_db()
        answer_callback(call["id"], "✅ Resetted to Premium Defaults!", show_alert=True)

    elif data.startswith("md_edit_"):
        answer_callback(call["id"])
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        key = data.replace("md_edit_", "")
        cm_text = render_body_text(bot_settings["custom_messages"].get(key, {}).get("text", "..."))
        try:
            edit_message(chat_id, msg_id, render_body_text(f"🎨 <b>Editing: {key.upper()}</b>\n\nPreview of current Text:\n{cm_text}"), reply_markup=menu_edit_options_keyboard(key))
        except: pass

    elif data.startswith("md_text_"):
        key = data.replace("md_text_", "")
        user_states[chat_id] = "wait_for_menu_text"
        temp_data[chat_id] = {"msg_id": msg_id, "menu_key": key}
        edit_message(chat_id, msg_id, render_body_text(f"?? <b>Edit Body: {key.upper()}</b>\n\nSend the new text. You can use Premium Emojis directly here.\n(Use standard HTML like <b>bold</b>, <i>italic</i> for formatting)"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"md_edit_{key}", "style": "danger"}]]})

    elif data.startswith("md_btns_"):
        answer_callback(call["id"]) 
        if chat_id in user_states: del user_states[chat_id] 
        if chat_id in temp_data: del temp_data[chat_id]
        key = data.replace("md_btns_", "")
        try:
            edit_message(chat_id, msg_id, render_body_text(f"⚙️ <b>Edit Inline Buttons: {key.upper()}</b>"), reply_markup=menu_buttons_list_keyboard(key))
        except: pass

    elif data.startswith("md_addbtn_"):
        key = data.replace("md_addbtn_", "")
        user_states[chat_id] = "wait_for_menu_btn"
        temp_data[chat_id] = {"msg_id": msg_id, "menu_key": key}
        edit_message(chat_id, msg_id, render_body_text(f"➕ <b>Add Button: {key.upper()}</b>\n\nSend custom button in this format:\n<code>Button Text - https://link.com</code>\n\n<i>(Only normal Emojis supported here!)</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"md_btns_{key}", "style": "danger"}]]})

    elif data.startswith("md_delbtn_"):
        parts = data.split("_")
        key = "_".join(parts[2:-1])
        b_idx = int(parts[-1])
        if b_idx < len(bot_settings["custom_messages"][key]["buttons"]):
            del bot_settings["custom_messages"][key]["buttons"][b_idx]
            save_db()
            answer_callback(call["id"], "✅ Button Deleted!", show_alert=True)
            edit_message(chat_id, msg_id, render_body_text(f"⚙️ <b>Edit Inline Buttons: {key.upper()}</b>"), reply_markup=menu_buttons_list_keyboard(key))

    elif data.startswith("sel_wm_"):
        method = data.replace("sel_wm_", "")
        bal = get_user(chat_id).get('balance', 0.0)
        min_w = bot_settings['min_withdraw']
        
        if bal < min_w:
            answer_callback(call["id"], f"❌ Insufficient balance! Minimum {min_w} USDT required.", show_alert=True)
            return
            
        temp_data[chat_id] = {"method": method, "balance": bal, "msg_id": msg_id}
        user_states[chat_id] = "wait_for_withdraw_amount"
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['ok']} Method: {method}\n💰 Available Balance: {bal} USDT\n\n📝 Enter the amount you want to withdraw (Min: {min_w} USDT):"), reply_markup=get_cancel_kb())
        answer_callback(call["id"])

    elif data == "test_message_flow":
        sims = active_test_simulations
        total_running = sum(1 for s in sims.values() if s.get("running"))
        kb = []
        for sim_id, sim in list(sims.items()):
            status = "🟢" if sim.get("running") else "🔴"
            sent = sim.get("total_sent", 0)
            label = f"{status} {sim['flag']} {sim['iso']} {sim['platform']} ({sent}/2880)"
            kb.append([{"text": label[:60], "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"stop_test_sim_{sim_id}", "style": "danger"}])
        kb.append([{"text": "➕ Add New Simulation", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_test_sim", "style": "success"}])
        if sims:
            kb.append([{"text": "⛔ Stop All Simulations", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "stop_all_test_sims", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "primary"}])
        txt = (
            f"🧪 <b>Test Simulation Panel</b>\n\n"
            f"<b>Active:</b> {total_running}　<b>Total:</b> {len(sims)}\n\n"
            f"<i>Each simulation sends 2,880 fake OTP messages randomly over 24 hours to all Forward Groups.\n"
            f"Tap a simulation row to stop it.</i>"
        )
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup={"inline_keyboard": kb})

    elif data == "add_test_sim":
        user_states[chat_id] = "wait_for_sim_input"
        temp_data[chat_id] = {"msg_id": msg_id}
        txt = (
            "🧪 <b>Add Test Simulation</b>\n\n"
            "Send one line in this format:\n"
            "<code>🇧🇩 BD Facebook 880 #EN 123-456</code>\n\n"
            "• <b>Flag emoji</b> — country flag (🇧🇩)\n"
            "• <b>ISO code</b> — 2-letter code (BD)\n"
            "• <b>Platform name</b> — app/service (Facebook)\n"
            "• <b>Dial code</b> — numeric (880)\n"
            "• <b>Language tag</b> — #EN, #AR … <i>(optional)</i>\n"
            "• <b>OTP pattern</b> — sets digit count &amp; style <i>(optional)</i>\n\n"
            "  <code>12345</code>   → 5-digit OTP, no separator\n"
            "  <code>123-45</code>  → 5-digit OTP with dash (3+2)\n"
            "  <code>123-456</code> → 6-digit OTP with dash (3+3)\n"
            "  <i>(omit for default 6-digit)</i>\n\n"
            "<i>The bot will generate 2,880 fake messages randomly distributed over 24 hours.</i>"
        )
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup={"inline_keyboard": [
            [{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "test_message_flow", "style": "danger"}]
        ]})

    elif data.startswith("stop_test_sim_"):
        sim_id = data[len("stop_test_sim_"):]
        if sim_id in active_test_simulations:
            active_test_simulations[sim_id]["stop_event"].set()
            active_test_simulations[sim_id]["running"] = False
            del active_test_simulations[sim_id]
            answer_callback(call["id"], "✅ Simulation stopped!", show_alert=True)
        else:
            answer_callback(call["id"], "⚠️ Simulation not found (may have already finished).", show_alert=True)
        handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "test_message_flow", "id": call["id"]})

    elif data == "stop_all_test_sims":
        for sim in active_test_simulations.values():
            sim["stop_event"].set()
            sim["running"] = False
        active_test_simulations.clear()
        answer_callback(call["id"], "✅ All simulations stopped!", show_alert=True)
        handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "test_message_flow", "id": call["id"]})

    elif data == "manage_emojis":
        _pack_total = len(FLAG_CUSTOM_EMOJI_IDS)
        _have = len(bot_settings.get("premium_flags", {}) or {})
        edit_message(chat_id, msg_id, render_body_text(
            f"{PEM['star']} <b>Premium Emoji Management</b>\n\n"
            f"Upload your TXT files or manually add them below:\n\n"
            f"{PEM['ok']} Flag emojis active: <b>{_have}</b>/<b>{len(COUNTRY_DB)}</b> countries\n"
            f"🚩 Default pack: <b>{_pack_total}</b> flags · fallback id <code>{DEFAULT_FLAG_CUSTOM_EMOJI_ID}</code>"
        ), reply_markup=emoji_settings_keyboard())

    elif data == "up_flags_txt":
        user_states[chat_id] = "wait_for_flag_txt"
        edit_message(chat_id, msg_id, render_body_text("📂 Please upload the <b>Flag Emojis</b> <code>.txt</code> file."), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_emojis", "style": "danger"}]]})

    elif data == "up_apps_txt":
        user_states[chat_id] = "wait_for_app_txt"
        edit_message(chat_id, msg_id, render_body_text("📂 Please upload the <b>Service Apps</b> <code>.txt</code> file."), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_emojis", "style": "danger"}]]})

    elif data == "add_single_emoji":
        user_states[chat_id] = "wait_for_emoji_extract"
        edit_message(chat_id, msg_id, render_body_text("📝 Send any Premium Emoji (e.g.: 🇧🇩 or 🚫):"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_emojis", "style": "danger"}]]})

    elif data == "dl_flags_txt":
        content = generate_emoji_txt("flags")
        if content:
            send_document(chat_id, "Flag_Emojis.txt", content)
            answer_callback(call["id"], "✅ Downloaded!")
        else:
            answer_callback(call["id"], "❌ No Flag Emojis found!", show_alert=True)

    elif data == "dl_apps_txt":
        content = generate_emoji_txt("apps")
        if content:
            send_document(chat_id, "Service_Apps.txt", content)
            answer_callback(call["id"], "✅ Downloaded!")
        else:
            answer_callback(call["id"], "❌ No App Emojis found!", show_alert=True)

    elif data == "flag_pack_reset":
        added, updated = seed_flag_emojis(force=True)
        save_db()
        answer_callback(call["id"], f"🚩 Default flag pack applied!\nNew: {added} · Updated: {updated}", show_alert=True)
        edit_message(chat_id, msg_id, render_body_text(
            f"{PEM['ok']} <b>Flag pack restored</b>\n\n"
            f"• Countries set: <b>{len(bot_settings.get('premium_flags', {}))}</b>\n"
            f"• Newly added: <b>{added}</b>\n"
            f"• Updated ids: <b>{updated}</b>\n"
            f"• Fallback (unknown country): 🚩 <code>{DEFAULT_FLAG_CUSTOM_EMOJI_ID}</code>"
        ), reply_markup=emoji_settings_keyboard())

    elif data == "del_all_flags":
        bot_settings["premium_flags"] = {}
        save_db()
        answer_callback(call["id"], "✅ All Premium Flags Deleted Successfully!", show_alert=True)

    elif data == "broadcast_msg":
        user_states[chat_id] = "wait_for_broadcast"
        edit_message(chat_id, msg_id, render_body_text("📢 <b>Broadcast Mode</b>\n\nSend the message you want to broadcast (Text, Photo, Video, File etc)."), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]]})

    elif data == "upload_num":
        user_states[chat_id] = "wait_for_txt"
        edit_message(chat_id, msg_id, render_body_text("📂 Please upload the numbers in a <b>.txt</b> file."), reply_markup={"inline_keyboard": [[{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]]})

    elif data == "delete_files":
        kb = []
        for b_id, b_data in number_batches.items():
            kb.append([{"text": f"{b_data['filename']} ({len(b_data['numbers'])})", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"del_b_{b_id}", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "primary"}])
        txt = "🗑 Select a file to delete:" if len(kb) > 1 else f"{PEM['no']} No files found."
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup={"inline_keyboard": kb})

    elif data.startswith("del_b_"):
        b_id = data.split("del_b_")[1]
        if b_id in number_batches:
            del number_batches[b_id]
            save_db()
            answer_callback(call["id"], "✅ File deleted!", show_alert=True)
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "delete_files", "id": call["id"]})

    elif data == "show_used":
        all_nums = set()
        for b in number_batches.values():
            for n in b["numbers"]:
                all_nums.add(n["num"].replace("+", "").strip())
        for n in used_numbers_list:
            all_nums.add(n.replace("+", "").strip())
        otp_used = [n for n in all_nums if n in otp_received_numbers]
        kb = {"inline_keyboard": [[{"text": "Download TXT", "icon_custom_emoji_id": "5257969839313526622", "callback_data": "dl_used", "style": "primary"}], [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]]}
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['ok']} <b>Used Numbers (OTP Received):</b> {len(otp_used)}"), reply_markup=kb)

    elif data == "show_unused":
        all_nums = set()
        for b in number_batches.values():
            for n in b["numbers"]:
                all_nums.add(n["num"].replace("+", "").strip())
        for n in used_numbers_list:
            all_nums.add(n.replace("+", "").strip())
        otp_unused = [n for n in all_nums if n not in otp_received_numbers]
        kb = {"inline_keyboard": [[{"text": "Download TXT", "icon_custom_emoji_id": "5257969839313526622", "callback_data": "dl_unused", "style": "primary"}], [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]]}
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['rocket']} <b>Unused Numbers (No OTP):</b> {len(otp_unused)}"), reply_markup=kb)

    elif data == "dl_used":
        all_nums = set()
        for b in number_batches.values():
            for n in b["numbers"]:
                all_nums.add(n["num"].replace("+", "").strip())
        for n in used_numbers_list:
            all_nums.add(n.replace("+", "").strip())
        otp_used = [n for n in all_nums if n in otp_received_numbers]
        if not otp_used:
            answer_callback(call["id"], "No OTP received numbers found!", show_alert=True)
            return
        content = "\n".join(otp_used).encode('utf-8')
        send_document(chat_id, "used_otp_numbers.txt", content)
        answer_callback(call["id"])

    elif data == "dl_unused":
        all_nums = set()
        for b in number_batches.values():
            for n in b["numbers"]:
                all_nums.add(n["num"].replace("+", "").strip())
        for n in used_numbers_list:
            all_nums.add(n.replace("+", "").strip())
        otp_unused = [n for n in all_nums if n not in otp_received_numbers]
        if not otp_unused:
            answer_callback(call["id"], "All numbers have received OTP!", show_alert=True)
            return
        content = "\n".join(otp_unused).encode('utf-8')
        send_document(chat_id, "unused_no_otp_numbers.txt", content)
        answer_callback(call["id"])

    elif data == "lb_main":
        txt = f"━━━━━━━━━━━━━━━\n《 {PEM['admin']} <b>LEADER BOARD MENU</b> 》\n━━━━━━━━━━━━━━━\n<i>Select a category to view the top performers or history.</i>\n━━━━━━━━━━━━━━━"
        kb = [
            [{"text": "Top Referrers", "icon_custom_emoji_id": "5420145051336485498", "callback_data": "lb_top_refs", "style": "primary"}],
            [{"text": "Top OTP Receivers", "icon_custom_emoji_id": "5353001161878182134", "callback_data": "lb_top_otps", "style": "primary"}],
            [{"text": "Withdrawal History", "icon_custom_emoji_id": "5348469219761626211", "callback_data": "lb_w_history", "style": "success"}],
            [{"text": "Back to Admin", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "back_to_admin", "style": "danger"}]
        ]
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup={"inline_keyboard": kb})

    elif data.startswith("lb_"):
        sub = data.replace("lb_", "")
        edit_message(chat_id, msg_id, render_body_text("⌛ <i>Fetching Data...</i>"))
        
        num_map = {"1": "1️⃣", "2": "2️⃣", "3": "3️⃣", "4": "4️⃣", "5": "5️⃣", "6": "6️⃣", "7": "7️⃣", "8": "8️⃣", "9": "9️⃣", "0": "0️⃣"}
        def get_p_num(n): return "".join([num_map.get(c, c) for c in str(n)])
        
        try:
            if sub == "top_refs":
                title, field, limit_n, icon = "TOP 5 REFERRERS", "total_refers", 5, PEM.get('user', '👥')
                res_txt = ""
                count = 1
                if not res_txt:
                    sorted_users = sorted(local_users_db.items(), key=lambda x: x[1].get(field, 0), reverse=True)[:limit_n]
                    for uid, d in sorted_users:
                        if d.get(field, 0) > 0:
                            p = "└" if count == limit_n else "├"
                            res_txt += f"{p} {get_p_num(count)} <a href='tg://user?id={uid}'>{uid}</a> ➔ <b>{d.get(field,0)}</b>\n"
                            count += 1
                if not res_txt: res_txt = "└ <i>No data found.</i>\n"

            elif sub == "top_otps":
                title, field, limit_n, icon = "TOP 5 OTP RECEIVERS", "total_otps", 5, PEM.get('msg', '📩')
                res_txt = ""
                count = 1
                if not res_txt:
                    sorted_users = sorted(local_users_db.items(), key=lambda x: x[1].get(field, 0), reverse=True)[:limit_n]
                    for uid, d in sorted_users:
                        if d.get(field, 0) > 0:
                            p = "└" if count == limit_n else "├"
                            res_txt += f"{p} {get_p_num(count)} <a href='tg://user?id={uid}'>{uid}</a> ➔ <b>{d.get(field,0)}</b>\n"
                            count += 1
                if not res_txt: res_txt = "└ <i>No data found.</i>\n"

            elif sub == "w_history":
                title, limit_n, icon = "LAST 10 WITHDRAWALS", 10, PEM.get('money', '💸')
                res_txt = ""
                count = 1
                if not res_txt:
                    sorted_ws = sorted(local_withdrawals_db.items(), key=lambda x: x[1].get("timestamp", 0), reverse=True)[:limit_n]
                    for wid, d in sorted_ws:
                        s = str(d.get('status','Pending')).lower()
                        stat_icon = PEM.get('ok','✅') if s in ["approved","success"] else PEM.get('no','❌') if s=="rejected" else "⏳"
                        uid = d.get('user_id','User')
                        p = "└" if count == limit_n else "├"
                        res_txt += f"{p} {get_p_num(count)} <a href='tg://user?id={uid}'>{uid}</a> ➔ <b>{d.get('amount',0)}USDT</b> {stat_icon}\n"
                        count += 1
                if not res_txt: res_txt = "└ <i>No history found.</i>\n"

            final_msg = f"━━━━━━━━━━━━━━━\n{icon} <b>{title}</b>\n━━━━━━━━━━━━━━━\n{res_txt}━━━━━━━━━━━━━━━"
            kb = [[{"text": "Refresh", "icon_custom_emoji_id": "5420155432272438703", "callback_data": data, "style": "success"}, {"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "lb_main", "style": "danger"}]]
            edit_message(chat_id, msg_id, render_body_text(final_msg), reply_markup={"inline_keyboard": kb})

        except Exception as e:
            edit_message(chat_id, msg_id, render_body_text(f"❌ Error: {e}"), reply_markup={"inline_keyboard": [[{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "lb_main", "style": "danger"}]]})

    elif data == "backup_menu":
        if chat_id in user_states: del user_states[chat_id]
        if chat_id in temp_data: del temp_data[chat_id]
        edit_message(chat_id, msg_id, backup_menu_text(), reply_markup=backup_menu_keyboard())

    elif data == "backup_download":
        try:
            file_name = backup_file_name()
            payload = backup_json_text().encode("utf-8")
            send_document(chat_id, file_name, payload)
            answer_callback(call["id"], "📥 Backup file sent to your chat.")
            edit_message(chat_id, msg_id, backup_menu_text(
                notice=f"{PEM['ok']} <b>Backup sent:</b> <code>{file_name}</code> ({len(payload)} bytes)"
            ), reply_markup=backup_menu_keyboard())
        except Exception as exc:
            answer_callback(call["id"], f"❌ Backup failed: {str(exc)[:120]}", show_alert=True)

    elif data == "backup_reset":
        answer_callback(call["id"], "⚠️ Reset needs 2 confirmations.", show_alert=True)
        edit_message(chat_id, msg_id, backup_reset_text(step=1), reply_markup=backup_reset_keyboard(step=1))

    elif data == "backup_reset_1":
        answer_callback(call["id"], "⚠️ 1/2 confirmed. One more tap to delete everything.", show_alert=True)
        edit_message(chat_id, msg_id, backup_reset_text(step=2), reply_markup=backup_reset_keyboard(step=2))

    elif data == "backup_reset_2":
        stats = reset_all_data()
        answer_callback(call["id"], "🗑 All data deleted — bot is back to factory default.", show_alert=True)
        edit_message(chat_id, msg_id, render_body_text(
            f"{PEM['ok']} <b>ALL DATA RESET</b>\n" + "\u2501" * 16 +
            f"\n🗑 Users removed: <b>{stats['users']}</b>"
            f"\n🗑 Withdrawals removed: <b>{stats['withdrawals']}</b>"
            f"\n🗑 Number files removed: <b>{stats['files']}</b>"
            f"\n🗑 Broadcast list cleared: <b>{stats['known_users']}</b>"
            f"\n🗑 Custom styles removed: <b>{stats['styles']}</b>"
            f"\n\n🔒 Admin: <code>{OWNER_ID}</code>"
            f"\n📁 Data folder: <code>{html.escape(os.path.abspath(DATA_DIR))}</code>"
            f"\n\n<i>বট এখন একদম নতুন অবস্থায় — প্রথমবার চালানোর মতো।</i>"
        ), reply_markup=backup_menu_keyboard())

    elif data == "backup_import":
        user_states[chat_id] = "wait_for_backup_file"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text(
            f"📤 <b>IMPORT OLD DATA</b>\n" + "\u2501" * 16 +
            "\nSend the backup file (<code>.json</code>) you downloaded earlier.\n\n"
            "• পুরনো ডাটা <b>যোগ</b> হবে — বর্তমান ডাটা মুছবে না\n"
            "• ইউজার ব্যালেন্স / OTP সংখ্যা, withdraw হিস্ট্রি, নাম্বার ফাইল, সেটিংস — সব আসবে\n"
            "• একই Req ID থাকলে পুরনোটা বাদ যাবে\n\n"
            "<i>Tip: আগে 📥 Download Data File দিয়ে ব্যাকআপ নিয়ে রাখুন।</i>"
        ), reply_markup={"inline_keyboard": [[
            {"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "backup_menu", "style": "danger"}
        ]]})

    elif data == "back_to_admin":
        if chat_id in user_states: del user_states[chat_id]
        edit_message(chat_id, msg_id, get_admin_text(), reply_markup=admin_panel_keyboard())
        
    elif data == "system_settings":
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['gear']} <b>System Settings</b>\nManage advanced bot configurations below:"), reply_markup=system_settings_keyboard())


    # ==========================================
    # 🌟 VoltX Services Management Callbacks
    # ==========================================
    elif data.startswith("pvs_manage_"):
        panel_idx = int(data.rsplit("_", 1)[1])
        ui_text, markup = panel_services_manager_view(panel_idx)
        edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)

    elif data.startswith("pvs_add_srv_"):
        panel_idx = int(data.rsplit("_", 1)[1])
        user_states[chat_id] = "wait_pvs_srv_name"
        temp_data[chat_id] = {"msg_id": msg_id, "panel_idx": panel_idx}
        panel = get_number_panel_for_source(panel_idx)
        provider = panel.get("type", "Number Panel").replace(" Panel", "") if panel else "Panel"
        edit_message(
            chat_id,
            msg_id,
            render_body_text(
                f"📝 Send the <b>Service Name</b> for <b>{provider}</b>:\n"
                f"<i>Every range added here will stay attached to this panel.</i>"
            ),
            reply_markup={
                "inline_keyboard": [[{
                    "text": "Cancel",
                    "icon_custom_emoji_id": "5267490665117275176",
                    "callback_data": f"pvs_manage_{panel_idx}",
                    "style": "danger",
                }]]
            },
        )

    elif data.startswith("pvs_srv_"):
        parts = data.split("_")
        if len(parts) != 4:
            return
        panel_idx, service_idx = int(parts[2]), int(parts[3])
        ui_text, markup = panel_service_countries_view(panel_idx, service_idx)
        edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)

    elif data.startswith("pvs_add_cnt_"):
        raw_indexes = data[len("pvs_add_cnt_"):].split("_", 1)
        if len(raw_indexes) != 2:
            answer_callback(call["id"], "❌ Invalid Add Country callback.", show_alert=True)
            return
        try:
            panel_idx, service_idx = map(int, raw_indexes)
        except ValueError:
            answer_callback(call["id"], "❌ Invalid panel or service reference.", show_alert=True)
            return
        user_states[chat_id] = "wait_pvs_cnt_name"
        temp_data[chat_id] = {
            "msg_id": msg_id,
            "panel_idx": panel_idx,
            "service_idx": service_idx,
        }
        panel = get_number_panel_for_source(panel_idx)
        service_items = get_panel_service_items(panel) if panel else []
        service = service_items[service_idx][0] if 0 <= service_idx < len(service_items) else "Service"
        edit_message(
            chat_id,
            msg_id,
            render_body_text(
                f"📝 Send the <b>Country Name</b> for <b>{service}</b>:\n"
                f"<i>Same country names can exist separately on different panels.</i>"
            ),
            reply_markup={
                "inline_keyboard": [[{
                    "text": "Cancel",
                    "icon_custom_emoji_id": "5267490665117275176",
                    "callback_data": f"pvs_srv_{panel_idx}_{service_idx}",
                    "style": "danger",
                }]]
            },
        )

    elif data.startswith("pvs_cnt_"):
        parts = data.split("_")
        if len(parts) != 5:
            return
        panel_idx, service_idx, country_idx = map(int, parts[2:5])
        ui_text, markup = panel_service_country_view(
            panel_idx,
            service_idx,
            country_idx,
        )
        edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)

    elif data.startswith("pvs_add_rng_"):
        parts = data.split("_")
        if len(parts) != 6:
            return
        panel_idx, service_idx, country_idx = map(int, parts[3:6])
        user_states[chat_id] = "wait_pvs_range"
        temp_data[chat_id] = {
            "msg_id": msg_id,
            "panel_idx": panel_idx,
            "service_idx": service_idx,
            "country_idx": country_idx,
        }
        panel = get_number_panel_for_source(panel_idx)
        ui_text = "📝 Send the Number Prefix/Range for this panel:"
        if panel:
            ui_text += f"\n<i>Provider: {panel.get('name', 'Selected panel')}</i>"
        edit_message(
            chat_id,
            msg_id,
            render_body_text(ui_text),
            reply_markup={
                "inline_keyboard": [[{
                    "text": "Cancel",
                    "icon_custom_emoji_id": "5267490665117275176",
                    "callback_data": f"pvs_cnt_{panel_idx}_{service_idx}_{country_idx}",
                    "style": "danger",
                }]]
            },
        )

    elif data.startswith("pvs_del_rng_"):
        parts = data.split("_")
        if len(parts) != 7:
            return
        panel_idx, service_idx, country_idx, range_idx = map(int, parts[3:7])
        panel = get_number_panel_for_source(panel_idx)
        services = get_panel_service_items(panel) if panel else []
        if 0 <= service_idx < len(services):
            _, countries = services[service_idx]
            countries = list((countries or {}).items())
            if 0 <= country_idx < len(countries):
                _, ranges = countries[country_idx]
                if 0 <= range_idx < len(ranges):
                    deleted = ranges.pop(range_idx)
                    save_db()
                    answer_callback(call["id"], f"✅ Range {deleted} deleted!", show_alert=True)
        ui_text, markup = panel_service_country_view(panel_idx, service_idx, country_idx)
        edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)

    elif data.startswith("pvs_del_cnt_"):
        parts = data.split("_")
        if len(parts) != 6:
            return
        panel_idx, service_idx, country_idx = map(int, parts[3:6])
        panel = get_number_panel_for_source(panel_idx)
        services = get_panel_service_items(panel) if panel else []
        if 0 <= service_idx < len(services):
            _, countries = services[service_idx]
            countries = list((countries or {}).items())
            if 0 <= country_idx < len(countries):
                deleted = countries.pop(country_idx)[0]
                # Rebuild the dict because the UI uses index-based callbacks.
                services[service_idx][1].clear()
                services[service_idx][1].update(countries)
                save_db()
                answer_callback(call["id"], f"✅ Country {deleted} deleted!", show_alert=True)
        ui_text, markup = panel_service_countries_view(panel_idx, service_idx)
        edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)

    elif data.startswith("pvs_del_srv_"):
        parts = data.split("_")
        if len(parts) != 5:
            return
        panel_idx, service_idx = int(parts[3]), int(parts[4])
        panel = get_number_panel_for_source(panel_idx)
        services = get_panel_services(panel) if panel else {}
        service_items = list(services.items())
        if 0 <= service_idx < len(service_items):
            deleted = service_items[service_idx][0]
            del services[deleted]
            save_db()
            answer_callback(call["id"], f"✅ Service {deleted} deleted!", show_alert=True)
        ui_text, markup = panel_services_manager_view(panel_idx)
        edit_message(chat_id, msg_id, render_body_text(ui_text), reply_markup=markup)

    elif data == "manage_vx_srv":
        if "voltx_services" not in bot_settings: bot_settings["voltx_services"] = {}
        vx_srvs = bot_settings["voltx_services"]
        kb = []
        for srv_name in vx_srvs:
            cnt_count = len(vx_srvs[srv_name])
            kb.append([{"text": f"📦 {srv_name} ({cnt_count} countries)", "icon_custom_emoji_id": "5192739271886282680", "callback_data": f"vx_srv_{srv_name}", "style": "primary"}])
        kb.append([{"text": "➕ Add Service", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "vx_add_srv", "style": "success"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_panels", "style": "danger"}])
        edit_message(chat_id, msg_id, render_body_text(f"📦 <b>VoltX Services Manager</b>\nManage your VoltX API-based services below:"), reply_markup={"inline_keyboard": kb})

    elif data == "vx_add_srv":
        user_states[chat_id] = "wait_vx_srv_name"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the <b>Service Name</b>:\n<i>Example: WhatsApp</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_vx_srv", "style": "danger"}]]})

    elif data.startswith("vx_srv_"):
        srv = data[7:]
        if srv not in bot_settings.get("voltx_services", {}):
            answer_callback(call["id"], "❌ Service not found!", show_alert=True)
            return
        vx_cnt = bot_settings["voltx_services"].get(srv, {})
        kb = []
        for cnt_name, ranges in vx_cnt.items():
            kb.append([{"text": f"🏳️ {cnt_name} ({len(ranges)} ranges)", "icon_custom_emoji_id": DEFAULT_FLAG_CUSTOM_EMOJI_ID, "callback_data": f"vx_cnt_{srv}_{cnt_name}", "style": "primary"}])
        kb.append([{"text": "➕ Add Country", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"vx_add_cnt_{srv}", "style": "success"}])
        kb.append([{"text": "🗑 Delete Service", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"vx_del_srv_{srv}", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_vx_srv", "style": "primary"}])
        edit_message(chat_id, msg_id, render_body_text(f"🌍 <b>{srv} Countries</b>\nManage countries for this number API service:"), reply_markup={"inline_keyboard": kb})

    elif data.startswith("vx_add_cnt_"):
        srv = data[11:]
        user_states[chat_id] = "wait_vx_cnt_name"
        temp_data[chat_id] = {"msg_id": msg_id, "srv": srv}
        edit_message(chat_id, msg_id, render_body_text(f"📝 Send the <b>Country Name</b> for <b>{srv}</b>:\n<i>Example: India</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"vx_srv_{srv}", "style": "danger"}]]})

    elif data.startswith("vx_cnt_"):
        rest = data[7:]
        parts = rest.split("_", 1)
        if len(parts) < 2:
            return
        srv, cnt = parts[0], parts[1]
        ranges = bot_settings.get("voltx_services", {}).get(srv, {}).get(cnt, [])
        ranges_text = "\n".join([f"• <code>{r}</code>" for r in ranges]) if ranges else "<i>No ranges yet</i>"
        kb = []
        for r in ranges:
            kb.append([{"text": f"❌ {r}", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"vx_dr_{srv}_{cnt}_{r}", "style": "danger"}])
        kb.append([{"text": "➕ Add Range/Prefix", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"vx_add_rng_{srv}_{cnt}", "style": "success"}])
        kb.append([{"text": "🗑 Delete Country", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"vx_del_cnt_{srv}_{cnt}", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"vx_srv_{srv}", "style": "primary"}])
        edit_message(chat_id, msg_id, render_body_text(f"📱 <b>{srv} → {cnt}</b>\n\n{ranges_text}"), reply_markup={"inline_keyboard": kb})

    elif data.startswith("vx_add_rng_"):
        rest = data[11:]
        parts = rest.split("_", 1)
        if len(parts) < 2:
            return
        srv, cnt = parts[0], parts[1]
        user_states[chat_id] = "wait_vx_addr"
        temp_data[chat_id] = {"msg_id": msg_id, "srv": srv, "cnt": cnt}
        edit_message(chat_id, msg_id, render_body_text(f"📝 Send the <b>Number Prefix/Range</b> for <b>{cnt}</b>:\n<i>Example: 88017, 91981XXX</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"vx_cnt_{srv}_{cnt}", "style": "danger"}]]})

    elif data.startswith("vx_dr_"):
        rest = data[6:]
        parts = rest.split("_", 2)
        if len(parts) < 3:
            return
        srv, cnt, rng = parts[0], parts[1], parts[2]
        if srv in bot_settings.get("voltx_services", {}) and cnt in bot_settings["voltx_services"][srv]:
            if rng in bot_settings["voltx_services"][srv][cnt]:
                bot_settings["voltx_services"][srv][cnt].remove(rng)
                save_db()
        answer_callback(call["id"], f"✅ Range {rng} deleted!", show_alert=True)
        handle_callback({"message": call["message"], "data": f"vx_cnt_{srv}_{cnt}", "id": "internal"})

    elif data.startswith("vx_del_srv_"):
        srv = data[11:]
        if srv in bot_settings.get("voltx_services", {}):
            del bot_settings["voltx_services"][srv]
            save_db()
        answer_callback(call["id"], f"✅ Service {srv} deleted!", show_alert=True)
        handle_callback({"message": call["message"], "data": "manage_vx_srv", "id": "internal"})

    elif data.startswith("vx_del_cnt_"):
        rest = data[11:]
        parts = rest.split("_", 1)
        if len(parts) < 2:
            return
        srv, cnt = parts[0], parts[1]
        if srv in bot_settings.get("voltx_services", {}) and cnt in bot_settings["voltx_services"][srv]:
            del bot_settings["voltx_services"][srv][cnt]
            save_db()
        answer_callback(call["id"], f"✅ Country {cnt} deleted!", show_alert=True)
        handle_callback({"message": call["message"], "data": f"vx_srv_{srv}", "id": "internal"})

    elif data.startswith("manage_vx_srv_"):
        # Panel-specific VoltX/FastX services (from panel_config_keyboard).
        idx = int(data.split("_")[3])
        handle_callback({
            "message": call["message"],
            "data": f"pvs_manage_{idx}",
            "id": call["id"],
        })

    elif data == "nexa_control":
        edit_message(chat_id, msg_id, render_body_text(f"🌐 <b>Nexa Control Panel</b>\n\nTotal API Keys: {len(bot_settings.get('nexa_keys', []))}\nManage your Nexa API Keys below:"), reply_markup=nexa_control_keyboard())

    elif data == "add_nexa_key":
        user_states[chat_id] = "wait_for_add_nexa_key"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the new Nexa API Key (e.g. nxa_...):"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "nexa_control", "style": "danger"}]]})

    elif data == "view_nexa_keys":
        kb = []
        for idx, key in enumerate(bot_settings.get("nexa_keys", [])):
            safe_name = key[:10] + "..." if len(key)>10 else key
            kb.append([{"text": f"Delete {safe_name}", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"del_nxa_{idx}", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "nexa_control", "style": "primary"}])
        edit_message(chat_id, msg_id, render_body_text("🗑 <b>Select Nexa Key to Delete:</b>"), reply_markup={"inline_keyboard": kb})

    elif data.startswith("del_nxa_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings.get("nexa_keys", [])):
            del bot_settings["nexa_keys"][idx]
            save_db()
            answer_callback(call["id"], "✅ Nexa Key Deleted!", show_alert=True)
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "view_nexa_keys", "id": call["id"]})

    elif data == "nexa_search_country":
        kb = []
        for idx, c in enumerate(bot_settings.get("search_countries", [])):
            kb.append([{"text": f"Delete {c}", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"del_sc_{idx}", "style": "danger"}])
        kb.append([{"text": "Add Country Code", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "add_search_country", "style": "success"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "nexa_control", "style": "primary"}])
        edit_message(chat_id, msg_id, render_body_text("🌍 <b>Allowed Search Countries:</b>\nOnly these country codes will be allowed in Search Number."), reply_markup={"inline_keyboard": kb})

    elif data == "add_search_country":
        user_states[chat_id] = "wait_for_add_sc"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the Country Code (e.g. 880 or 92):"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "nexa_search_country", "style": "danger"}]]})

    elif data.startswith("del_sc_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings.get("search_countries", [])):
            del bot_settings["search_countries"][idx]
            save_db()
            answer_callback(call["id"], "✅ Country Deleted!", show_alert=True)
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "nexa_search_country", "id": call["id"]})

    elif data == "manage_nexa_srv":
        kb = []
        srvs = bot_settings.get("nexa_services", {})
        apps_db = bot_settings.get("premium_apps", {})
        for srv in srvs:
            emoji_id = "5257969839313526622"
            for app_key, app_data in apps_db.items():
                if srv.upper() == app_key or srv.upper() in app_key or app_key in srv.upper():
                    if "id" in app_data:
                        emoji_id = app_data["id"]
                        break
            kb.append([{"text": f"{srv}", "icon_custom_emoji_id": emoji_id, "callback_data": f"nx_srv_{srv}", "style": "primary"}])
        kb.append([{"text": "Add New Service", "icon_custom_emoji_id": "5420323438508155202", "callback_data": "nx_add_srv", "style": "success"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "nexa_control", "style": "danger"}])
        edit_message(chat_id, msg_id, render_body_text("📦 <b>Nexa Services Manager</b>\nManage your API-based dynamic services below:"), reply_markup={"inline_keyboard": kb})

    elif data == "nx_add_srv":
        user_states[chat_id] = "wait_nx_srv_name"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Enter Service Name (e.g. TELEGRAM):"), reply_markup=get_cancel_kb())

    elif data.startswith("nx_srv_"):
        srv = data.replace("nx_srv_", "")
        kb = []
        countries = bot_settings["nexa_services"].get(srv, {})
        flags_db = bot_settings.get("premium_flags", {})
        for c in countries:
            emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID
            for flag_code, flag_data in flags_db.items():
                iso = flag_data.get("iso", "").upper()
                name = flag_data.get("name", "").upper()
                if c.upper() == iso or c.upper() == name or c.upper() in name or name in c.upper():
                    if "id" in flag_data:
                        emoji_id = flag_data["id"]
                        break
            kb.append([{"text": f"{c} ({len(countries[c])} Ranges)", "icon_custom_emoji_id": emoji_id, "callback_data": f"nx_cnt_{srv}_{c}", "style": "primary"}])
        kb.append([{"text": "Add Country", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"nx_add_cnt_{srv}", "style": "success"}])
        kb.append([{"text": "Delete Service", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"nx_del_srv_{srv}", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_nexa_srv", "style": "primary"}])
        edit_message(chat_id, msg_id, render_body_text(f"📂 <b>Service: {srv}</b>\nManage countries for this service:"), reply_markup={"inline_keyboard": kb})

    elif data.startswith("nx_add_cnt_"):
        srv = data.replace("nx_add_cnt_", "")
        user_states[chat_id] = "wait_nx_cnt_name"
        temp_data[chat_id] = {"msg_id": msg_id, "srv": srv}
        edit_message(chat_id, msg_id, render_body_text(f"🌍 Enter Country Name for <b>{srv}</b> (e.g. BD, INDIA):"), reply_markup=get_cancel_kb())

    elif data.startswith("nx_cnt_"):
        parts = data.split("_")
        srv, cnt = parts[2], parts[3]
        ranges = bot_settings["nexa_services"][srv].get(cnt, [])
        
        kb = []
        row = []
        for r in ranges:
            row.append({"text": f"Delete {r}", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"nx_dr_{srv}_{cnt}_{r}", "style": "danger"})
            if len(row) == 2:
                kb.append(row)
                row = []
        if row: kb.append(row)
        
        kb.append([{"text": "Add Range", "icon_custom_emoji_id": "5420323438508155202", "callback_data": f"nx_addr_{srv}_{cnt}", "style": "success"}])
        kb.append([{"text": "Delete Entire Country", "icon_custom_emoji_id": "5422557736330106570", "callback_data": f"nx_del_cnt_{srv}_{cnt}", "style": "danger"}])
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"nx_srv_{srv}", "style": "primary"}])
        
        txt = f"📍 <b>Service: {srv} | Country: {cnt}</b>\n\n<b>Total Ranges:</b> {len(ranges)}\n<i>Click on a range below to delete it, or add a new one.</i>"
        edit_message(chat_id, msg_id, render_body_text(txt), reply_markup={"inline_keyboard": kb})

    elif data.startswith("nx_addr_"):
        parts = data.split("_")
        srv, cnt = parts[2], parts[3]
        user_states[chat_id] = "wait_nx_addr"
        temp_data[chat_id] = {"msg_id": msg_id, "srv": srv, "cnt": cnt}
        edit_message(chat_id, msg_id, render_body_text(f"📝 Send the new Range for <b>{cnt}</b> (e.g. 88017):"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"nx_cnt_{srv}_{cnt}", "style": "danger"}]]})

    elif data.startswith("nx_dr_"):
        parts = data.split("_")
        srv, cnt, rng = parts[2], parts[3], parts[4]
        if rng in bot_settings["nexa_services"].get(srv, {}).get(cnt, []):
            bot_settings["nexa_services"][srv][cnt].remove(rng)
            save_db()
            answer_callback(call["id"], f"✅ Range {rng} deleted!", show_alert=True)
        handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": f"nx_cnt_{srv}_{cnt}", "id": call["id"]})

    elif data.startswith("nx_del_srv_"):
        srv = data.replace("nx_del_srv_", "")
        if srv in bot_settings["nexa_services"]: del bot_settings["nexa_services"][srv]
        save_db()
        handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": "manage_nexa_srv", "id": call["id"]})

    elif data.startswith("nx_del_cnt_"):
        parts = data.split("_")
        srv, cnt = parts[3], parts[4]
        if cnt in bot_settings["nexa_services"].get(srv, {}): del bot_settings["nexa_services"][srv][cnt]
        save_db()
        handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": f"nx_srv_{srv}", "id": call["id"]})

    elif data == "manage_fj":
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['link']} <b>FORCE JOIN SYSTEM</b>\nManage channels/groups below:"), reply_markup=fj_settings_keyboard())

    elif data == "toggle_fj":
        bot_settings["fj_on"] = not bot_settings["fj_on"]
        save_db()
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['link']} <b>FORCE JOIN SYSTEM</b>\nManage channels/groups below:"), reply_markup=fj_settings_keyboard())

    elif data == "add_fj":
        user_states[chat_id] = "wait_for_add_fj"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 <b>Channel ya Group Add Karein</b>\n\n✅ Bot pehle se channel/group mein admin hona chahiye!\n\nBhejein koi bhi ek:\n• Username: <code>@channelname</code>\n• Public Link: <code>https://t.me/channelname</code>\n• Numeric ID: <code>-1001234567890</code>\n\n🔄 Bot auto-detect karega Channel/Group aur Private/Public!"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_fj", "style": "danger"}]]})

    elif data.startswith("del_fj_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["fj_channels"]):
            removed = bot_settings["fj_channels"][idx]
            info = _get_fj_info(removed)
            del bot_settings["fj_channels"][idx]
            save_db()
            answer_callback(call["id"], f"✅ {info.get('title', 'Item')} deleted!", show_alert=True)
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['link']} <b>FORCE JOIN SYSTEM</b>\nManage channels/groups below:"), reply_markup=fj_settings_keyboard())

    elif data == "manage_admins":
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['user']} <b>ADMIN MANAGEMENT</b>\nManage your bot admins below:"), reply_markup=admin_settings_keyboard())

    elif data == "add_adm":
        user_states[chat_id] = "wait_for_add_adm"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the User ID of the new Admin:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_admins", "style": "danger"}]]})

    elif data.startswith("del_adm_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["admins"]):
            del bot_settings["admins"][idx]
            save_db()
            answer_callback(call["id"], "✅ Admin deleted!", show_alert=True)
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['user']} <b>ADMIN MANAGEMENT</b>\nManage your bot admins below:"), reply_markup=admin_settings_keyboard())

    elif data == "manage_otp_groups":
        edit_message(chat_id, msg_id, render_body_text("🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:"), reply_markup=otp_groups_list_keyboard())

    elif data == "add_fw":
        user_states[chat_id] = "wait_for_add_fw_id"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the Group ID/Username to forward messages to:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_otp_groups", "style": "danger"}]]})

    elif data.startswith("manage_fw_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["fw_groups"]):
            grp_id = bot_settings["fw_groups"][idx]["chat_id"]
            edit_message(chat_id, msg_id, render_body_text(f"🛡 <b>Manage Group:</b> {grp_id}"), reply_markup=specific_fw_group_keyboard(idx))

    elif data.startswith("add_fwbtn_"):
        idx = int(data.split("_")[2])
        user_states[chat_id] = "wait_for_add_fw_btn"
        temp_data[chat_id] = {"msg_id": msg_id, "fw_idx": idx}
        edit_message(chat_id, msg_id, render_body_text("📝 Send Custom Inline Button format:\n<code>Button Text - https://link.com</code>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"manage_fw_{idx}", "style": "danger"}]]})

    elif data.startswith("del_fwbtn_"):
        parts = data.split("_")
        idx, b_idx = int(parts[2]), int(parts[3])
        if 0 <= idx < len(bot_settings["fw_groups"]):
            _group_btns = group_buttons(bot_settings["fw_groups"][idx])
            if 0 <= b_idx < len(_group_btns):
                del _group_btns[b_idx]
                save_db()
                answer_callback(call["id"], "✅ Button deleted!", show_alert=True)
                edit_message(chat_id, msg_id, render_body_text(f"🛡 <b>Manage Group:</b> {bot_settings['fw_groups'][idx]['chat_id']}"), reply_markup=specific_fw_group_keyboard(idx))

    elif data.startswith("del_fw_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["fw_groups"]):
            del bot_settings["fw_groups"][idx]
            save_db()
            answer_callback(call["id"], "✅ Group deleted!", show_alert=True)
            edit_message(chat_id, msg_id, render_body_text("🛡 <b>OTP GROUP MANAGEMENT</b>\nManage settings below:"), reply_markup=otp_groups_list_keyboard())

    elif data == "edit_otp_link":
        user_states[chat_id] = "wait_for_otp_link"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the new OTP Group Link:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_otp_groups", "style": "danger"}]]})

    elif data == "manage_panels":
        api_count = len([p for p in bot_settings["panels"] if p.get("type") == "API Panel"])
        cpt_count = len([p for p in bot_settings["panels"] if p.get("type", "API Panel") == "Auto Captcha Panel"])
        voltx_count = len([p for p in bot_settings["panels"] if p.get("type") == "VoltX Panel"])
        fastx_count = len([p for p in bot_settings["panels"] if p.get("type") == "FastX Panel"])
        stex_count = len([p for p in bot_settings["panels"] if p.get("type") == "Stex Panel"])
        text = f"{PEM['gear']} <b>Panel Management</b>\n\nSelect which type of panel system you want to manage:"
        kb = {"inline_keyboard": [
            [{"text": f"Manage API Panels ({api_count})", "icon_custom_emoji_id": "5336972142066047577", "callback_data": "manage_api_panels", "style": "primary"}],
            [{"text": f"Manage VoltX Panels ({voltx_count})", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "manage_voltx_panels", "style": "success"}],
            [{"text": f"Manage Fastx Panels ({fastx_count})", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "manage_fastx_panels", "style": "success"}],
            [{"text": f"Manage Stex Panels ({stex_count})", "icon_custom_emoji_id": "5420155432272438703", "callback_data": "manage_stex_panels", "style": "success"}],
            [{"text": f"Manage Auto Captcha Panels ({cpt_count})", "icon_custom_emoji_id": "5353022963132174959", "callback_data": "manage_cpt_panels", "style": "success"}],
            [{"text": "Back to System", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "system_settings", "style": "danger"}]
        ]}
        edit_message(chat_id, msg_id, render_body_text(text), reply_markup=kb)

    elif data in ["manage_api_panels", "manage_cpt_panels", "manage_voltx_panels", "manage_fastx_panels", "manage_stex_panels"]:
        if data == "manage_api_panels": p_type = "API Panel"
        elif data == "manage_voltx_panels": p_type = "VoltX Panel"
        elif data == "manage_fastx_panels": p_type = "FastX Panel"
        elif data == "manage_stex_panels": p_type = "Stex Panel"
        else: p_type = "Auto Captcha Panel"
        p_list = [p for p in bot_settings["panels"] if p.get("type", "API Panel") == p_type]
        if p_type == "API Panel": icon = f"{PEM['world']} API"
        elif p_type == "VoltX Panel": icon = "🌐 VoltX"
        elif p_type == "FastX Panel": icon = "⚡ FastX"
        elif p_type == "Stex Panel": icon = "🌐 Stex"
        else: icon = f"{PEM['lock']} Auto Captcha"
        
        text = f"{icon} <b>{p_type}s Management</b>\n\n👀 <b>Active Monitors:</b> {len(p_list)}\n\n🟢 <b>Available Providers:</b>\n"
        for p in p_list:
            status = "Monitoring" if panel_status(p) == 'ON' else "Stopped"
            login_state = p.get('login_status', '')
            if panel_type(p) == 'Auto Captcha Panel':
                conf = f" {login_state}" if login_state else f"{PEM['ok']} Configured"
            elif is_number_api_panel(p):
                conf = f"{PEM['ok']} Configured" if p.get('base_url') else f"{PEM['no']} Not Configured"
            else:
                conf = f"{PEM['ok']} Configured" if p.get('api_url') else f"{PEM['no']} Not Configured"
            text += f"• {panel_name(p)}: {PEM['ok'] if panel_status(p)=='ON' else PEM['no']} {status} | {conf}\n"
        edit_message(chat_id, msg_id, render_body_text(text), reply_markup=typed_panels_list_keyboard(p_type))

    elif data in ["add_api_panel", "add_cpt_panel", "add_voltx_panel", "add_fastx_panel", "add_stex_panel"]:
        user_states[chat_id] = "wait_for_panel_name"
        if data == "add_api_panel": p_type = "api"
        elif data == "add_voltx_panel": p_type = "voltx"
        elif data == "add_fastx_panel": p_type = "fastx"
        elif data == "add_stex_panel": p_type = "stex"
        else: p_type = "logc"
        temp_data[chat_id] = {"msg_id": msg_id, "add_type": p_type}
        if p_type == "api":
            back_cb = "manage_api_panels"
        elif p_type == "voltx":
            back_cb = "manage_voltx_panels"
        elif p_type == "fastx":
            back_cb = "manage_fastx_panels"
        elif p_type == "stex":
            back_cb = "manage_stex_panels"
        else:
            back_cb = "manage_cpt_panels"
        edit_message(chat_id, msg_id, render_body_text("📝 Please send the name of the New Provider:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": back_cb, "style": "danger"}]]})

    elif data.startswith("add_ptype_"):
        pass

    elif data in ["list_del_api", "list_del_cpt", "list_del_voltx", "list_del_fastx", "list_del_stex"]:
        if data == "list_del_api": p_type = "API Panel"
        elif data == "list_del_voltx": p_type = "VoltX Panel"
        elif data == "list_del_fastx": p_type = "FastX Panel"
        elif data == "list_del_stex": p_type = "Stex Panel"
        else: p_type = "Auto Captcha Panel"
        kb = []
        for idx, p in enumerate(bot_settings["panels"]):
            if p.get("type", "API Panel") == p_type:
                kb.append([{"text": f"Delete {panel_name(p)}", "icon_custom_emoji_id": "5420130255174145507", "callback_data": f"do_del_pnl_{idx}", "style": "danger"}])
        if p_type == "API Panel": back_to = "manage_api_panels"
        elif p_type == "VoltX Panel": back_to = "manage_voltx_panels"
        elif p_type == "FastX Panel": back_to = "manage_fastx_panels"
        elif p_type == "Stex Panel": back_to = "manage_stex_panels"
        else: back_to = "manage_cpt_panels"
        kb.append([{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": back_to, "style": "primary"}])
        edit_message(chat_id, msg_id, render_body_text(f"{PEM['trash']} <b>Select a Provider to Delete:</b>"), reply_markup={"inline_keyboard": kb})

    elif data.startswith("do_del_pnl_"):
        idx = int(data.split("_")[3])
        if 0 <= idx < len(bot_settings["panels"]):
            p_type = bot_settings["panels"][idx].get("type", "API Panel")
            del bot_settings["panels"][idx]
            save_db()
            answer_callback(call["id"], "✅ Provider Deleted!", show_alert=True)
            if p_type == "Auto Captcha Panel": back_mgr = "manage_cpt_panels"
            elif p_type == "VoltX Panel": back_mgr = "manage_voltx_panels"
            elif p_type == "FastX Panel": back_mgr = "manage_fastx_panels"
            elif p_type == "Stex Panel": back_mgr = "manage_stex_panels"
            else: back_mgr = "manage_api_panels"
            handle_callback({"message": {"chat": {"id": chat_id}, "message_id": msg_id}, "data": back_mgr, "id": "internal"})

    elif data.startswith("tog_pnl_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["panels"]):
            p = bot_settings["panels"][idx]
            
            new_status = "ON" if panel_status(p) == "OFF" else "OFF"
            p["status"] = new_status
            if new_status == "ON":
                p["needs_warmup"] = True
            save_db()
            
            if p["type"] == "Auto Captcha Panel":
                text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>Login Status:</b> {p.get('login_status', 'Unknown')}\n<b>Login URL:</b> <code>{p.get('login_url', 'None')}</code>\n<b>User:</b> <code>{p.get('username', 'None')}</code>"
            elif is_number_api_panel(p):
                text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>Base URL:</b> <code>{p.get('base_url', 'None')}</code>\n<b>API Key:</b> <code>{p.get('api_key', 'None')}</code>"
            else:
                text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>API URL:</b> <code>{p.get('api_url', 'None')}</code>\n<b>Token:</b> <code>{p.get('token', 'None')}</code>"
            edit_message(chat_id, msg_id, render_body_text(text), reply_markup=panel_config_keyboard(idx))

    elif data.startswith("conf_pnl_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["panels"]):
            p = bot_settings["panels"][idx]
            if p["type"] == "Auto Captcha Panel":
                text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>Login Status:</b> {p.get('login_status', 'Unknown')}\n<b>Login URL:</b> <code>{p.get('login_url', 'None')}</code>\n<b>User:</b> <code>{p.get('username', 'None')}</code>\n<b>Num Col:</b> {p.get('num_col_name')} (Idx: {p.get('num_col_idx')})\n<b>Msg Col:</b> {p.get('msg_col_name')} (Idx: {p.get('msg_col_idx')})"
            elif is_number_api_panel(p):
                api_key_masked = (p.get('api_key', '')[:4] + "****" + p.get('api_key', '')[-4:]) if len(p.get('api_key', '')) > 8 else p.get('api_key', 'None')
                last_at = p.get("last_getnum_at") or 0
                last_ago = "never" if not last_at else f"{int(max(0, time.time() - last_at))}s ago"
                last_raw = str(p.get("last_getnum_raw") or "")[:160]
                last_err = str(p.get("last_getnum_error") or "")[:150]
                last_disp = str(p.get("last_display_error") or "")[:150]
                text = (
                    f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n"
                    f"<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n"
                    f"<b>Base URL:</b> <code>{p.get('base_url', 'None')}</code>\n"
                    f"<b>API Key:</b> <code>{api_key_masked}</code>\n"
                    f"<b>GetNum URL:</b> <code>{p.get('getnum_url', 'Auto')}</code>\n"
                    f"<b>GetMsg URL:</b> <code>{p.get('getmsg_url', 'Auto')}</code>\n"
                    f"<b>Traffic URL:</b> <code>{p.get('traffic_url', 'Auto')}</code>\n"
                    f"\n<b>🧾 LAST GETNUM:</b> {last_ago} · claimed <b>{int(p.get('last_getnum_count', 0) or 0)}</b>\n"
                    f"<code>{html.escape(last_raw) if last_raw else 'no response stored yet'}</code>\n"
                )
                if last_err:
                    text += f"\n<b>⚠️ GetNum error:</b> <code>{html.escape(last_err)}</code>"
                if last_disp:
                    text += f"\n<b>⚠️ Telegram display error:</b> <code>{html.escape(last_disp)}</code>"
            else:
                text = f"⚙️ <b>Configure {panel_name(p)}</b>\n\n<b>Type:</b> {panel_type(p)}\n<b>Status:</b> {'🟢 Monitoring' if panel_status(p) == 'ON' else '🔴 Stopped'}\n<b>API URL:</b> <code>{p.get('api_url', 'None')}</code>\n<b>Token:</b> <code>{p.get('token', 'None')}</code>\n<b>Full API URL:</b> <code>{p.get('full_api_url', 'None')}</code>"
            edit_message(chat_id, msg_id, render_body_text(text), reply_markup=panel_config_keyboard(idx))

    elif data.startswith("set_p_api_"):
        idx = int(data.split("_")[3])
        user_states[chat_id] = "wait_for_p_api"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the API URL for this provider:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_tok_"):
        idx = int(data.split("_")[3])
        user_states[chat_id] = "wait_for_p_tok"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the Token for this provider:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_fapi_"):
        idx = int(data.split("_")[3])
        user_states[chat_id] = "wait_for_p_fapi"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the FULL API URL (Example: http://api.com/get?key=YOUR_TOKEN&start=0):"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_rec_"):
        idx = int(data.split("_")[3])
        user_states[chat_id] = "wait_for_p_rec"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the number of records to fetch (e.g. 10).\nType <code>0</code> for Unlimited:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})


    # ==========================================
    # 🌟 VoltX Panel Edit Callbacks
    # ==========================================
    elif data.startswith("set_p_vbase_"):
        idx = int(data.split("_")[3])
        panel_label = bot_settings["panels"][idx].get("type", "Number API Panel").replace(" Panel", "")
        user_states[chat_id] = "wait_for_voltx_base_url"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        edit_message(chat_id, msg_id, render_body_text(f"🌐 <b>{panel_label} Base URL</b>\n\nSend the Base API URL:\n<i>Example: https://api.2oo9.cloud/XXX/tnevs/@public/api</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_vkey_"):
        idx = int(data.split("_")[3])
        panel_label = bot_settings["panels"][idx].get("type", "Number API Panel").replace(" Panel", "")
        user_states[chat_id] = "wait_for_voltx_api_key"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        edit_message(chat_id, msg_id, render_body_text(f"🔑 <b>{panel_label} API Key</b>\n\nSend your API Key / Token:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_vgetnum_"):
        idx = int(data.split("_")[3])
        panel_label = bot_settings["panels"][idx].get("type", "Number API Panel").replace(" Panel", "")
        user_states[chat_id] = "wait_for_voltx_getnum_url"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        default_suffix = "/api/getnum" if panel_label == "FastX" else "/getnum"
        edit_message(chat_id, msg_id, render_body_text(f"📥 <b>{panel_label} GetNum URL</b>\n\nSend GetNum URL (or leave blank to use auto):\n<i>Default: {{base_url}}{default_suffix}</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_vgetmsg_"):
        idx = int(data.split("_")[3])
        panel_label = bot_settings["panels"][idx].get("type", "Number API Panel").replace(" Panel", "")
        user_states[chat_id] = "wait_for_voltx_getmsg_url"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        default_suffix = "/api/success-otp-info" if panel_label == "FastX" else "/success-otp"
        edit_message(chat_id, msg_id, render_body_text(f"📨 <b>{panel_label} GetMsg URL</b>\n\nSend GetMsg URL (or leave blank to use auto):\n<i>Default: {{base_url}}{default_suffix}</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("set_p_vtraf_"):
        idx = int(data.split("_")[3])
        panel_label = bot_settings["panels"][idx].get("type", "Number API Panel").replace(" Panel", "")
        user_states[chat_id] = "wait_for_voltx_traffic_url"
        temp_data[chat_id] = {"msg_id": msg_id, "p_idx": idx}
        default_suffix = "/api/live-console" if panel_label == "FastX" else "/console"
        edit_message(chat_id, msg_id, render_body_text(f"📊 <b>{panel_label} Traffic URL</b>\n\nSend Traffic URL (or leave blank to use auto):\n<i>Default: {{base_url}}{default_suffix}</i>"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": f"conf_pnl_{idx}", "style": "danger"}]]})

    elif data.startswith("test_p_conn_"):
        idx = int(data.split("_")[3])
        p = bot_settings["panels"][idx]
        wait_msg = send_message(chat_id, render_body_text("⏳ Testing connection. Please wait..."))
        wait_msg_id = wait_msg.get("result", {}).get("message_id") if wait_msg else None
        answer_callback(call["id"])
        
        try:
            parsed = []
            raw_text = ""
            
            if is_number_api_panel(p):
                base_url = p.get("base_url", "").strip()
                api_key = p.get("api_key", "").strip()
                if not base_url or not api_key:
                    if wait_msg_id: delete_message(chat_id, wait_msg_id)
                    send_message(chat_id, render_body_text("❌ Please set Base URL and API Key first!"))
                    return
                getmsg_url = get_number_panel_url(p, "getmsg_url")
                headers_vx = get_number_panel_headers(p)
                try:
                    res_vx = requests.get(getmsg_url, headers=headers_vx, timeout=15)
                    if wait_msg_id: delete_message(chat_id, wait_msg_id)
                    if res_vx.status_code == 200:
                        d = res_vx.json()
                        otp_payload = d.get("data") or {}
                        otps = otp_payload.get("otps", []) if isinstance(otp_payload, dict) else []
                        if isinstance(otps, list) and otps:
                            sample = otps[0]
                            panel_label = p.get("type", "Number API").replace(" Panel", "")
                            sample_message = str(sample.get("message") or sample.get("sms") or "")
                            sample_otp = str(sample.get("otp") or extract_otp_code(sample_message))
                            txt = f"✅ <b>{panel_label} Connection OK!</b>\n\n🔢 OTPs in queue: <b>{len(otps)}</b>\n\n<b>Sample Entry:</b>\n📱 Number: <code>{sample.get('number','?')}</code>\n📝 Message: <code>{html.escape(sample_message[:200])}</code>\n🔐 OTP: <code>{sample_otp}</code>"
                            send_message(chat_id, render_body_text(txt))
                        else:
                            panel_label = p.get("type", "Number API").replace(" Panel", "")
                            send_message(chat_id, render_body_text(f"✅ <b>{panel_label} Connected!</b> No OTPs in queue yet.\n\n<code>{html.escape(str(res_vx.text)[:300])}</code>"))
                    else:
                        panel_label = p.get("type", "Number API").replace(" Panel", "")
                        send_message(chat_id, render_body_text(f"❌ <b>{panel_label} Connection Failed!</b>\nHTTP {res_vx.status_code}\n<code>{html.escape(str(res_vx.text)[:300])}</code>"))
                except Exception as e:
                    if wait_msg_id: delete_message(chat_id, wait_msg_id)
                    panel_label = p.get("type", "Number API").replace(" Panel", "")
                    send_message(chat_id, render_body_text(f"❌ <b>{panel_label} Error:</b> {html.escape(str(e))}"))
                return

            elif p["type"] == "Auto Captcha Panel":
                sess = panel_sessions.get(idx)
                login_url = p.get("login_url", "").strip()
                if not login_url.startswith("http"): login_url = "http://" + login_url
                msg_link = p.get("msg_link", "").strip()
                if not msg_link.startswith("http") and msg_link != "": msg_link = "http://" + msg_link
                check_url = msg_link if msg_link else f"{login_url.split('/login')[0]}/client/SMSCDRStats"

                # Try up to 2 times: once with existing session, once after fresh login
                for attempt in range(2):
                    if not sess:
                        success = attempt_auto_login(p, idx)
                        save_db()
                        if not success:
                            if wait_msg_id: delete_message(chat_id, wait_msg_id)
                            send_message(chat_id, render_body_text(f"❌ <b>Auto Login Failed!</b>\nReason: {html.escape(str(p.get('login_status', 'Unknown')))}"))
                            return
                        sess = panel_sessions.get(idx)
                    try:
                        # 🌟 test connection supports sAjaxSource & HTML table parser
                        parsed, raw_text = fetch_cpt_panel_cdrs(p, sess, check_url)
                        break  # success — exit retry loop
                    except Exception as sess_err:
                        if "Session expired" in str(sess_err) and attempt == 0:
                            # Session expired — clear and re-login on next attempt
                            if idx in panel_sessions: del panel_sessions[idx]
                            sess = None
                            continue
                        raise  # re-raise on second attempt or other errors

            else:
                full_url = p.get("full_api_url", "").strip()
                url = p.get("api_url", "").strip()
                token = p.get("token", "").strip()
                if not full_url and not url:
                    if wait_msg_id: delete_message(chat_id, wait_msg_id)
                    send_message(chat_id, render_body_text("❌ Please Set API URL or Full API URL first!"))
                    return
                
                urls_to_try = []
                if full_url:
                    urls_to_try.append(full_url)
                else:
                    if "{token}" in url or "{key}" in url:
                        urls_to_try.append(url.replace("{token}", token).replace("{key}", token))
                    elif "token=" in url or "key=" in url:
                        urls_to_try.append(url)
                    else:
                        sep = '&' if '?' in url else '?'
                        urls_to_try.append(f"{url}{sep}token={token}")
                        urls_to_try.append(f"{url}{sep}key={token}&start=0")
                        urls_to_try.append(f"{url}{sep}key={token}")
                    
                parsed = []
                raw_text = ""
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
                # 🌟 Zenex Network requires the API key via a "mapikey" header, not a URL param
                zenex_target = full_url or url
                if "zenexnetwork.com" in zenex_target:
                    zenex_key = token
                    if not zenex_key:
                        try:
                            zenex_key = parse_qs(urlparse(zenex_target).query).get('key', [''])[0]
                        except Exception:
                            zenex_key = ""
                    if zenex_key:
                        headers['mapikey'] = zenex_key
                for try_url in urls_to_try:
                    try:
                        res = requests.get(try_url, headers=headers, timeout=10)
                        raw_text = res.text
                        parsed = parse_panel_response(raw_text, p)
                        if parsed:
                            if not full_url and try_url != url and token:
                                p["api_url"] = try_url.replace(token, "{token}")
                                save_db()
                            break
                    except: pass
                 
            if wait_msg_id: delete_message(chat_id, wait_msg_id)
                 
            if parsed:
                txt = f"✅ <b>Connection Successful!</b>\n\n🎯 <b>Parsed Data Sample (Max 3):</b>\n\n"
                
                for i, sample in enumerate(parsed[:3]):
                    num = sample['number']
                    msg = sample['message']
                    otp = sample['otp']
                    
                    detected_app = detect_service(msg)
                    app_name = detected_app if detected_app else p.get("name", "Unknown")
                    app_full_name, prem_app_html = get_service_info_html(app_name, msg)
                    
                    txt += f"<b>{i+1}.</b> {prem_app_html} <b>{app_full_name}</b>\n"
                    txt += f"📱 Number: <code>{num}</code>\n"
                    txt += f"📝 Full Msg: <code>{html.escape(msg)}</code>\n"
                    txt += f"🔐 OTP: <code>{otp}</code>\n"
                    txt += "➖" * 12 + "\n"
                    
                send_message(chat_id, render_body_text(txt))
            else:
                if p["type"] == "Auto Captcha Panel":
                    try:
                        soup = BeautifulSoup(raw_text, 'html.parser')
                        tables = soup.find_all('table')
                        if tables:
                            full_table_data = "🔍 FULL TABLE DATA (A-Z)\n" + "="*50 + "\n\n"
                            for t_idx, table in enumerate(tables):
                                full_table_data += f"--- Table {t_idx+1} ---\n"
                                rows = table.find_all('tr')
                                for r_idx, row in enumerate(rows):
                                    cols = row.find_all(['th', 'td'])
                                    col_texts = [f"[{c_idx+1}] {c.get_text(separator=' ', strip=True)}" for c_idx, c in enumerate(cols)]
                                    full_table_data += f"Row {r_idx+1}: {' | '.join(col_texts)}\n"
                                full_table_data += "\n" + "="*50 + "\n"
                            
                            send_document(chat_id, f"Full_Panel_Data_{idx}.txt", full_table_data.encode('utf-8'))
                            fail_txt = f"⚠️ <b>Connected, but couldn't parse OTP data!</b>\n\n<i>I have sent the complete (A-Z) data of that link in a Text File. Open the file and check the correct Column Number (e.g.: [1], [3]) then update in panel.</i>"
                            send_message(chat_id, render_body_text(fail_txt))
                        else:
                            send_message(chat_id, render_body_text(f"⚠️ <b>Connected, but no HTML Table found!</b>\nMake sure the message link is correct."))
                    except Exception as e:
                        send_message(chat_id, render_body_text(f"❌ <b>Error parsing HTML:</b> {html.escape(str(e))}"))
                else:
                    safe_html = html.escape(str(raw_text)[:300])
                    send_message(chat_id, render_body_text(f"⚠️ <b>Connected, but couldn't find/parse OTP data.</b>\n\n<i>Make sure your API config is correct.</i>\n\nRaw HTML/Data (excerpt):\n<code>{safe_html}...</code>"))
        except Exception as e:
            if wait_msg_id: delete_message(chat_id, wait_msg_id)
            send_message(chat_id, render_body_text(f"❌ <b>Connection Failed!</b>\nError: {html.escape(str(e))}"))

    elif data == "abhi_control":
        if chat_id in user_states: del user_states[chat_id]
        edit_message(chat_id, msg_id, render_body_text("🕹 <b>SHAHADOT X DEV CONTROL PANEL</b>"), reply_markup=abhi_control_keyboard())

    elif data == "abhi_toggle_w":
        bot_settings["withdraw_on"] = not bot_settings["withdraw_on"]
        save_db()
        edit_message(chat_id, msg_id, render_body_text("🕹 <b>SHAHADOT X DEV CONTROL PANEL</b>"), reply_markup=abhi_control_keyboard())

    elif data == "abhi_toggle_prem_emoji":
        bot_settings["premium_emoji_on"] = not bot_settings.get("premium_emoji_on", False)
        save_db()
        status = "✅ ON" if bot_settings["premium_emoji_on"] else "❌ OFF"
        answer_callback(call["id"], f"✨ Premium Emoji {status}", show_alert=True)
        edit_message(chat_id, msg_id, render_body_text("🕹 <b>SHAHADOT X DEV CONTROL PANEL</b>"), reply_markup=abhi_control_keyboard())

    elif data == "manage_w_methods":
        edit_message(chat_id, msg_id, render_body_text("💳 <b>WITHDRAWAL METHODS</b>\n\nManage your withdrawal methods below:"), reply_markup=w_methods_keyboard())

    elif data == "add_wm":
        user_states[chat_id] = "wait_for_add_wm"
        temp_data[chat_id] = {"msg_id": msg_id}
        edit_message(chat_id, msg_id, render_body_text("📝 Send the name of the new Withdrawal Method:"), reply_markup={"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "manage_w_methods", "style": "danger"}]]})

    elif data.startswith("del_wm_"):
        idx = int(data.split("_")[2])
        if 0 <= idx < len(bot_settings["w_methods"]):
            del bot_settings["w_methods"][idx]
            save_db()
            answer_callback(call["id"], "✅ Method deleted!", show_alert=True)
            edit_message(chat_id, msg_id, render_body_text("💳 <b>WITHDRAWAL METHODS</b>\n\nManage your withdrawal methods below:"), reply_markup=w_methods_keyboard())

    elif data == "main_developer":
        dev_msg = render_body_text(
            "━━━━━━━━━━━━━━━━━━━━\n"
            "👨‍💻 <b>MAIN DEVELOPER</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "🆔 <b>Name:</b> SHAHADOT X DEV\n"
            "👤 <b>Username:</b> @shahadotxdev\n\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "📣 <b>Channel:</b> @shahadotX_dev\n"
            "🌐 <b>Facebook:</b> <a href='https://www.facebook.com/61595739159487'>Click Here</a>\n\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "✨ <i>This bot is developed & maintained by SHAHADOT X DEV</i>\n"
            "━━━━━━━━━━━━━━━━━━━━"
        )
        kb = {"inline_keyboard": [
            [{"text": "👤 Profile", "url": "https://t.me/shahadotxdev", "style": "primary"},
             {"text": "📣 Channel", "url": "https://t.me/shahadotX_dev", "style": "success"}],
            [{"text": "🌐 Facebook", "url": "https://www.facebook.com/61595739159487", "style": "primary"}],
            [{"text": "Back", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "abhi_control", "style": "danger"}]
        ]}
        edit_message(chat_id, msg_id, dev_msg, reply_markup=kb)

    elif data == "cor_list":
        if chat_id in user_states: del user_states[chat_id]
        cor = bot_settings.get("country_otp_rewards", {})
        title = f"🌍 <b>COUNTRY OTP REWARDS</b>\n\n📌 Default Reward: <b>{bot_settings.get('otp_reward', 0.1)} USDT</b>\n"
        if cor:
            title += f"✅ Custom Rewards Set: <b>{len(cor)}</b> countries"
        else:
            title += "ℹ️ No custom rewards set yet.\nAdd a country to override the default reward."
        edit_message(chat_id, msg_id, render_body_text(title), reply_markup=country_otp_rewards_keyboard())

    elif data.startswith("cor_add_p"):
        page = int(data.replace("cor_add_p", "") or "0")
        edit_message(chat_id, msg_id, render_body_text("🌍 <b>SELECT COUNTRY</b>\n\nPick a country to set a custom OTP reward:"), reply_markup=cor_add_keyboard(page))

    elif data.startswith("cor_pick_"):
        iso = data.replace("cor_pick_", "")
        country_name = iso
        for _, info in COUNTRY_DB.items():
            if info.get("iso", "").upper() == iso.upper():
                country_name = info.get("name", iso)
                break
        existing = bot_settings.get("country_otp_rewards", {}).get(iso.upper(), "")
        existing_txt = f"\n💰 Current Reward: <b>{existing} USDT</b>" if existing != "" else f"\n💰 Default Reward: <b>{bot_settings.get('otp_reward', 0.1)} USDT</b>"
        user_states[chat_id] = "wait_for_cor_value"
        temp_data[chat_id] = {"msg_id": msg_id, "cor_iso": iso}
        cancel_kb = {"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "cor_list", "style": "danger"}]]}
        edit_message(chat_id, msg_id, render_body_text(
            f"🌍 <b>{get_flag_emoji(iso)} {country_name}</b>{existing_txt}\n\n📝 Send the new OTP reward amount (e.g. <code>0.5</code>):"
        ), reply_markup=cancel_kb)

    elif data.startswith("cor_del_"):
        iso = data.replace("cor_del_", "").upper()
        cor = bot_settings.get("country_otp_rewards", {})
        if iso in cor:
            del cor[iso]
            bot_settings["country_otp_rewards"] = cor
            save_db()
            answer_callback(call["id"], "✅ Removed!", show_alert=True)
        edit_message(chat_id, msg_id, render_body_text(
            f"🌍 <b>COUNTRY OTP REWARDS</b>\n\n📌 Default Reward: <b>{bot_settings.get('otp_reward', 0.1)} USDT</b>"
        ), reply_markup=country_otp_rewards_keyboard())

    elif data.startswith("abhi_"):
        key = data.replace("abhi_", "")
        key_map = {"min_w": "min_withdraw", "otp_r": "otp_reward", "ref_r": "refer_reward", "cool": "cooldown", "num_req": "num_req", "num_share": "num_share", "sup_link": "support_link", "w_group": "w_group"}
        if key in key_map:
            temp_data[chat_id] = {"msg_id": msg_id, "key": key_map[key]}
            user_states[chat_id] = "set_abhi"
            cancel_kb = {"inline_keyboard": [[{"text": "Cancel", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "cancel_abhi_edit", "style": "danger"}]]}
            edit_message(chat_id, msg_id, render_body_text(f"📝 Please send the new value for <code>{key_map[key]}</code>:"), reply_markup=cancel_kb)
            answer_callback(call["id"])

    elif data == "change_service":
        # The current number should no longer remain active after changing the
        # service, so expire it before reusing the same Telegram message.
        expire_previous_number(chat_id)
        if not get_available_services():
            edit_message(chat_id, msg_id, render_body_text(f"{PEM['no']} No numbers or services available!"))
        else:
            txt, markup = get_service_selection_ui()
            edit_message(chat_id, msg_id, txt, reply_markup=markup)

    elif data == "change_country":
        active_session = user_active_sessions.get(chat_id, {})
        service = active_session.get("service")
        if not service:
            answer_callback(call["id"], "❌ The current service could not be identified.", show_alert=True)
            return
        expire_previous_number(chat_id)
        txt, markup = get_country_selection_ui(service)
        edit_message(chat_id, msg_id, txt, reply_markup=markup)

    elif data == "toggle_cc":
        active_session = user_active_sessions.get(chat_id)
        if not active_session:
            answer_callback(call["id"], "❌ This number session has expired.", show_alert=True)
            return

        active_session["remove_cc"] = not active_session.get("remove_cc", False)
        target_msg_id = active_session.get("msg_id", msg_id)
        shown, _disp_error = show_waiting_screen(
            chat_id,
            target_msg_id,
            waiting_sms_keyboard(active_session),
            active_session,
        )
        answer_callback(call["id"], "" if shown else "❌ Could not refresh the message")

    elif data.startswith("g_s_"):
        service = data.split("g_s_", 1)[1]
        txt, markup = get_country_selection_ui(service)
        edit_message(chat_id, msg_id, txt, reply_markup=markup)

    elif data.startswith("g_c_") or data.startswith("c_n_"):
        # 1. Global cooldown check (for all number methods)
        now = time.time()
        if now - user_cooldowns.get(chat_id, 0) < bot_settings["cooldown"]:
            answer_callback(call["id"], f"⌛ Please wait {int(bot_settings['cooldown'] - (now - user_cooldowns.get(chat_id, 0)))}s.", show_alert=True)
            return
        
        # Cooldown update
        user_cooldowns[chat_id] = now
        
        # Clean the previous session, but keep its message visible until the
        # new screen has really been rendered.
        previous_msg_id = expire_previous_number(chat_id, mark_expired=False)

        # If coming from search number
        if data.startswith("c_n_s_"):
            parts_s = data.split("_")
            query = parts_s[3]
            service_from_cb = parts_s[4] if len(parts_s) > 4 else None
            
            allowed_countries = bot_settings.get("search_countries", [])
            if allowed_countries and not any(query.startswith(c) for c in allowed_countries):
                answer_callback(call["id"], "❌ This country code is not allowed for search!", show_alert=True)
                return
                
            edit_message(chat_id, msg_id, render_body_text("⌛ <i>Processing... Finding Number...</i>"))
            wait_msg_id = msg_id
            
            found_indices = []
            for b_id, b_data in number_batches.items():
                for idx, n_obj in enumerate(b_data["numbers"]):
                    if n_obj["num"].replace("+", "").startswith(query) and chat_id not in n_obj.get("used_by", []):
                        found_indices.append((b_id, idx))

            # Recycle: if no available numbers, reset all matching numbers
            if not found_indices:
                has_matching = False
                for b_id, b_data in number_batches.items():
                    for n_obj in b_data["numbers"]:
                        if n_obj["num"].replace("+", "").startswith(query):
                            has_matching = True
                            n_obj["shares"] = 0
                            n_obj["used_by"] = []
                if has_matching:
                    for b_id, b_data in number_batches.items():
                        for idx, n_obj in enumerate(b_data["numbers"]):
                            if n_obj["num"].replace("+", "").startswith(query):
                                found_indices.append((b_id, idx))

            fetched_nums = []
            if not found_indices:
                nexa_found = False
                nexa_keys = bot_settings.get("nexa_keys", [])
                search_range = query + ("X" * (11 - len(query))) if len(query) < 11 else query
                
                def _fetch_one_nexa(api_key):
                    try:
                        headers = {"X-API-Key": api_key}
                        res = requests.post(f"{NEXA_BASE_URL}/api/v1/numbers/get", json={"range": search_range, "format": "normal"}, headers=headers, timeout=10)
                        d = res.json()
                        if d.get("success") and d.get("number"):
                            return api_key, str(d["number"]).replace("+", ""), d.get("number_id")
                    except: pass
                    return None

                num_needed = bot_settings.get("num_req", 1)
                keys_to_try = (nexa_keys * num_needed)[:num_needed * max(1, len(nexa_keys))]
                with ThreadPoolExecutor(max_workers=min(num_needed, 5)) as ex:
                    futures = [ex.submit(_fetch_one_nexa, k) for k in keys_to_try]
                    for fut in futures:
                        result_n = fut.result()
                        if result_n and len(fetched_nums) < num_needed:
                            api_key_used, num_str, number_id = result_n
                            if num_str not in fetched_nums:
                                fetched_nums.append(num_str)
                                nexa_assigned_numbers[num_str] = chat_id
                                nexa_found = True
                                total_assigned_stats += 1
                                if number_id:
                                    threading.Thread(target=poll_otp_with_status, args=(number_id, num_str, chat_id, api_key_used), daemon=True).start()
                        
                if not nexa_found:
                    answer_callback(call["id"], "❌ Number out of stock!", show_alert=True)
                    delete_message(chat_id, wait_msg_id)
                    return
                save_db()
            else:
                random.shuffle(found_indices)
                for b_id, idx in found_indices:
                    if len(fetched_nums) >= bot_settings.get("num_req", 1): break
                    n_obj = number_batches[b_id]["numbers"][idx]
                    num_str = n_obj["num"]
                    fetched_nums.append(num_str)
                    n_obj["shares"] += 1
                    n_obj["used_by"].append(chat_id)
                    total_assigned_stats += 1
                    if n_obj["shares"] >= bot_settings.get("num_share", 1):
                        if num_str not in used_numbers_list:
                            used_numbers_list.append(num_str)
                save_db()
                
            kb = []
            if service_from_cb:
                app_full_name, _ = get_service_info_html(service_from_cb)
                emoji_id_srv = "5337302974806922068"
                for app_key, app_data in bot_settings.get("premium_apps", {}).items():
                    if service_from_cb.upper() == app_key or service_from_cb.upper() in app_key or app_key in service_from_cb.upper():
                        if "id" in app_data: emoji_id_srv = app_data["id"]; break
                kb.append([{"text": f"{app_full_name}", "icon_custom_emoji_id": emoji_id_srv, "callback_data": "ignore", "style": "success"}])

            flags_db = bot_settings.get("premium_flags", {})
            for num in fetched_nums:
                _, iso = get_flag_and_code(num)
                display_num = f"+{num}" if not str(num).startswith("+") else str(num)
                emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID
                for flag_code, flag_data in flags_db.items():
                    if iso == flag_data.get("iso"):
                        if "id" in flag_data: emoji_id = flag_data["id"]; break
                kb.append([{"text": f"{display_num}", "icon_custom_emoji_id": emoji_id, "copy_text": {"text": display_num}, "style": "primary"}])
            kb.append(waiting_sms_cc_button())
            kb.append([{"text": "Change Number", "icon_custom_emoji_id": "5420155432272438703", "callback_data": f"c_n_s_{query}", "style": "danger"}] + otp_group_row())
            kb.extend(waiting_sms_navigation_buttons())
            
            c_btns = bot_settings["custom_messages"].get("search_number", {}).get("buttons", [])
            for c_b in c_btns: 
                b_copy = c_b.copy()
                if "style" not in b_copy: b_copy["style"] = "primary"
                kb.append([b_copy])
            kb.append([{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}])
            
            edit_message(chat_id, wait_msg_id, render_body_text("╔═══════════════╗\n║ 💬 Waiting For SMS...\n╚═══════════════╝"), reply_markup={"inline_keyboard": kb})
            user_active_sessions[chat_id] = {
                "msg_id": wait_msg_id,
                "nums": fetched_nums,
                "service": service_from_cb,
                "country": None,
                "remove_cc": False,
                "change_callback": f"c_n_s_{query}",
                "custom_menu": "search_number",
            }
            return

        # If coming from upload or service. Split from the right so service
        # names containing underscores still resolve correctly.
        payload = data[4:]
        selected_panel_idx = None
        selected_source = ""
        if "__" in payload:
            payload, source_marker = payload.rsplit("__", 1)
            if source_marker.startswith("P"):
                try:
                    selected_panel_idx = int(source_marker[1:])
                    selected_source = "panel"
                except ValueError:
                    selected_panel_idx = None
            elif source_marker.startswith("S"):
                selected_source = source_marker[1:]
        try:
            service, country = payload.rsplit("_", 1)
        except ValueError:
            answer_callback(call["id"], "❌ Invalid service/country selection.", show_alert=True)
            return
        source_callback_suffix = ""
        if selected_panel_idx is not None:
            source_callback_suffix = f"__P{selected_panel_idx}"
        elif selected_source:
            source_callback_suffix = f"__S{selected_source}"

        available_indices = []
        # Only a Local Stock button may use local numbers. A panel-specific
        # country button must never silently fall back to another source.
        if selected_panel_idx is None and selected_source not in {"nexa", "legacy_voltx"}:
            for b_id, b_data in number_batches.items():
                if service_names_equal(b_data.get("service"), service) and country_names_equal(b_data.get("country"), country):
                    for idx, n_obj in enumerate(b_data["numbers"]):
                        if chat_id not in n_obj.get("used_by", []):
                            available_indices.append((b_id, idx))

        # Recycle: if no available numbers, reset all matching numbers
        if not available_indices:
            has_matching = False
            if selected_panel_idx is None and selected_source not in {"nexa", "legacy_voltx"}:
                for b_id, b_data in number_batches.items():
                    if service_names_equal(b_data.get("service"), service) and country_names_equal(b_data.get("country"), country):
                        for n_obj in b_data["numbers"]:
                            has_matching = True
                            n_obj["shares"] = 0
                            n_obj["used_by"] = []
            if has_matching:
                for b_id, b_data in number_batches.items():
                    if service_names_equal(b_data.get("service"), service) and country_names_equal(b_data.get("country"), country):
                        for idx, n_obj in enumerate(b_data["numbers"]):
                            available_indices.append((b_id, idx))

        # If a panel-specific country was selected, use only that panel.
        # Never fall through to Nexa, another number panel, or local stock.
        if not available_indices:
            nexa_srv_data = []
            voltx_srv_data = []
            vx_panel = None

            if selected_panel_idx is not None:
                vx_panel = get_number_panel_for_source(selected_panel_idx)
                if vx_panel:
                    voltx_srv_data = get_panel_ranges(vx_panel, service, country)
            elif selected_source == "legacy_voltx":
                voltx_srv_data = get_service_country_ranges(
                    bot_settings.get("voltx_services", {}),
                    service,
                    country,
                )
                vx_panel = next(
                    (
                        p for p in bot_settings.get("panels", [])
                        if p.get("type") == "VoltX Panel"
                    ),
                    None,
                )
            elif selected_source == "local":
                # Local Stock was explicitly selected; do not switch source.
                pass
            else:
                nexa_srv_data = get_service_country_ranges(
                    bot_settings.get("nexa_services", {}),
                    service,
                    country,
                )
                if nexa_srv_data:
                    random_range = random.choice(nexa_srv_data)
                    # Redirect to Nexa Search Flow (Reset cooldown to prevent block)
                    user_cooldowns[chat_id] = 0
                    handle_callback({
                        "message": call["message"],
                        "data": f"c_n_s_{random_range}_{service}",
                        "id": call["id"],
                    })
                    return

                # Legacy global VoltX data is supported only for old databases.
                voltx_srv_data = get_service_country_ranges(
                    bot_settings.get("voltx_services", {}),
                    service,
                    country,
                )
                vx_panel = next(
                    (
                        p for p in bot_settings.get("panels", [])
                        if p.get("type") == "VoltX Panel"
                        and p.get("status") == "ON"
                        and p.get("base_url")
                        and p.get("api_key")
                    ),
                    None,
                )

            if selected_panel_idx is not None and not voltx_srv_data:
                answer_callback(call["id"], "❌ No range is configured for this selected panel.", show_alert=True)
                if data.startswith("c_n_"):
                    delete_message(chat_id, msg_id)
                return

            if (
                selected_panel_idx is None
                and selected_source in {"local", "nexa", "legacy_voltx"}
                and not voltx_srv_data
                and not available_indices
            ):
                answer_callback(call["id"], "❌ Number out of stock for this selected source.", show_alert=True)
                if data.startswith("c_n_"):
                    delete_message(chat_id, msg_id)
                return

            if voltx_srv_data and len(voltx_srv_data) > 0:
                if not vx_panel:
                    answer_callback(call["id"], "❌ Selected panel is not configured or is OFF.", show_alert=True)
                    if data.startswith("c_n_"): delete_message(chat_id, msg_id)
                    return
                if vx_panel:
                    edit_message(chat_id, msg_id, render_body_text("⌛ <i>Processing... Getting Numbers...</i>"))
                    num_to_fetch = bot_settings.get("num_req", 1)
                    vx_fetched, last_err = fetch_numbers_from_number_panel(
                        vx_panel,
                        voltx_srv_data,
                        num_to_fetch,
                    )
                    for num_str in vx_fetched:
                        voltx_assigned_numbers[num_str] = chat_id
                        total_assigned_stats += 1
                    while len(voltx_assigned_numbers) > 5000:
                        voltx_assigned_numbers.pop(next(iter(voltx_assigned_numbers)))

                    if vx_fetched:
                        save_db()
                        app_full_name, _ = get_service_info_html(service)
                        emoji_id_srv = "5337302974806922068"
                        for app_key_s, app_data_s in bot_settings.get("premium_apps", {}).items():
                            if service.upper() == app_key_s or service.upper() in app_key_s or app_key_s in service.upper():
                                if "id" in app_data_s: emoji_id_srv = app_data_s["id"]; break
                        flags_db = bot_settings.get("premium_flags", {})
                        kb = [[{"text": f"{app_full_name}", "icon_custom_emoji_id": emoji_id_srv, "callback_data": "ignore", "style": "success"}]]
                        for num_str in vx_fetched:
                            display_num = f"+{num_str}" if not num_str.startswith("+") else num_str
                            _, iso = get_flag_and_code(num_str)
                            emoji_id_flag = DEFAULT_FLAG_CUSTOM_EMOJI_ID
                            for flag_code, flag_data in flags_db.items():
                                if iso == flag_data.get("iso"):
                                    if "id" in flag_data: emoji_id_flag = flag_data["id"]; break
                            kb.append([{"text": f"{display_num}", "icon_custom_emoji_id": emoji_id_flag, "copy_text": {"text": display_num}, "style": "primary"}])
                        kb.extend(waiting_action_rows(
                            f"c_n_{service}_{country}{source_callback_suffix}",
                            custom_menu="get_number",
                        ))
                        shown, disp_error = show_waiting_screen(chat_id, msg_id, kb, {
                            "nums": vx_fetched,
                            "service": service,
                            "country": country,
                            "remove_cc": False,
                            "change_callback": f"c_n_{service}_{country}{source_callback_suffix}",
                            "custom_menu": "get_number",
                            "panel": str(vx_panel.get("name") or "") if isinstance(vx_panel, dict) else "",
                        }, panel=vx_panel if isinstance(vx_panel, dict) else None)
                        if shown:
                            _expire_old_screen(chat_id, previous_msg_id)
                            print(f"✅ Panel number shown to {chat_id}: {', '.join(vx_fetched)} ({vx_panel.get('name') if isinstance(vx_panel, dict) else 'panel'})")
                        else:
                            answer_callback(call["id"], f"❌ Telegram error: {disp_error[:120]}", show_alert=True)
                        return  # number claimed by panel — never fall through to delete
                    else:
                        err_text = f"❌ {str(last_err)[:150]}" if last_err else "❌ Number out of stock!"
                        answer_callback(call["id"], err_text, show_alert=True)
                        if data.startswith("c_n_"): delete_message(chat_id, msg_id)
                        else: edit_message(chat_id, msg_id, render_body_text("❌ <b>Number out of stock!</b>\nTry again later."), reply_markup={"inline_keyboard": [[{"text": "Close", "icon_custom_emoji_id": "5420130255174145507", "callback_data": "close_msg", "style": "danger"}]]})
            if data.startswith("c_n_"): delete_message(chat_id, msg_id)
            return

        random.shuffle(available_indices)
        
        fetched_nums = []
        for b_id, idx in available_indices:
            if len(fetched_nums) >= bot_settings["num_req"]: break
            n_obj = number_batches[b_id]["numbers"][idx]
            
            fetched_nums.append(n_obj["num"])
            n_obj["shares"] += 1
            n_obj["used_by"].append(chat_id)
            total_assigned_stats += 1
            
            if n_obj["shares"] >= bot_settings.get("num_share", 1):
                if n_obj["num"] not in used_numbers_list:
                    used_numbers_list.append(n_obj["num"])
        save_db()

        if not fetched_nums:
            answer_callback(call["id"], "❌ You have already taken all numbers or stock is empty!", show_alert=True)
            if data.startswith("c_n_"): delete_message(chat_id, msg_id)
            return

        app_full_name, _ = get_service_info_html(service)
        emoji_id = "5337302974806922068"
        apps_db = bot_settings.get("premium_apps", {})
        for app_key, app_data in apps_db.items():
            if service.upper() == app_key or service.upper() in app_key or app_key in service.upper():
                if "id" in app_data:
                    emoji_id = app_data["id"]
                    break
        kb = [[{"text": f"{app_full_name}", "icon_custom_emoji_id": emoji_id, "callback_data": "ignore", "style": "success"}]]
        
        flags_db = bot_settings.get("premium_flags", {})
        for num in fetched_nums:
            _, iso = get_flag_and_code(num)
            display_num = f"+{num}" if not num.startswith("+") else num
            
            emoji_id = DEFAULT_FLAG_CUSTOM_EMOJI_ID  # 🚩 default flag from the pack
            for flag_code, flag_data in flags_db.items():
                if iso == flag_data.get("iso"):
                    if "id" in flag_data: emoji_id = flag_data["id"]
                    break
            kb.append([{"text": f"{display_num}", "icon_custom_emoji_id": emoji_id, "copy_text": {"text": display_num}, "style": "primary"}])
            
        kb.extend(waiting_action_rows(
            f"c_n_{service}_{country}{source_callback_suffix}",
            custom_menu="get_number",
        ))
        
        shown, disp_error = show_waiting_screen(chat_id, msg_id, kb, {
            "nums": fetched_nums,
            "service": service,
            "country": country,
            "remove_cc": False,
            "change_callback": f"c_n_{service}_{country}{source_callback_suffix}",
            "custom_menu": "get_number",
        })
        if shown:
            _expire_old_screen(chat_id, previous_msg_id)
        else:
            answer_callback(call["id"], f"❌ Telegram error: {disp_error[:120]}", show_alert=True)

    elif data.startswith("wapp_") or data.startswith("wrej_"):
        # Admin check (need to check User ID)
        user_id_clicked = call.get("from", {}).get("id", chat_id)
        if not is_admin(user_id_clicked):
            answer_callback(call["id"], "🚫 Only Bot Admins can process withdrawals!", show_alert=True)
            return

        action = "APPROVE" if data.startswith("wapp_") else "REJECT"
        req_id = data.replace("wapp_", "").replace("wrej_", "")

        ok, message, next_id = process_withdrawal_action(req_id, action, user_id_clicked)
        plain_message = message.replace("<b>", "").replace("</b>", "")
        if not ok:
            answer_callback(call["id"], plain_message, show_alert=True)
            return

        answer_callback(call["id"], plain_message, show_alert=True)
        # Keep the notification card readable, then continue the queue in the same
        # message so the admin can review the next request immediately.
        try:
            status_word = "APPROVED" if action == "APPROVE" else "REJECTED"
            edit_message(chat_id, msg_id, render_body_text(
                f"{PEM['money']} <b>WITHDRAWAL {status_word}</b>\n" + "\u2501" * 16 +
                f"\n{message}\n🧾 <code>{html.escape(str(req_id))}</code>"
            ), reply_markup={"inline_keyboard": [
                [{"text": f"⏭ Next pending ({len(pending_withdrawal_ids())})", "icon_custom_emoji_id": "5267490665117275176", "callback_data": "wd_pending", "style": "success"}],
            ]})
        except Exception:
            pass

# ==========================================
# Polling Loop
# ==========================================
def poll_otp_with_status(number_id, num_str, owner_id, api_key):
    headers = {"X-API-Key": api_key}
    for _ in range(150): # 150 * 4 seconds = 10 Minutes Polling
        try:
            res = requests.get(f"{NEXA_BASE_URL}/api/v1/numbers/{number_id}/sms", headers=headers, timeout=10)
            data = res.json()
            if data.get("success") and data.get("otp"):
                otp = str(data["otp"])
                msg_text = data.get("message", f"Your code is {otp}")
                
                # 🌟 Fix to find OTP with dash or large OTP from full message
                extracted_otp = extract_otp_code(msg_text)
                if extracted_otp and len(extracted_otp) > len(otp):
                    otp = extracted_otp
                    
                # 🌟 Fix to detect service/app from full message
                app_name = data.get("service", "Nexa Service")
                detected_app = detect_service(msg_text)
                if detected_app:
                    app_name = detected_app
                
                unique_id = f"POLL_{number_id}_{otp}"
                if unique_id not in processed_otps:
                    _track_processed_otp(unique_id)

                    char, iso = get_flag_and_code(num_str)
                    app_full_name, prem_app_html = get_service_info_html(app_name, msg_text)
                    
                    global recent_traffic
                    current_time = time.time()
                    recent_traffic = [t for t in recent_traffic if current_time - t.get("time", 0) <= 3600]
                    recent_traffic.append({"service": app_full_name, "iso": iso, "flag": char, "number": num_str, "time": current_time})
                    save_local_db()
                    
                    display_num = f"+{num_str}" if not str(num_str).startswith("+") else str(num_str)
                    masked = mask_number(display_num, user_id=owner_id)
                    lang = detect_language(msg_text)
                    
                    send_otp_to_groups(
                        num_str, otp, app_full_name, lang, prem_app_html,
                        display_num, panel_name="Nexa poll")

                    inbox_msg = render_body_text(format_otp_display(
                        display_num, app_full_name, lang, masked=False,
                        prem_html=prem_app_html, otp=otp, for_group=False))
                    inbox_kb = [[{"text": f"{otp}", "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": otp}, "style": "success"}]]
                    
                    reward = get_otp_reward_for_country(iso)
                    if reward > 0:
                        update_balance(owner_id, reward)
                        inbox_kb.append([{"text": f"Added {reward} USDT", "icon_custom_emoji_id": "5420396762189831222", "callback_data": "ignore", "style": "primary"}])
                    
                    send_message(owner_id, inbox_msg, reply_markup={"inline_keyboard": inbox_kb})
                    
                    _increment_local_user(owner_id, "total_otps", 1)
                    try:
                        clean_poll_num = str(num_str).replace("+", "").replace(" ", "").replace("-", "").strip()
                        _track_otp_received(clean_poll_num)
                    except: pass
                break
        except: pass
        time.sleep(4)

def global_sms_listener():
    global processed_otps, recent_traffic, nexa_assigned_numbers, nexa_warmup_done
    first_run = True
    while True:
        try:
            nexa_keys = bot_settings.get("nexa_keys", [])
            for api_key in nexa_keys:
                try:
                    headers = {"X-API-Key": api_key}
                    try:
                        res = requests.get(f"{NEXA_BASE_URL}/api/v1/sms/latest", headers=headers, timeout=10)
                        data = res.json()
                    except:
                        res = requests.get(f"{NEXA_BASE_URL}/api/v1/console/logs?limit=20", headers=headers, timeout=10)
                        data = res.json()
                    if data.get("success") and "data" in data:
                        for item in data["data"]:
                            num = str(item.get("number", "")).replace("+", "")
                            msg_text = str(item.get("sms", ""))
                            
                            # 🌟 Fix to detect service/app from full message
                            app_name = item.get("app_name", "Unknown")
                            detected_app = detect_service(msg_text)
                            if detected_app:
                                app_name = detected_app
                                
                            otp = extract_otp_code(msg_text) or "CODE"
                            unique_id = f"NEXA_{num}_{item.get('id', otp)}"
                            
                            if unique_id not in processed_otps and num:
                                _track_processed_otp(unique_id)
                                
                                # Warmup: first run me skip karo
                                if first_run:
                                    continue
                                
                                char, iso = get_flag_and_code(num)
                                app_full_name, prem_app_html = get_service_info_html(app_name, msg_text)
                                current_time = time.time()
                                
                                recent_traffic = [t for t in recent_traffic if current_time - t.get("time", 0) <= 3600]
                                recent_traffic.append({"service": app_full_name, "iso": iso, "flag": char, "number": num, "time": current_time})
                                save_local_db()
                                
                                display_num = f"+{num}" if not str(num).startswith("+") else str(num)
                                lang = detect_language(msg_text)
                                
                                owner_ids = find_otp_owners(num)
                                owner_id = owner_ids[0] if owner_ids else None
                                
                                masked = mask_number(display_num, user_id=owner_id)
                                
                                send_otp_to_groups(
                                    num, otp, app_full_name, lang, prem_app_html,
                                    display_num, panel_name="Nexa listener")
                                        
                                if owner_id:
                                    inbox_msg = render_body_text(format_otp_display(
                                        display_num, app_full_name, lang, masked=False,
                                        prem_html=prem_app_html, otp=otp, for_group=False))
                                    inbox_kb = [[{"text": f"{otp}", "icon_custom_emoji_id": "5353022963132174959", "copy_text": {"text": otp}, "style": "success"}]]
                                    
                                    reward = get_otp_reward_for_country(iso)
                                    if reward > 0:
                                        update_balance(owner_id, reward)
                                        inbox_kb.append([{"text": f"Added {reward} USDT", "icon_custom_emoji_id": "5420396762189831222", "callback_data": "ignore", "style": "primary"}])
                                    
                                    send_message(owner_id, inbox_msg, reply_markup={"inline_keyboard": inbox_kb})
                                    
                                    _increment_local_user(owner_id, "total_otps", 1)
                except: continue
        except: pass
        if first_run:
            first_run = False
            nexa_warmup_done = True
            print("🧹 Nexa warmup done — old OTPs skipped, now processing new ones only.")
        time.sleep(5)

def flush_old_updates():
    """Skip all pending Telegram updates so old messages are not reprocessed on restart."""
    try:
        res = api_call("getUpdates?offset=-1&timeout=0")
        if res and "result" in res and res["result"]:
            last_id = res["result"][-1]["update_id"]
            api_call(f"getUpdates?offset={last_id + 1}&timeout=0")
            print(f"🧹 Flushed old Telegram updates (last_id={last_id})")
        else:
            print("🧹 No pending Telegram updates to flush.")
    except Exception as e:
        print(f"⚠️ Could not flush old updates: {e}")

# ==========================================
# Test Simulation Engine
# ==========================================

def _sim_generate_fake_number(dial_code):
    """Return a plausible fake number: dial_code + 8-9 random digits."""
    sub_len = random.randint(8, 9)
    sub = "".join([str(random.randint(0, 9)) for _ in range(sub_len)])
    if sub[0] == "0":
        sub = str(random.randint(1, 9)) + sub[1:]
    return str(dial_code) + sub

def _is_otp_template(s):
    """Return True if s looks like an OTP pattern (digits + optional separators like -)."""
    if len(s) < 4:
        return False
    if not s[0].isdigit() or not s[-1].isdigit():
        return False
    return all(c.isdigit() or c in '-. ' for c in s)

def _parse_otp_template(template):
    """Decompose an OTP template string into parts."""
    parts = []
    run = 0
    for ch in template:
        if ch.isdigit():
            run += 1
        else:
            if run:
                parts.append(('digits', run))
                run = 0
            parts.append(('sep', ch))
    if run:
        parts.append(('digits', run))
    return parts

def _sim_generate_fake_otp(otp_template_parts=None):
    """Return a random OTP matching the template, or plain 6-digit."""
    if not otp_template_parts:
        return str(random.randint(100000, 999999))
    result = ""
    for ptype, pval in otp_template_parts:
        if ptype == 'digits':
            digits = ""
            for i in range(pval):
                digits += str(random.randint(1 if i == 0 and not result else 0, 9))
            result += digits
        else:
            result += pval
    return result

def _sim_build_minute_schedule(total_messages=2880, total_minutes=1440):
    """Randomly assign total_messages to total_minutes slots."""
    schedule = [0] * total_minutes
    for _ in range(total_messages):
        schedule[random.randint(0, total_minutes - 1)] += 1
    return schedule

def run_test_simulation(sim_id):
    """
    Background thread: sends 2,880 fake OTP messages distributed randomly
    over 1,440 minutes (24 hours) to all configured fw_groups.
    Stops immediately when the stop_event is set.
    """
    global active_test_simulations, recent_traffic

    sim = active_test_simulations.get(sim_id)
    if not sim:
        return

    flag               = sim["flag"]
    iso                = sim["iso"]
    platform           = sim["platform"]
    dial_code          = sim["dial_code"]
    lang               = sim["lang"]
    otp_template_parts = sim.get("otp_template_parts")
    stop_ev            = sim["stop_event"]

    sim["running"] = True
    schedule = _sim_build_minute_schedule(2880, 1440)
    app_full_name, prem_app_html = get_service_info_html(platform)

    for minute_idx, msg_count in enumerate(schedule):
        if stop_ev.is_set():
            break
        for _ in range(msg_count):
            if stop_ev.is_set():
                break
            try:
                fake_num = _sim_generate_fake_number(dial_code)
                fake_otp = _sim_generate_fake_otp(otp_template_parts)
                display_num = f"+{fake_num}"

                sim_lang = detect_language(fake_otp)

                current_time = time.time()
                recent_traffic[:] = [
                    t for t in recent_traffic if current_time - t.get("time", 0) <= 3600
                ]
                recent_traffic.append({
                    "service": app_full_name,
                    "iso": iso,
                    "flag": flag,
                    "number": fake_num,
                    "time": current_time,
                })

                # Same delivery path as real OTPs -> the selected style is used.
                send_otp_to_groups(
                    fake_num, fake_otp, app_full_name, sim_lang, prem_app_html,
                    display_num, panel_name="Test simulation")

                sim["total_sent"] = sim.get("total_sent", 0) + 1

            except Exception:
                pass

        if not stop_ev.is_set():
            stop_ev.wait(timeout=60)

    sim["running"] = False


def _report_handler_error(chat_id, is_callback=False, callback_id=None):
    """Tell the user something went wrong instead of dying silently."""
    try:
        if is_callback and callback_id:
            answer_callback(callback_id, "⚠️ Something went wrong — please try again.", show_alert=True)
    except Exception:
        pass
    try:
        if chat_id:
            send_message(chat_id, render_body_text(
                "⚠️ <b>Something went wrong.</b>\n\n"
                "Session গুলিয়ে গিয়েছিল — আবার শুরু করুন। /start চাপুন।"
            ), reply_markup=main_menu(chat_id))
    except Exception:
        pass


def _safe_process(handler, payload, is_callback=False):
    """Run one update, log any error, reset that chat's state and keep the bot alive."""
    chat_id = None
    callback_id = None
    try:
        if isinstance(payload, dict):
            if is_callback:
                callback_id = payload.get("id")
                message = payload.get("message") or payload.get("channel_post") or {}
                chat_id = (message.get("chat") or {}).get("id") or (payload.get("from") or {}).get("id")
            else:
                chat_id = (payload.get("chat") or {}).get("id") or (payload.get("from") or {}).get("id")
        handler(payload)
    except Exception:
        print("💥 Handler crashed — recovering:")
        traceback.print_exc()
        try:
            if chat_id in user_states:
                del user_states[chat_id]
            if chat_id in temp_data:
                del temp_data[chat_id]
        except Exception:
            pass
        _report_handler_error(chat_id, is_callback=is_callback, callback_id=callback_id)


def main():
    global BOT_USERNAME
    res = api_call("getMe")
    if res.get("ok"): BOT_USERNAME = res["result"]["username"]
    print(f"🤖 Bot is starting... @{BOT_USERNAME}")
    
    # ♻️ Rebuild the pending withdrawal queue from the JSON DB (survives restarts)
    rebuild_pending_withdrawals()

    # 🧹 Flush old updates BEFORE starting background threads
    flush_old_updates()
    
    threading.Thread(target=panel_monitor_thread, daemon=True).start()
    threading.Thread(target=global_sms_listener, daemon=True).start()
    print("📡 Background APIs & Global SMS Listener Started!")
    
    # 🌟 PRO-LEVEL FAST SYSTEM: 500 Workers Pool
    executor = ThreadPoolExecutor(max_workers=500)
    
    offset = None
    while True:
        try:
            updates = api_call(f"getUpdates?timeout=50&offset={offset}")
            if updates and "result" in updates:
                for update in updates["result"]:
                    offset = update["update_id"] + 1
                    if "message" in update:
                        executor.submit(_safe_process, handle_message, update["message"])
                    elif "callback_query" in update:
                        executor.submit(_safe_process, handle_callback, update["callback_query"], True)
        except Exception as e:
            time.sleep(2)

# ==========================================
# 🔐 License / Permission Gate (build r18)
# ==========================================
# The permission file on GitHub must contain either "yes" or "no".
#   yes -> the bot keeps running (checked again after every interval)
#   no  -> console shows the admin contacts and the bot shuts down immediately
LICENSE_URL = (
    "https://raw.githubusercontent.com/AriyanAhamedAri/Permission-only/refs/heads/main/permission.txt"
)
# Backup link: tried only when the first one cannot be read (both are public,
# so neither of them can expire like a private-repo "?token=" link).
LICENSE_URL_FALLBACK = (
    "https://raw.githubusercontent.com/AriyanAhamedAri/Number-Bot/refs/heads/main/permission.txt"
)
LICENSE_CONTACTS = {
    "facebook": "https://www.facebook.com/61595739159487",
    "whatsapp": "+8801852548237",
    "telegram": "https://t.me/shahadotxdev",
}
try:
    LICENSE_CHECK_INTERVAL = 24.0 * 3600.0
except Exception:
    LICENSE_CHECK_INTERVAL = 24 * 3600.0
LICENSE_TIMEOUT = 12
LICENSE_STATE = {
    "status": "unknown",   # yes | no | error
    "raw": "",
    "error": "",
    "source": "",
    "checked_at": 0.0,
}
LICENSE_BOX_WIDTH = 62


def _console_write(text=""):
    """print() that never dies on old Windows code pages."""
    try:
        print(text, flush=True)
    except UnicodeEncodeError:
        try:
            enc = getattr(sys.stdout, "encoding", None) or "ascii"
            print(str(text).encode(enc, "replace").decode(enc, "replace"), flush=True)
        except Exception:
            print(str(text).encode("ascii", "replace").decode("ascii"), flush=True)
    except Exception:
        pass


def _clear_console():
    """Wipe everything that was printed before (old SMS/text lines go away)."""
    try:
        if os.name == "nt":
            os.system("cls")
        elif os.environ.get("TERM"):
            # only when a terminal type is known, otherwise `clear` prints a warning
            os.system("clear")
    except Exception:
        pass
    try:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
    except Exception:
        pass


def _disp_len(text):
    """Visible width of a string (emoji / CJK count as 2)."""
    width = 0
    for char in str(text):
        width += 2 if unicodedata.east_asian_width(char) in ("W", "F") else 1
    return width


def _box_header(title, width=LICENSE_BOX_WIDTH):
    title = str(title)
    inner = width - 4
    pad_total = max(0, inner - _disp_len(title))
    left = pad_total // 2
    right = pad_total - left
    lines = [
        "╔" + "═" * (width - 2) + "╗",
        "║ " + " " * left + title + " " * right + " ║",
        "╚" + "═" * (width - 2) + "╝",
    ]
    return "\n".join(lines)


def _kv(label, value, pad=12):
    return f"    {str(label).ljust(pad)}: {value}"


def license_parse(text):
    """Return 'yes', 'no' or None for the permission text."""
    if text is None:
        return None
    cleaned = str(text).replace("\ufeff", "")
    cleaned = re.sub(r"[\u200b-\u200f\u2028\u2029]", "", cleaned).strip().lower()
    if not cleaned:
        return None
    for token in re.findall(r"[a-z]+", cleaned):
        if token == "yes":
            return "yes"
        if token == "no":
            return "no"
    return None


def license_fetch(timeout=None):
    """Read the permission file. Returns (status, raw_text, error, source_url)."""
    timeout = timeout or LICENSE_TIMEOUT
    last_error = ""
    for url in (LICENSE_URL, LICENSE_URL_FALLBACK):
        try:
            response = requests.get(
                url,
                timeout=timeout,
                headers={"Cache-Control": "no-cache", "Pragma": "no-cache",
                         "User-Agent": "number-bot-permission-check"},
            )
            status_code = getattr(response, "status_code", 200)
            if status_code != 200:
                last_error = f"HTTP {status_code}"
                continue
            raw = getattr(response, "text", "") or ""
            status = license_parse(raw)
            if status:
                return status, raw.strip()[:300], "", url
            last_error = "permission file has no yes/no"
        except Exception as exc:
            last_error = str(exc)[:160] or exc.__class__.__name__
    return None, "", last_error or "could not reach the permission file", ""


def license_check(log=True):
    """Run one permission check. True = allowed to run."""
    status, raw, error, source = license_fetch()
    LICENSE_STATE.update({
        "status": status or "error",
        "raw": raw,
        "error": error,
        "source": source,
        "checked_at": time.time(),
    })
    if log:
        if status == "yes":
            _print_license_ok(source)
        elif status == "no":
            _print_license_denied()
        else:
            _print_license_unknown(error)
    return status == "yes"


def _license_footer():
    return [
        "",
        "──────────────────────────────────────────────────────────────",
        f"    Build : {BOT_BUILD}",
        f"    Data  : {os.path.abspath(DATA_DIR)}",
        "──────────────────────────────────────────────────────────────",
    ]


def _print_license_ok(source="", clear=True):
    if clear:
        _clear_console()
    checked = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    hours = LICENSE_CHECK_INTERVAL / 3600.0
    next_text = f"{hours:g} ঘণ্টা পরে ({int(hours)}h)"
    _console_write()
    _console_write(_box_header("✅  PERMISSION OK — BOT IS STARTING"))
    _console_write()
    _console_write(_kv("Status", "YES  ✓ (অনুমতি আছে)"))
    _console_write(_kv("Checked", checked))
    _console_write(_kv("Next check", next_text))
    _console_write(_kv("Source", "github.com/AriyanAhamedAri/Permission-only/permission.txt"))
    _console_write(_kv("SMS service", "✅ চালু হচ্ছে — OTP / SMS ডেলিভারি প্রস্তুত"))
    for line in _license_footer():
        _console_write(line)
    _console_write()
    _console_write("    ▶ বট চালু হচ্ছে… (এই জানালাটি প্রতি চেক-এ নতুন করে দেখাবে)")
    _console_write()


def _print_license_denied(clear=True):
    if clear:
        _clear_console()
    _console_write()
    _console_write(_box_header("⛔  BOT OFF — PERMISSION DENIED (no)"))
    _console_write()
    _console_write("    দুঃখিত! এই বট চালানোর অনুমতি নেই (permission.txt = no)।")
    _console_write()
    _console_write("    📞 অ্যাডমিনের সাথে যোগাযোগ করুন:")
    _console_write()
    _console_write(f"       Facebook : {LICENSE_CONTACTS['facebook']}")
    _console_write(f"       WhatsApp : {LICENSE_CONTACTS['whatsapp']}")
    _console_write(f"       Telegram : {LICENSE_CONTACTS['telegram']}")
    _console_write()
    _console_write("    ✆ SMS / মেসেজ দিয়ে সহজে সাহায্য নিন।")
    _console_write()
    _console_write("    বট বন্ধ হয়ে গেছে। অনুমতি দিলে আবার চালু করুন।")
    for line in _license_footer():
        _console_write(line)
    _console_write()


def _print_license_unknown(error="", clear=True):
    if clear:
        _clear_console()
    _console_write()
    _console_write(_box_header("⚠️  PERMISSION CHECK FAILED — BOT KEEPS RUNNING"))
    _console_write()
    _console_write(_kv("Status", "UNKNOWN (ফাইল পড়া যায়নি)"))
    _console_write(_kv("Error", str(error)[:90]))
    _console_write(_kv("Retry", f"{LICENSE_CHECK_INTERVAL / 3600.0:g} ঘণ্টা পরে"))
    _console_write("    ℹ ইন্টারনেট সমস্যায় বট বন্ধ হয় না — শুধু 'no' পেলে বন্ধ হয়।")
    for line in _license_footer():
        _console_write(line)
    _console_write()


class _SilentStream:
    """Swallows late output so only the contact box stays on screen."""

    encoding = "utf-8"
    errors = "replace"

    def write(self, *_args, **_kwargs):
        return 0

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise OSError("silent stream has no file descriptor")


def license_stop(reason="permission denied"):
    """Shut the whole process down right away (after the contact box is printed)."""
    global BOT_TERMINATED
    BOT_TERMINATED = True
    _console_write(f"    ⛔ Bot stopped: {reason}")
    _console_write("")
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    # from here on nothing else may appear on the console
    try:
        sys.stdout = _SilentStream()
        sys.stderr = _SilentStream()
    except Exception:
        pass
    os._exit(0)  # noqa: SLF001 — hard stop, background threads must die with it


def license_gate_or_exit():
    """Startup gate: 'no' shuts the bot down before anything else is started."""
    if license_check(log=True):
        return True
    status = LICENSE_STATE.get("status")
    if status == "no":
        license_stop("permission.txt says no")
    return True


def license_watchdog():
    """Re-check the permission file every LICENSE_CHECK_INTERVAL seconds."""
    while True:
        time.sleep(LICENSE_CHECK_INTERVAL)
        try:
            allowed = license_check(log=True)
        except Exception as exc:
            _console_write(f"⚠️ Permission re-check crashed: {str(exc)[:120]}")
            continue
        if not allowed and LICENSE_STATE.get("status") == "no":
            license_stop("permission.txt changed to no")


def start_license_watch():
    """Startup check + background 24h re-check."""
    license_gate_or_exit()
    threading.Thread(target=license_watchdog, daemon=True).start()


# ==========================================
# Keep-Alive Web Server (UptimeRobot ping)
# ==========================================
class KeepAliveHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"Bot is running!")
    def log_message(self, format, *args):
        pass  # লগ স্প্যাম বন্ধ

def run_keep_alive():
    server = HTTPServer(("0.0.0.0", 8000), KeepAliveHandler)
    server.serve_forever()

if __name__ == "__main__":
    # 🔐 Permission check first: console is cleared, "yes" keeps the bot running,
    # "no" prints the admin contacts and stops the process immediately.
    start_license_watch()

    threading.Thread(target=run_keep_alive, daemon=True).start()
    print("🌐 Keep-Alive server started on port 8000")
    main()