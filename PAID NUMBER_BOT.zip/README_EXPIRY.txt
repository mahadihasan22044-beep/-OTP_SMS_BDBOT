HARD-CODED EXPIRY
=================
This build contains a fixed 48-hour expiry deadline.
After 03 Nov 2026 09:50 Bangladesh time (UTC+6), the bot will refuse to start.
The expiry is non-destructive: project files and data are not deleted.
