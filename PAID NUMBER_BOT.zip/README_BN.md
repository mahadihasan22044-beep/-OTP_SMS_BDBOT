# Number Bot — Source Version

এই সংস্করণে আসল Python source `main.py`-তে রাখা হয়েছে। `main.pyc` বা encrypted loader দরকার নেই।

## Setup
1. Python 3.10+ ইনস্টল করুন (প্রজেক্টের লাইব্রেরির সাথে সামঞ্জস্যপূর্ণ সংস্করণ ব্যবহার করুন)।
2. `mainbot.py-এর hardcoded configuration.example` কপি করে `mainbot.py-এর hardcoded configuration` নাম দিন।
3. `mainbot.py-এর hardcoded configuration`-এ নিজের নতুন `TOKEN (mainbot.py)` এবং `OWNER_ID (mainbot.py)` বসান।
4. Dependencies ইনস্টল করুন: `pip install -r requirements.txt`
5. প্রথমে পুরোনো BDT balance নিরাপদে convert করুন: `python migrate_bdt_to_usdt.py`। আপনার দেওয়া rate `1 USDT = 125 BDT`; rate prompt-এ Enter চাপলে 125 ব্যবহার হবে, এরপর `YES` লিখে নিশ্চিত করুন।
6. তারপর চালান: `python main.py`

## Security
- `mainbot.py-এর hardcoded configuration` বা bot token কাউকে পাঠাবেন না এবং public repository-তে আপলোড করবেন না।
- আগের ZIP-এ থাকা bot token প্রকাশিত হয়ে থাকতে পারে; BotFather থেকে revoke করে নতুন token নিন।
- এই প্যাকেজে `mainbot.py-এর hardcoded configuration` এবং `main.pyc` অন্তর্ভুক্ত করা হয়নি।
- Source-কে plaintext করা হয়েছে; বটের ব্যবসায়িক লজিক/লাইসেন্স চেক ইচ্ছাকৃতভাবে সরানো হয়নি।

## USDT migration
- Withdrawal networks: USDT TRC20 and USDT BEP20.
- Run `python migrate_bdt_to_usdt.py` exactly once before starting the bot.
- The script backs up the three JSON databases first. Default conversion rate is 125 BDT per USDT; press Enter to accept it.
- It converts user balances, minimum withdrawal, OTP/referral rewards, country rewards, and pending withdrawals. Completed/rejected history stays tagged BDT.
- Do not guess the exchange rate; use the rate you intend to honor for existing user balances.
