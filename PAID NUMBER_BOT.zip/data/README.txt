Bot data folder
=================

bot_state.json    - settings, panels, styles, buttons, numbers, stats
users_db.json     - user balances / OTP counts
withdrawals_db.json - withdraw requests
known_users.json  - user ids for broadcast

Admin Panel -> 💾 Backup / Restore:
  📥 Download Data File  -> one JSON file with everything
  📤 Import Old Data     -> send that file back to merge old data into this bot
