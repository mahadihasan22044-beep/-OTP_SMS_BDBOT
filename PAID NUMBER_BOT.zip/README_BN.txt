RAMBO BOT — ALL TEXT & BUTTONS UNICODE BOLD PATCH

This update makes bot message text, photo captions, inline keyboard labels, and main reply-menu labels appear bold using Unicode mathematical bold characters. Existing callbacks and action IDs are preserved. Incoming bold menu labels are normalized before action matching.

INSTALL
1. Stop the bot.
2. Back up your existing main.py.
3. Extract this archive and replace ONLY main.py.
4. Keep your existing mainbot.py-এর hardcoded configuration and data/ folder unchanged.
5. Restart the bot and send /start.

NOTE: Numeric OTPs, links, HTML tags, and callback data are preserved as much as possible. Some fonts/clients may render Unicode bold differently.
